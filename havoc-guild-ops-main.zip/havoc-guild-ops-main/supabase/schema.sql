-- Havoc Guild Operations: production database foundation
create extension if not exists "pgcrypto";

create type public.event_type as enum ('guild_league', 'emperium_overrun');
create type public.raid_type as enum ('main', 'sub');
create type public.reward_category as enum ('puppet_fragment', 'light_dark_feather', 'time_space_feather');

create table public.members (
  id uuid primary key default gen_random_uuid(),
  ign text not null unique,
  job_class text not null,
  combat_role text not null check (combat_role in ('DPS','Support','Utility')),
  auction_group smallint check (auction_group between 1 and 4),
  puppet_complete boolean not null default false,
  puppet_completed_at date,
  puppet_rotation_order integer unique,
  guild_title text not null default 'Member',
  is_officer boolean not null default false,
  can_manage boolean not null default false,
  officer_rotation_order integer,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.events (
  id uuid primary key default gen_random_uuid(),
  event_type public.event_type not null,
  event_date date not null,
  call_time time not null default '20:30',
  loa_cutoff interval not null default interval '6 hours',
  active_auction_group smallint not null check (active_auction_group between 1 and 4),
  lineup_finalized boolean not null default false,
  auction_finalized boolean not null default false,
  created_at timestamptz not null default now(),
  unique(event_type,event_date)
);

create table public.officer_access_profiles (
  auth_user_id uuid primary key references auth.users(id) on delete cascade,
  member_id uuid unique references public.members(id) on delete cascade,
  can_manage_access boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.leave_of_absence (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  reason text,
  filed_at timestamptz not null default now(),
  cancelled_at timestamptz,
  unique(event_id,member_id)
);

create table public.event_absences (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  marked_by uuid,
  marked_at timestamptz not null default now(),
  reason text not null default 'No-show',
  unique(event_id,member_id)
);

create table public.lineup_slots (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  member_id uuid not null references public.members(id) on delete cascade,
  raid public.raid_type not null,
  party_number smallint not null check (party_number between 1 and 8),
  slot_number smallint not null check (slot_number between 1 and 5),
  created_at timestamptz not null default now(),
  unique(event_id,member_id),
  unique(event_id,raid,party_number,slot_number)
);

create table public.auction_runs (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  puppet_count integer not null check (puppet_count >= 0),
  light_dark_end_page integer not null check (light_dark_end_page > 0),
  light_dark_end_item smallint not null check (light_dark_end_item between 1 and 4),
  time_space_end_page integer not null check (time_space_end_page > 0),
  time_space_end_item smallint not null check (time_space_end_item between 1 and 4),
  light_dark_total integer not null check (light_dark_total >= 0),
  time_space_total integer not null check (time_space_total >= 0),
  officer_rotation_start smallint not null default 0,
  officer_rotation_next smallint not null default 0,
  generated_at timestamptz not null default now()
);

create table public.guild_settings (
  id boolean primary key default true check (id),
  officer_rotation_index smallint not null default 0,
  updated_at timestamptz not null default now()
);

create table public.job_change_log (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references public.members(id) on delete cascade,
  previous_job text,
  previous_role text,
  new_job text not null,
  new_role text not null,
  reason text not null check (char_length(reason) >= 5),
  changed_at timestamptz not null default now()
);

create table public.auction_player_quotas (
  id uuid primary key default gen_random_uuid(),
  auction_run_id uuid not null references public.auction_runs(id) on delete cascade,
  member_id uuid not null references public.members(id),
  light_dark_count integer not null default 0 check (light_dark_count >= 0),
  time_space_count integer not null default 0 check (time_space_count >= 0),
  unique(auction_run_id,member_id)
);

create table public.auction_assignments (
  id uuid primary key default gen_random_uuid(),
  auction_run_id uuid not null references public.auction_runs(id) on delete cascade,
  member_id uuid not null references public.members(id),
  category public.reward_category not null,
  auction_tab text not null check (auction_tab in ('Cards','Feather')),
  page_number integer,
  item_number integer not null,
  auction_group smallint check (auction_group between 1 and 4),
  created_at timestamptz not null default now()
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  entity_type text not null,
  entity_id text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index loa_event_idx on public.leave_of_absence(event_id) where cancelled_at is null;
create index absence_event_idx on public.event_absences(event_id);
create index lineup_event_idx on public.lineup_slots(event_id);
create index auction_assignment_run_idx on public.auction_assignments(auction_run_id);

alter table public.members enable row level security;
alter table public.events enable row level security;
alter table public.officer_access_profiles enable row level security;
alter table public.leave_of_absence enable row level security;
alter table public.event_absences enable row level security;
alter table public.lineup_slots enable row level security;
alter table public.auction_runs enable row level security;
alter table public.guild_settings enable row level security;
alter table public.job_change_log enable row level security;
alter table public.auction_player_quotas enable row level security;
alter table public.auction_assignments enable row level security;
alter table public.audit_log enable row level security;

-- Add authenticated-user policies only after the guild's admin/member roles are connected.
