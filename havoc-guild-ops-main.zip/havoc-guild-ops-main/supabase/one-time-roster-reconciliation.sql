-- One-time guarded reconciliation for the September 2026 roster.
-- Run only after reviewing the preflight output. The block aborts and rolls back on any mismatch.

do $$
declare
  v_state jsonb;
  v_removed_ids text[];
  v_removed_member_ids uuid[];
  v_event jsonb;
  v_events jsonb := '[]'::jsonb;
  v_lineups jsonb;
  v_parties jsonb;
  v_party jsonb;
  v_raid text;
  v_player record;
  v_index integer;
  v_order integer := 1;
  v_member_id uuid;
  v_active_count integer;
  v_distinct_positions integer;
begin
  select state into v_state from public.guild_app_state where id = true for update;
  if v_state is null then raise exception 'Guild state not found'; end if;

  select count(*) into v_active_count
  from jsonb_array_elements(coalesce(v_state->'players', '[]'::jsonb)) player
  where coalesce((player->>'active')::boolean, true);
  if v_active_count <> 78 then raise exception 'Expected 78 active state players, found %', v_active_count; end if;

  if not exists (select 1 from public.members where id = '86a7469d-3abc-49bc-b496-22180304ba27' and lower(ign) = 'lumululu') then
    raise exception 'Expected Lumululu member record was not found';
  end if;
  if not exists (select 1 from public.members where id = '7c3689c2-658e-41d6-96c2-ce55325f5b61' and auth_user_id = 'ffb25e31-bbf9-4d11-b345-4a9cc2de957a') then
    raise exception 'Expected active RonTzy officer record was not found';
  end if;
  if not exists (
    select 1 from jsonb_array_elements(v_state->'players') player
    where player->>'id' = 'player-71' and player->>'name' = 'CREIOS'
  ) then raise exception 'Expected CREIOS state record was not found'; end if;

  select coalesce(array_agg(player->>'id'), array[]::text[])
  into v_removed_ids
  from jsonb_array_elements(v_state->'players') player
  where not coalesce((player->>'active')::boolean, true);

  v_removed_member_ids := array[
    '662fbdef-9bf6-45e7-8b1a-b0ad982cdae9'::uuid,
    'a4f721b4-5fdf-4a06-9e0d-570e524220f0'::uuid,
    'ed2f5273-d602-4fe6-ab86-7fff017fd37f'::uuid,
    '200097f6-6828-405b-b5e7-c11fc6226654'::uuid,
    '263750a7-8d7b-4420-97b8-a766ae6a5d9f'::uuid,
    '9699fbc5-8e2b-4c71-9307-41a938530567'::uuid,
    '4bf7dd3a-3073-49df-b0d8-1fc26191ede4'::uuid,
    '31e88496-eaa3-45ec-a79b-f08518e3fe8b'::uuid,
    'f9e6807c-1a84-4d18-95e7-74eaf6e0e4da'::uuid
  ];

  delete from public.auction_assignments where member_id = any(v_removed_member_ids);
  delete from public.auction_player_quotas where member_id = any(v_removed_member_ids);
  delete from public.audit_log where entity_id = any(v_removed_member_ids::text[]);
  delete from public.members where id = any(v_removed_member_ids);

  update public.members set ign = 'RonTzy', active = true, updated_at = now()
  where id = '7c3689c2-658e-41d6-96c2-ce55325f5b61';
  update public.officer_access_profiles set login_name = 'RonTzy'
  where member_id = '7c3689c2-658e-41d6-96c2-ce55325f5b61';
  update public.members set ign = 'pautog', active = true, updated_at = now()
  where id = '86a7469d-3abc-49bc-b496-22180304ba27';

  v_state := jsonb_set(v_state, '{players}', coalesce((
    select jsonb_agg(player order by ordinality)
    from jsonb_array_elements(v_state->'players') with ordinality rows(player, ordinality)
    where coalesce((player->>'active')::boolean, true)
  ), '[]'::jsonb), false);

  v_state := jsonb_set(v_state, '{loas}', coalesce((select jsonb_agg(row)
    from jsonb_array_elements(coalesce(v_state->'loas', '[]'::jsonb)) row
    where not (row->>'playerId' = any(v_removed_ids))), '[]'::jsonb), true);
  v_state := jsonb_set(v_state, '{jobChangeLog}', coalesce((select jsonb_agg(row)
    from jsonb_array_elements(coalesce(v_state->'jobChangeLog', '[]'::jsonb)) row
    where not (row->>'playerId' = any(v_removed_ids))), '[]'::jsonb), true);
  v_state := jsonb_set(v_state, '{publicActionLog}', coalesce((select jsonb_agg(row)
    from jsonb_array_elements(coalesce(v_state->'publicActionLog', '[]'::jsonb)) row
    where not (row->>'playerId' = any(v_removed_ids))), '[]'::jsonb), true);
  v_state := jsonb_set(v_state, '{history}', coalesce((select jsonb_agg(row)
    from jsonb_array_elements(coalesce(v_state->'history', '[]'::jsonb)) row
    where not exists (select 1 from unnest(v_removed_ids) id where row::text like '%' || id || '%')), '[]'::jsonb), true);
  v_state := jsonb_set(v_state, '{lineupHistory}', coalesce((select jsonb_agg(row)
    from jsonb_array_elements(coalesce(v_state->'lineupHistory', '[]'::jsonb)) row
    where not exists (select 1 from unnest(v_removed_ids) id where row::text like '%' || id || '%')), '[]'::jsonb), true);
  v_state := jsonb_set(v_state, '{puppetCycleHistory}', coalesce((select jsonb_agg(
    jsonb_set(cycle, '{members}', coalesce((select jsonb_agg(member)
      from jsonb_array_elements(coalesce(cycle->'members', '[]'::jsonb)) member
      where not (member->>'playerId' = any(v_removed_ids))), '[]'::jsonb), true))
    from jsonb_array_elements(coalesce(v_state->'puppetCycleHistory', '[]'::jsonb)) cycle), '[]'::jsonb), true);

  for v_event in select value from jsonb_array_elements(coalesce(v_state->'events', '[]'::jsonb)) loop
    v_lineups := coalesce(v_event->'lineups', jsonb_build_object('main','[]'::jsonb,'sub','[]'::jsonb));
    foreach v_raid in array array['main','sub'] loop
      v_parties := '[]'::jsonb;
      for v_party in select value from jsonb_array_elements(coalesce(v_lineups->v_raid, '[]'::jsonb)) loop
        v_party := coalesce((select jsonb_agg(case when trim(both '"' from slot::text) = any(v_removed_ids) then 'null'::jsonb else slot end order by ordinality)
          from jsonb_array_elements(v_party) with ordinality rows(slot, ordinality)), '[]'::jsonb);
        v_parties := v_parties || jsonb_build_array(v_party);
      end loop;
      v_lineups := jsonb_set(v_lineups, array[v_raid], v_parties, true);
    end loop;
    v_event := jsonb_set(v_event, '{lineups}', v_lineups, true);
    v_event := jsonb_set(v_event, '{noShows}', coalesce((select jsonb_agg(item)
      from jsonb_array_elements(coalesce(v_event->'noShows', '[]'::jsonb)) item
      where not (trim(both '"' from item::text) = any(v_removed_ids))), '[]'::jsonb), true);
    v_event := jsonb_set(v_event, '{ineligibleFeatherIds}', coalesce((select jsonb_agg(item)
      from jsonb_array_elements(coalesce(v_event->'ineligibleFeatherIds', '[]'::jsonb)) item
      where not (trim(both '"' from item::text) = any(v_removed_ids))), '[]'::jsonb), true);
    if v_event ? 'featherIneligibleReasons' then
      v_event := jsonb_set(v_event, '{featherIneligibleReasons}', coalesce(v_event->'featherIneligibleReasons','{}'::jsonb) - v_removed_ids, true);
    end if;
    if v_event #> '{auction,assignments}' is not null then
      v_event := jsonb_set(v_event, '{auction,assignments}', coalesce((select jsonb_agg(row)
        from jsonb_array_elements(v_event #> '{auction,assignments}') row
        where not (row->>'playerId' = any(v_removed_ids))), '[]'::jsonb), false);
    end if;
    if v_event #> '{auction,settings,playerQuotas}' is not null then
      v_event := jsonb_set(v_event, '{auction,settings,playerQuotas}', (v_event #> '{auction,settings,playerQuotas}') - v_removed_ids, false);
    end if;
    v_events := v_events || jsonb_build_array(v_event);
  end loop;
  v_state := jsonb_set(v_state, '{events}', v_events, true);

  -- Keep everyone in the same relative queue order, except restore CREIOS permanently at #7.
  for v_player in
    select player->>'id' app_id
    from jsonb_array_elements(v_state->'players') player
    where player->>'id' <> 'player-71'
    order by nullif(player->>'puppetOrder','')::integer nulls last, lower(player->>'name')
  loop
    if v_order = 7 then v_order := 8; end if;
    select (ordinality - 1)::integer into v_index
    from jsonb_array_elements(v_state->'players') with ordinality rows(player, ordinality)
    where player->>'id' = v_player.app_id;
    v_state := jsonb_set(v_state, array['players',v_index::text,'puppetOrder'], to_jsonb(v_order), true);
    v_order := v_order + 1;
  end loop;
  select (ordinality - 1)::integer into v_index
  from jsonb_array_elements(v_state->'players') with ordinality rows(player, ordinality)
  where player->>'id' = 'player-71';
  v_state := jsonb_set(v_state, array['players',v_index::text,'puppetOrder'], '7'::jsonb, true);

  -- Synchronize every remaining normalized member by identity and write its UUID back into app state.
  -- Clear positions first so the unique constraint cannot collide while rows are renumbered.
  update public.members set puppet_rotation_order = null where active;
  for v_player in
    select player, (ordinality - 1)::integer player_index
    from jsonb_array_elements(v_state->'players') with ordinality rows(player, ordinality)
  loop
    select id into v_member_id from public.members where lower(ign) = lower(v_player.player->>'name') limit 1;
    if v_member_id is null then raise exception 'No normalized member row for %', v_player.player->>'name'; end if;
    update public.members set
      puppet_rotation_order = nullif(v_player.player->>'puppetOrder','')::integer,
      puppet_complete = coalesce((v_player.player->>'puppetComplete')::boolean,false),
      puppet_completed_at = nullif(v_player.player->>'puppetCompletedAt','')::date,
      active = true,
      updated_at = now()
    where id = v_member_id;
    v_state := jsonb_set(v_state, array['players',v_player.player_index::text,'dbId'], to_jsonb(v_member_id::text), true);
  end loop;

  select count(*), count(distinct nullif(player->>'puppetOrder','')::integer)
  into v_active_count, v_distinct_positions
  from jsonb_array_elements(v_state->'players') player;
  if v_active_count <> 78 or v_distinct_positions <> 78 then
    raise exception 'Reconciled roster/rotation validation failed: % players, % positions', v_active_count, v_distinct_positions;
  end if;
  if not exists (select 1 from jsonb_array_elements(v_state->'players') player where player->>'name'='CREIOS' and (player->>'puppetOrder')::int=7) then
    raise exception 'CREIOS was not restored to Puppet position 7';
  end if;
  if (select count(*) from public.members where active) <> 78 then raise exception 'Normalized active roster is not 78'; end if;

  update public.guild_app_state set state = v_state, updated_at = now() where id = true;
end;
$$;
