-- HAVOC Marketplace + preview isolation
-- Applied to Supabase project snknsiptlxddqrnqmqfy on 2026-09-18.

create table if not exists public.havoc_preview_state (
  branch_key text primary key,
  state jsonb not null default '{}'::jsonb,
  version bigint not null default 1,
  last_changed_by text,
  last_change_kind text,
  last_changed_at timestamptz,
  updated_at timestamptz not null default now()
);

alter table public.havoc_preview_state enable row level security;
revoke all on table public.havoc_preview_state from anon, authenticated;
grant select, insert, update, delete on table public.havoc_preview_state to service_role;

create table if not exists public.marketplace_listings (
  id uuid primary key default gen_random_uuid(),
  scope text not null,
  intent text not null check (intent in ('sell','buy','trade')),
  category text not null,
  title text not null,
  seller_player_id text not null,
  seller_ign text not null,
  right_type text check (right_type is null or right_type in ('feather','puppet')),
  origin_event_id text,
  origin_event_date date,
  origin_group smallint check (origin_group is null or origin_group between 1 and 4),
  price numeric(12,2) check (price is null or price >= 0),
  price_text text,
  description text,
  password_salt text not null,
  password_hash text not null,
  status text not null default 'listed' check (status in ('listed','sold','cancelled','expired','completed')),
  buyer_player_id text,
  buyer_ign text,
  sold_at timestamptz,
  completed_at timestamptz,
  cancelled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists marketplace_listings_scope_status_idx
  on public.marketplace_listings(scope, status, right_type, created_at desc);

create unique index if not exists marketplace_one_open_right_per_seller
  on public.marketplace_listings(scope, seller_player_id, right_type)
  where right_type is not null and status in ('listed','sold');

create unique index if not exists marketplace_one_open_purchase_per_buyer
  on public.marketplace_listings(scope, buyer_player_id, right_type)
  where right_type is not null and status = 'sold' and buyer_player_id is not null;

alter table public.marketplace_listings enable row level security;
revoke all on table public.marketplace_listings from anon, authenticated;
grant select, insert, update, delete on table public.marketplace_listings to service_role;

create table if not exists public.marketplace_offers (
  id uuid primary key default gen_random_uuid(),
  scope text not null,
  listing_id uuid not null references public.marketplace_listings(id) on delete cascade,
  buyer_player_id text not null,
  buyer_ign text not null,
  amount numeric(12,2) check (amount is null or amount >= 0),
  note text,
  status text not null default 'active' check (status in ('active','accepted','withdrawn','expired')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists marketplace_offers_listing_status_idx
  on public.marketplace_offers(scope, listing_id, status, created_at desc);

create index if not exists marketplace_offers_buyer_status_idx
  on public.marketplace_offers(scope, buyer_player_id, status, created_at desc);

create unique index if not exists marketplace_one_active_offer_per_buyer_listing
  on public.marketplace_offers(listing_id, buyer_player_id)
  where status = 'active';

alter table public.marketplace_offers enable row level security;
revoke all on table public.marketplace_offers from anon, authenticated;
grant select, insert, update, delete on table public.marketplace_offers to service_role;


-- Listing photos (added 2026-09-18)
create table if not exists public.marketplace_listing_images (
  id uuid primary key default gen_random_uuid(),
  scope text not null,
  listing_id uuid not null references public.marketplace_listings(id) on delete cascade,
  storage_path text not null unique,
  original_name text not null,
  content_type text not null,
  size_bytes integer,
  position smallint not null default 0 check (position between 0 and 4),
  created_at timestamptz not null default now(),
  unique (listing_id, position)
);

create index if not exists marketplace_listing_images_listing_idx
  on public.marketplace_listing_images(scope, listing_id, position);

alter table public.marketplace_listing_images enable row level security;
revoke all on table public.marketplace_listing_images from anon, authenticated;
grant select, insert, update, delete on table public.marketplace_listing_images to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('marketplace-media','marketplace-media',false,3145728,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update
set public=excluded.public,
    file_size_limit=excluded.file_size_limit,
    allowed_mime_types=excluded.allowed_mime_types;


-- Bidding-right BUY requests (added 2026-09-18)
alter table public.marketplace_listings
  add column if not exists created_by_player_id text,
  add column if not exists created_by_ign text;

update public.marketplace_listings
set created_by_player_id = coalesce(created_by_player_id, seller_player_id),
    created_by_ign = coalesce(created_by_ign, seller_ign)
where created_by_player_id is null or created_by_ign is null;

drop index if exists public.marketplace_one_open_right_per_seller;

create unique index if not exists marketplace_one_listed_sell_right_per_seller
  on public.marketplace_listings(scope, seller_player_id, right_type)
  where right_type is not null and intent = 'sell' and status = 'listed';

create unique index if not exists marketplace_one_sold_right_per_seller
  on public.marketplace_listings(scope, seller_player_id, right_type)
  where right_type is not null and status = 'sold';

create unique index if not exists marketplace_one_open_buy_request_per_buyer
  on public.marketplace_listings(scope, created_by_player_id, right_type)
  where right_type is not null
    and intent = 'buy'
    and status = 'listed'
    and created_by_player_id is not null;
