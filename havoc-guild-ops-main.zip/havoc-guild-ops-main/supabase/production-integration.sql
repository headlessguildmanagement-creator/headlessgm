-- Havoc production integration layer
alter table public.members add column if not exists auth_user_id uuid references auth.users(id) on delete set null;
alter table public.officer_access_profiles add column if not exists login_name text;
alter table public.officer_access_profiles add column if not exists login_email text;
alter table public.officer_access_profiles add column if not exists must_change_password boolean not null default false;
create unique index if not exists officer_access_login_name_idx on public.officer_access_profiles(lower(login_name)) where login_name is not null;

create table if not exists public.guild_app_state (
  id boolean primary key default true check (id),
  state jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.guild_app_state enable row level security;

create or replace function public.is_havoc_officer()
returns boolean language sql stable security definer set search_path = public, auth
as $$ select exists (select 1 from public.officer_access_profiles p where p.auth_user_id = auth.uid() and p.active = true); $$;

create or replace function public.is_havoc_admin()
returns boolean language sql stable security definer set search_path = public, auth
as $$ select exists (select 1 from public.officer_access_profiles p where p.auth_user_id = auth.uid() and p.active = true and p.can_manage_access = true); $$;

create or replace function public.complete_havoc_first_login()
returns void language plpgsql security definer set search_path = public, auth
as $$ begin update public.officer_access_profiles set must_change_password=false where auth_user_id=auth.uid() and active=true; end; $$;
revoke all on function public.complete_havoc_first_login() from public;
grant execute on function public.complete_havoc_first_login() to authenticated;

-- Snapshot is sanitized by the client: it contains no passwords or Auth IDs.
drop policy if exists guild_app_state_public_read on public.guild_app_state;
create policy guild_app_state_public_read on public.guild_app_state for select to anon, authenticated using (true);
drop policy if exists guild_app_state_officer_write on public.guild_app_state;
create policy guild_app_state_officer_write on public.guild_app_state for insert to authenticated with check (public.is_havoc_officer());
drop policy if exists guild_app_state_officer_update on public.guild_app_state;
create policy guild_app_state_officer_update on public.guild_app_state for update to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());

-- Members are not public API data; the public app uses the sanitized snapshot.
drop policy if exists members_public_read on public.members;
drop policy if exists members_officer_read on public.members;
create policy members_officer_read on public.members for select to authenticated using (public.is_havoc_officer());
drop policy if exists members_admin_insert on public.members;
drop policy if exists members_officer_insert on public.members;
create policy members_officer_insert on public.members for insert to authenticated with check (public.is_havoc_officer());
drop policy if exists members_admin_update on public.members;
drop policy if exists members_officer_update on public.members;
create policy members_officer_update on public.members for update to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());

-- Required table privileges for the browser officer client and server-side access manager.
grant select, insert, update on table public.members to authenticated;
grant select, insert, update on table public.members to service_role;

-- Published operational data can be read publicly; writes require an officer.
drop policy if exists events_public_read on public.events; create policy events_public_read on public.events for select to anon, authenticated using (true);
drop policy if exists events_officer_write on public.events; create policy events_officer_write on public.events for all to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());
drop policy if exists loa_public_read on public.leave_of_absence; create policy loa_public_read on public.leave_of_absence for select to anon, authenticated using (true);
drop policy if exists loa_officer_write on public.leave_of_absence; create policy loa_officer_write on public.leave_of_absence for all to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());
drop policy if exists absence_public_read on public.event_absences; create policy absence_public_read on public.event_absences for select to anon, authenticated using (true);
drop policy if exists absence_officer_write on public.event_absences; create policy absence_officer_write on public.event_absences for all to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());
drop policy if exists lineup_public_read on public.lineup_slots; create policy lineup_public_read on public.lineup_slots for select to anon, authenticated using (true);
drop policy if exists lineup_officer_write on public.lineup_slots; create policy lineup_officer_write on public.lineup_slots for all to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());
drop policy if exists auction_runs_public_read on public.auction_runs; create policy auction_runs_public_read on public.auction_runs for select to anon, authenticated using (true);
drop policy if exists auction_runs_officer_write on public.auction_runs; create policy auction_runs_officer_write on public.auction_runs for all to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());
drop policy if exists auction_quotas_public_read on public.auction_player_quotas; create policy auction_quotas_public_read on public.auction_player_quotas for select to anon, authenticated using (true);
drop policy if exists auction_quotas_officer_write on public.auction_player_quotas; create policy auction_quotas_officer_write on public.auction_player_quotas for all to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());
drop policy if exists auction_assignments_public_read on public.auction_assignments; create policy auction_assignments_public_read on public.auction_assignments for select to anon, authenticated using (true);
drop policy if exists auction_assignments_officer_write on public.auction_assignments; create policy auction_assignments_officer_write on public.auction_assignments for all to authenticated using (public.is_havoc_officer()) with check (public.is_havoc_officer());

-- Access profiles: officers can read the access roster; only administrators can mutate it.
drop policy if exists officer_profiles_read on public.officer_access_profiles;
create policy officer_profiles_read on public.officer_access_profiles for select to authenticated using (public.is_havoc_officer());
drop policy if exists officer_profiles_admin_write on public.officer_access_profiles;
create policy officer_profiles_admin_write on public.officer_access_profiles for all to authenticated using (public.is_havoc_admin()) with check (public.is_havoc_admin());

-- Seed/link the two administrators whose Auth accounts already exist.
insert into public.officer_access_profiles(auth_user_id, member_id, can_manage_access, active, login_name, login_email, must_change_password)
select u.id, m.id, true, true, m.ign, u.email, false
from auth.users u
join public.members m on lower(m.ign) = lower(case when u.email='gabrielbalenton@gmail.com' then 'OZAWA' else 'Zonzi' end)
where u.email in ('gabrielbalenton@gmail.com','zonzi@havoc-guild.local')
on conflict (auth_user_id) do update set member_id=excluded.member_id,can_manage_access=true,active=true,login_name=excluded.login_name,login_email=excluded.login_email,must_change_password=false;

update public.members m set auth_user_id=p.auth_user_id from public.officer_access_profiles p where p.member_id=m.id and p.active=true;
