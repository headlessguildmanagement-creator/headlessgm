-- Havoc officer/member permissions
-- Run once in Supabase SQL Editor.
-- Officers may read, add, and edit member profiles; only OZAWA/Zonzi can manage officer access.

grant select, insert, update on table public.members to authenticated;
grant select, insert, update on table public.members to service_role;

drop policy if exists members_admin_insert on public.members;
drop policy if exists members_officer_insert on public.members;
create policy members_officer_insert on public.members
  for insert to authenticated
  with check (public.is_havoc_officer());

drop policy if exists members_admin_update on public.members;
drop policy if exists members_officer_update on public.members;
create policy members_officer_update on public.members
  for update to authenticated
  using (public.is_havoc_officer())
  with check (public.is_havoc_officer());
