create table if not exists public.puppet_appeals (
  id uuid primary key default gen_random_uuid(),
  state_player_id text not null,
  member_id uuid references public.members(id) on delete set null,
  player_name text not null,
  cycle integer not null check (cycle > 0),
  event_id text not null,
  event_date date not null,
  assignment_page integer,
  assignment_item integer,
  reason text not null,
  declaration boolean not null default true,
  screenshot_path text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by text,
  review_note text
);

create unique index if not exists puppet_appeals_one_per_cycle
  on public.puppet_appeals(state_player_id, cycle);
create index if not exists puppet_appeals_status_submitted
  on public.puppet_appeals(status, submitted_at desc);

alter table public.puppet_appeals enable row level security;

-- Server-side Puppet Appeal APIs run with the Supabase service role. Explicit
-- grants are required even though service_role bypasses RLS.
grant select, insert, update, delete on table public.puppet_appeals to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'puppet-appeals',
  'puppet-appeals',
  false,
  3145728,
  array['image/jpeg','image/png','image/webp']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;
