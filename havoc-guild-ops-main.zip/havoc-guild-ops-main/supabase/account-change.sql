-- Atomic public IGN changes. Apply before deploying the matching application code.
-- The Vercel API calls this function with the server-only service role.

create or replace function public.rename_havoc_member(
  p_player_id text,
  p_new_ign text,
  p_reason text
)
returns jsonb
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_state jsonb;
  v_player jsonb;
  v_player_index integer;
  v_old_ign text;
  v_new_ign text := regexp_replace(btrim(coalesce(p_new_ign, '')), '\s+', ' ', 'g');
  v_reason text := left(btrim(coalesce(p_reason, '')), 500);
  v_member_id uuid;
  v_now timestamptz := now();
  v_account_log jsonb;
  v_public_log jsonb;
begin
  if char_length(v_new_ign) < 2 or char_length(v_new_ign) > 32 then
    raise exception 'IGN must contain 2 to 32 characters';
  end if;
  if v_new_ign ~ '[<>[:cntrl:]]' then
    raise exception 'IGN contains unsupported characters';
  end if;
  if char_length(v_reason) < 3 then
    raise exception 'Please enter a reason for the IGN change';
  end if;

  select state into v_state
  from public.guild_app_state
  where id = true
  for update;

  if v_state is null then raise exception 'Guild state not found'; end if;

  select item, (ordinality - 1)::integer
  into v_player, v_player_index
  from jsonb_array_elements(coalesce(v_state->'players', '[]'::jsonb)) with ordinality as rows(item, ordinality)
  where item->>'id' = p_player_id
    and coalesce((item->>'active')::boolean, true)
  limit 1;

  if v_player is null then raise exception 'Active member not found'; end if;
  v_old_ign := v_player->>'name';
  if lower(v_new_ign) = lower(v_old_ign) then raise exception 'The new IGN is the same as the current IGN'; end if;

  if exists (
    select 1
    from jsonb_array_elements(coalesce(v_state->'players', '[]'::jsonb)) item
    where item->>'id' <> p_player_id
      and coalesce((item->>'active')::boolean, true)
      and lower(item->>'name') = lower(v_new_ign)
  ) then
    raise exception 'That IGN is already used by another active member';
  end if;

  select id into v_member_id
  from public.members
  where lower(ign) = lower(v_old_ign)
  order by active desc, updated_at desc
  limit 1
  for update;

  if v_member_id is null then raise exception 'The normalized member record was not found'; end if;
  if exists (select 1 from public.members where id <> v_member_id and lower(ign) = lower(v_new_ign)) then
    raise exception 'That IGN already exists in the member database';
  end if;

  update public.members
  set ign = v_new_ign, updated_at = v_now
  where id = v_member_id;

  update public.officer_access_profiles
  set login_name = v_new_ign
  where member_id = v_member_id;

  v_player := jsonb_set(v_player, '{name}', to_jsonb(v_new_ign), false);
  v_player := jsonb_set(v_player, '{dbId}', to_jsonb(v_member_id::text), true);
  v_state := jsonb_set(v_state, array['players', v_player_index::text], v_player, false);

  v_account_log := coalesce(v_state->'accountChangeLog', '[]'::jsonb) || jsonb_build_array(jsonb_build_object(
    'id', gen_random_uuid(), 'playerId', p_player_id, 'oldIgn', v_old_ign,
    'newIgn', v_new_ign, 'reason', v_reason, 'changedAt', v_now, 'submittedPublicly', true
  ));
  v_state := jsonb_set(v_state, '{accountChangeLog}',
    (select coalesce(jsonb_agg(item), '[]'::jsonb) from (
      select item from jsonb_array_elements(v_account_log) with ordinality rows(item, n)
      order by n desc limit 300
    ) kept), true);

  v_public_log := coalesce(v_state->'publicActionLog', '[]'::jsonb) || jsonb_build_array(jsonb_build_object(
    'id', gen_random_uuid(), 'action', 'ign_change', 'playerId', p_player_id,
    'playerName', v_new_ign, 'previousPlayerName', v_old_ign, 'at', v_now
  ));
  v_state := jsonb_set(v_state, '{publicActionLog}',
    (select coalesce(jsonb_agg(item), '[]'::jsonb) from (
      select item from jsonb_array_elements(v_public_log) with ordinality rows(item, n)
      order by n desc limit 500
    ) kept), true);

  update public.guild_app_state
  set state = v_state, updated_at = v_now
  where id = true;

  insert into public.audit_log(action, entity_type, entity_id, payload)
  values ('public_ign_change', 'member', v_member_id::text,
    jsonb_build_object('playerId', p_player_id, 'oldIgn', v_old_ign, 'newIgn', v_new_ign, 'reason', v_reason));

  return jsonb_build_object('ok', true, 'memberId', v_member_id, 'playerId', p_player_id, 'oldIgn', v_old_ign, 'newIgn', v_new_ign);
end;
$$;

revoke execute on function public.rename_havoc_member(text, text, text) from public, anon, authenticated;
grant execute on function public.rename_havoc_member(text, text, text) to service_role;
