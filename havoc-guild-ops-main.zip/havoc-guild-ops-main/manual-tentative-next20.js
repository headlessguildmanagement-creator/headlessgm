(() => {
  const originalPublishToDiscord = window.publishToDiscord;
  const TENTATIVE_PUPPET_LIMIT = 20;

  function unavailableIds(event) {
    const unavailable = new Set([...(event?.noShows || []), ...(event?.puppetCannotBidIds || [])]);
    for (const loa of state.loas || []) {
      if (loa.eventId === event?.id && !loa.cancelledAt) unavailable.add(loa.playerId);
    }
    for (const playerId of event?.ineligibleFeatherIds || []) {
      if (event.featherIneligibleReasons?.[playerId] === "Absent") unavailable.add(playerId);
    }
    for (const member of state.players || []) {
      if (member.active && typeof window.havocIsMemberEligibleForEvent === "function" && !window.havocIsMemberEligibleForEvent(member, event)) unavailable.add(member.id);
    }
    return unavailable;
  }

  function appealWindowOpen(cycle, event) {
    if (Number(cycle) === Number(state.puppetCycle || 1)) return true;
    const history = (state.puppetCycleHistory || []).find(row => Number(row.cycle) === Number(cycle));
    if (!history?.completedAt) return false;
    const deadline = history.appealOpenUntil || new Date(new Date(history.completedAt).getTime() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const eventAt = new Date(`${event?.date}T${event?.callTime || '20:30'}:00+08:00`).getTime();
    return eventAt <= new Date(deadline).getTime();
  }

  function tentativePuppetPlayers(event, limit = TENTATIVE_PUPPET_LIMIT) {
    const unavailable = unavailableIds(event);
    const rotation = (state.players || [])
      .filter(member => member.active && Number.isInteger(member.puppetOrder))
      .sort((a, b) => a.puppetOrder - b.puppetOrder);
    const byId = new Map(rotation.map(member => [member.id, member]));
    const available = rotation.filter(member => !unavailable.has(member.id));
    const selected = [];
    const selectedIds = new Set();
    const take = member => {
      if (!member || unavailable.has(member.id) || selectedIds.has(member.id) || selected.length >= limit) return;
      selectedIds.add(member.id);
      selected.push(member);
    };

    (state.puppetDeferredTurns || [])
      .filter(row => !row.consumedAt)
      .sort((a,b)=>Number(a.sourceCycle||0)-Number(b.sourceCycle||0)||String(a.createdAt||'').localeCompare(String(b.createdAt||'')))
      .forEach(row => take(byId.get(row.playerId)));

    (state.puppetAppealQueue || [])
      .filter(row => !row.consumedAt && appealWindowOpen(row.sourceCycle, event))
      .sort((a,b)=>Number(a.sourceCycle||0)-Number(b.sourceCycle||0)||String(a.approvedAt||'').localeCompare(String(b.approvedAt||'')))
      .forEach(row => take(byId.get(row.playerId)));

    available.filter(member => !member.puppetComplete).forEach(take);
    if (selected.length < limit) available.filter(member => member.puppetComplete).forEach(take);
    return selected;
  }

  function tentativeFeatherPlayers(event) {
    const unavailable = unavailableIds(event);
    const blocked = new Set([...(event?.ineligibleFeatherIds || []), ...unavailable]);
    return (state.players || [])
      .filter(member => member.active && Number(member.auctionGroup) === Number(event.activeGroup) && !blocked.has(member.id))
      .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
  }

  function roundedRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, r);
    ctx.stroke();
  }

  function loadImage(src) {
    return new Promise(resolve => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = src;
    });
  }

  async function generateTentativeImage(event) {
    const width = 1200;
    const rowHeight = 52;
    const feather = tentativeFeatherPlayers(event);
    const puppet = tentativePuppetPlayers(event);
    const rows = Math.max(feather.length, puppet.length, 20);
    const height = Math.max(1320, 420 + rows * rowHeight);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");

    const bg = ctx.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, "#06070a");
    bg.addColorStop(0.62, "#0b0b0f");
    bg.addColorStop(1, "#19090d");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    ctx.fillStyle = "#c9152e";
    ctx.fillRect(0, 0, 14, height);
    ctx.fillStyle = "rgba(201,21,46,.14)";
    ctx.fillRect(width - 160, 0, 160, height);

    const crest = await loadImage("/assets/havoc-crest.png");
    if (crest) {
      const maxW = 185;
      const maxH = 185;
      const scale = Math.min(maxW / crest.width, maxH / crest.height);
      const w = crest.width * scale;
      const h = crest.height * scale;
      ctx.drawImage(crest, 44, 35, w, h);
    }

    ctx.fillStyle = "#f14a5e";
    ctx.font = "900 18px Arial, sans-serif";
    ctx.fillText("HAVOC GUILD OPERATIONS", 250, 60);
    ctx.fillStyle = "#f5eee2";
    ctx.font = "900 54px Arial, sans-serif";
    ctx.fillText("POSSIBLE BIDDERS", 250, 125);
    ctx.fillStyle = "#bcb6ae";
    ctx.font = "700 21px Arial, sans-serif";
    ctx.fillText(`${event.name} · ${formatDate(event.date)} · Group ${event.activeGroup}`, 250, 165);

    ctx.strokeStyle = "#d62a40";
    ctx.lineWidth = 2;
    roundedRect(ctx, 44, 220, 1112, 112, 12);
    ctx.fillStyle = "#ef4658";
    ctx.font = "900 23px Arial, sans-serif";
    ctx.fillText("EARLY REMINDER ONLY — NOT THE OFFICIAL BIDDING LIST", 78, 260);
    ctx.fillStyle = "#d5d0c8";
    ctx.font = "600 17px Arial, sans-serif";
    ctx.fillText("The names below are possible bidders based on the current order and eligibility.", 78, 292);
    ctx.fillText("Puppet bidders may change depending on the final event ranking/results.", 78, 318);

    const leftX = 44;
    const rightX = 614;
    const panelY = 368;
    const panelW = 542;
    const panelH = rows * rowHeight + 92;

    ctx.strokeStyle = "#9e1c2d";
    ctx.lineWidth = 2;
    roundedRect(ctx, leftX, panelY, panelW, panelH, 12);
    roundedRect(ctx, rightX, panelY, panelW, panelH, 12);

    ctx.fillStyle = "#b71930";
    ctx.fillRect(leftX + 1, panelY + 1, panelW - 2, 58);
    ctx.fillRect(rightX + 1, panelY + 1, panelW - 2, 58);
    ctx.fillStyle = "#fff7ef";
    ctx.font = "900 24px Arial, sans-serif";
    ctx.fillText("POSSIBLE FEATHER BIDDERS", leftX + 26, panelY + 38);
    ctx.fillText("POSSIBLE PUPPET BIDDERS · UP TO 20", rightX + 26, panelY + 38);

    ctx.font = "700 22px Arial, sans-serif";
    feather.forEach((member, index) => {
      const y = panelY + 98 + index * rowHeight;
      ctx.fillStyle = "#ef4658";
      ctx.fillText(`${index + 1}.`, leftX + 30, y);
      ctx.fillStyle = "#f5eee2";
      ctx.fillText(member.name, leftX + 82, y);
    });
    puppet.forEach((member, index) => {
      const y = panelY + 98 + index * rowHeight;
      ctx.fillStyle = "#ef4658";
      ctx.fillText(`${index + 1}.`, rightX + 30, y);
      ctx.fillStyle = "#f5eee2";
      ctx.fillText(member.name, rightX + 82, y);
    });

    const footerY = panelY + panelH + 52;
    ctx.fillStyle = "#f5eee2";
    ctx.font = "900 20px Arial, sans-serif";
    ctx.fillText("SAVE YOUR GOLD", 58, footerY);
    ctx.fillText("PUPPET BIDDERS MAY VARY", 445, footerY);
    ctx.fillText("NOT THE FINAL LIST", 865, footerY);
    ctx.fillStyle = "#bcb6ae";
    ctx.font = "600 16px Arial, sans-serif";
    ctx.fillText("You may be called to bid tomorrow.", 58, footerY + 28);
    ctx.fillText("Final slots depend on event results/ranking.", 445, footerY + 28);
    ctx.fillText("Wait for the official list after the event.", 865, footerY + 28);

    return [{
      title: "POSSIBLE BIDDERS",
      filename: "havoc-possible-bidders.png",
      data: canvas.toDataURL("image/png")
    }];
  }

  function officerName() {
    return currentAdmin || currentAccount?.()?.owner || "Officer";
  }

  async function publishTentative(button) {
    if (!officerSession || accessMode !== "commander") return toast("Officer login is required");
    const event = eventById(selectedEventId);
    if (!event) return toast("Selected event was not found");
    if (event.tentativePublishedAt && !confirm("This Possible Bidders reminder was already published. Publish another Discord notification?")) return;

    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = "Publishing…";
    try {
      await persistState();
      const images = await generateTentativeImage(event);
      const response = await fetch("/api/discord-publish", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${officerSession.access_token}` },
        body: JSON.stringify({ type: "tentative", eventId: event.id, eventName: event.name, eventDate: event.date, images })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Discord notification failed");
      event.tentativePublishedAt = new Date().toISOString();
      event.tentativePublishedBy = officerName();
      await persistState();
      toast("Possible Bidders reminder published to Discord");
      render();
    } catch (error) {
      console.error(error);
      toast(error.message || "Discord notification failed");
    } finally {
      if (button.isConnected) {
        button.disabled = false;
        button.textContent = originalText;
      }
    }
  }

  window.__havocTentativePuppetPlayers = tentativePuppetPlayers;
  window.publishToDiscord = function patchedPublishToDiscord(type, button) {
    if (type === "tentative") return publishTentative(button);
    return originalPublishToDiscord(type, button);
  };
})();