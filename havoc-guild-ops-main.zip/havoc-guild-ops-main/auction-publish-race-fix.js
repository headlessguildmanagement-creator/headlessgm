(() => {
  let bypassNextPublishClick = false;

  document.addEventListener("click", async event => {
    const button = event.target.closest?.("#publish-auction");
    if (!button) return;

    if (bypassNextPublishClick) {
      bypassNextPublishClick = false;
      return;
    }

    event.preventDefault();
    event.stopImmediatePropagation();

    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = "Finishing save…";

    try {
      await Promise.resolve(syncQueue);
      if (window.__havocLastSaveError) {
        const error = window.__havocLastSaveError;
        window.__havocLastSaveError = null;
        throw error;
      }

      bypassNextPublishClick = true;
      button.disabled = false;
      button.textContent = originalText;
      button.click();
    } catch (error) {
      button.disabled = false;
      button.textContent = originalText;
      toast(error?.message || "Auction save did not finish. Refresh before publishing to Discord.");
    }
  }, true);
})();