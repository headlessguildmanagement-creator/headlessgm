import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const source = fs.readFileSync(new URL("../manual-tentative-next20.js", import.meta.url), "utf8");

function players(count, pendingFrom) {
  return Array.from({ length: count }, (_, index) => ({
    id: `p${index + 1}`,
    name: `Player ${index + 1}`,
    active: true,
    puppetOrder: index + 1,
    puppetComplete: index + 1 < pendingFrom,
    auctionGroup: 1
  }));
}

const state = { players: players(30, 22), loas: [], puppetCycle: 1, puppetDeferredTurns: [], puppetAppealQueue: [], puppetCycleHistory: [] };
const event = {
  id: "gl-test",
  date: "2026-09-08",
  callTime: "20:30",
  name: "Guild League",
  activeGroup: 1,
  noShows: [],
  puppetCannotBidIds: [],
  ineligibleFeatherIds: [],
  featherIneligibleReasons: {}
};

const context = {
  window: { publishToDiscord() {} },
  state,
  currentAdmin: "Tester",
  currentAccount: () => ({ owner: "Tester" }),
  officerSession: null,
  accessMode: "commander",
  selectedEventId: event.id,
  eventById: () => event,
  toast() {},
  persistState: async () => {},
  render() {},
  formatDate: value => value,
  document: {},
  confirm: () => true,
  fetch: async () => ({ ok: true, json: async () => ({}) }),
  console
};
vm.createContext(context);
vm.runInContext(source, context);

const ids = rows => Array.from(rows, row => row.id);

const projected = context.window.__havocTentativePuppetPlayers(event);
assert.equal(projected.length, 20);
assert.deepEqual(ids(projected.slice(0, 9)), ["p22","p23","p24","p25","p26","p27","p28","p29","p30"]);
assert.deepEqual(ids(projected.slice(9)), ["p1","p2","p3","p4","p5","p6","p7","p8","p9","p10","p11"]);
assert.equal(new Set(ids(projected)).size, 20);

// Cannot Bid is skipped but does not freeze the projected list.
event.puppetCannotBidIds = ["p25"];
const skipped = context.window.__havocTentativePuppetPlayers(event);
assert.equal(skipped.length, 20);
assert.deepEqual(ids(skipped.slice(0, 8)), ["p22","p23","p24","p26","p27","p28","p29","p30"]);
assert.deepEqual(ids(skipped.slice(8)), ["p1","p2","p3","p4","p5","p6","p7","p8","p9","p10","p11","p12"]);
assert.equal(new Set(ids(skipped)).size, 20);

// LOA is skipped the same way.
event.puppetCannotBidIds = [];
state.loas = [{ eventId: event.id, playerId: "p24", cancelledAt: null }];
const loa = context.window.__havocTentativePuppetPlayers(event);
assert.equal(loa.length, 20);
assert.deepEqual(ids(loa.slice(0, 8)), ["p22","p23","p25","p26","p27","p28","p29","p30"]);
assert.deepEqual(ids(loa.slice(8)), ["p1","p2","p3","p4","p5","p6","p7","p8","p9","p10","p11","p12"]);
assert.equal(new Set(ids(loa)).size, 20);

// An old deferred obligation must appear first when that member is available again.
state.loas = [];
state.puppetDeferredTurns = [{ id:'d1', playerId:'p5', sourceCycle:0, createdAt:'2026-09-01T00:00:00Z', consumedAt:null }];
const withDeferred = context.window.__havocTentativePuppetPlayers(event);
assert.equal(withDeferred[0].id,'p5');
assert.equal(new Set(ids(withDeferred)).size,20);

console.log("Manual tentative next-20 tests passed");