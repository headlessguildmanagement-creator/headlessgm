import assert from 'node:assert/strict';
import { selectPuppetBidders } from '../lib/puppet-cycle.js';

function player(index, complete, addedAt = null) {
  return {
    id: `p${index}`,
    name: `P${index}`,
    active: true,
    puppetOrder: index,
    puppetComplete: complete,
    ...(addedAt ? { memberAddedAt: addedAt } : {})
  };
}

const event = {
  id: 'gl-2026-09-08',
  date: '2026-09-08',
  callTime: '20:30',
  noShows: [],
  puppetCannotBidIds: [],
  ineligibleFeatherIds: [],
  featherIneligibleReasons: {}
};

const players = [];
for (let i = 1; i <= 15; i++) players.push(player(i, true));
for (let i = 16; i <= 20; i++) players.push(player(i, false));
for (let i = 21; i <= 24; i++) players.push(player(i, false, '2026-09-07T10:00:00+08:00'));

const state = {
  puppetCycle: 1,
  players,
  loas: [],
  puppetCycleHistory: [],
  puppetAppealQueue: [],
  puppetDeferredTurns: [],
  puppetNextCycleCredits: []
};

const base = selectPuppetBidders(state, event, 20);
assert.equal(base.assignments.length, 20, 'overview/Discord next-20 should fill to 20');
assert.deepEqual(base.assignments.slice(0, 5).map(x => x.playerId), ['p16','p17','p18','p19','p20'], 'five eligible current-cycle bidders should lead');
assert.deepEqual(base.assignments.slice(5).map(x => x.playerId), Array.from({ length: 15 }, (_, i) => `p${i + 1}`), 'top 15 completed members should fill the next-cycle queue');
assert.equal(base.assignments.some(x => ['p21','p22','p23','p24'].includes(x.playerId)), false, '96H members must be excluded');
assert.equal(base.currentCycleCount, 5);
assert.equal(base.rolloverCount, 15);
assert.equal(base.cycleCanFinish, true);

state.puppetAppealQueue = [{
  appealId: 'appeal-p10',
  playerId: 'p10',
  playerName: 'P10',
  sourceCycle: 1,
  approvedAt: '2026-09-08T09:00:00+08:00',
  consumedAt: null
}];
const withAppeal = selectPuppetBidders(state, event, 20);
assert.equal(withAppeal.assignments.length, 20);
assert.equal(withAppeal.assignments[0].playerId, 'p10', 'approved appeal should be first');
assert.equal(withAppeal.assignments[0].puppetTurnKind, 'appeal');
assert.deepEqual(withAppeal.assignments.slice(1, 6).map(x => x.playerId), ['p16','p17','p18','p19','p20']);
assert.equal(withAppeal.assignments.filter(x => x.puppetTurnKind === 'rollover').length, 14, 'appeal should consume one of the 20 slots');
assert.equal(withAppeal.assignments.some(x => ['p21','p22','p23','p24'].includes(x.playerId)), false);

console.log('Puppet overview/Discord next-20 tests passed');
