import assert from "node:assert/strict";
import fs from "node:fs";
import { selectEventBidders } from "../api/pre-event-bidders.js";

function makePlayers(count, pendingFrom) {
  return Array.from({ length: count }, (_, index) => ({
    id: `p${index + 1}`,
    name: `Player ${index + 1}`,
    active: true,
    auctionGroup: 1,
    puppetOrder: index + 1,
    puppetComplete: index + 1 < pendingFrom,
    puppetCompletedAt: index + 1 < pendingFrom ? "2026-08-23" : null
  }));
}

const event = {
  id: "gl-next20",
  date: "2026-09-10",
  type: "GL",
  activeGroup: 1,
  noShows: [],
  puppetCannotBidIds: [],
  ineligibleFeatherIds: [],
  featherIneligibleReasons: {}
};

const state = { players: makePlayers(30, 22), loas: [], puppetCycle: 1, puppetDeferredTurns: [], puppetAppealQueue: [], puppetNextCycleCredits: [] };
const result = selectEventBidders(state, event, 20);
assert.equal(result.puppetPlayers.length, 20);
assert.deepEqual(result.puppetPlayers.slice(0, 9).map(player => player.id), ["p22","p23","p24","p25","p26","p27","p28","p29","p30"]);
assert.deepEqual(result.puppetPlayers.slice(9).map(player => player.id), ["p1","p2","p3","p4","p5","p6","p7","p8","p9","p10","p11"]);
assert.equal(new Set(result.puppetPlayers.map(player => player.id)).size, 20);

// Cannot Bid skips that member but no longer freezes rollover for everyone else.
const blocked = selectEventBidders(state, { ...event, puppetCannotBidIds: ["p25"] }, 20);
assert.equal(blocked.puppetPlayers.length,20);
assert.ok(!blocked.puppetPlayers.some(player => player.id === 'p25'));
assert.deepEqual(blocked.puppetPlayers.slice(0,8).map(player=>player.id),["p22","p23","p24","p26","p27","p28","p29","p30"]);
assert.deepEqual(blocked.puppetPlayers.slice(8).map(player=>player.id),["p1","p2","p3","p4","p5","p6","p7","p8","p9","p10","p11","p12"]);

const clientSource = fs.readFileSync(new URL("../puppet-cycle-v2.js", import.meta.url), "utf8");
assert.match(clientSource, /NEXT CYCLE BIDDER/);
assert.match(clientSource, /MAKE-UP BIDDER/);
assert.match(clientSource, /CURRENT CYCLE/);
assert.match(clientSource, /puppetDeferredTurns/);

const reminderSource = fs.readFileSync(new URL("../api/pre-event-bidders.js", import.meta.url), "utf8");
assert.match(reminderSource, /const puppetLimit = 20;/);
assert.match(reminderSource, /selectPuppetBidders/);

console.log("Puppet next-20 reminder tests passed");