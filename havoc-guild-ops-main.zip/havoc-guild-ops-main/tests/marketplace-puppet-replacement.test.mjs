import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source=fs.readFileSync(new URL('../puppet-cycle-v2.js',import.meta.url),'utf8');

const players=Array.from({length:10},(_,i)=>({
  id:`p${i+1}`,
  name:i===6?'Seller':i===7?'Gab':i===8?'Tricia':i===9?'Mygo':`P${i+1}`,
  active:true,
  puppetOrder:i+1,
  puppetComplete:false,
  puppetCompletedAt:null
}));
const state={
  puppetCycle:1,
  players,
  loas:[],
  puppetDeferredTurns:[],
  puppetAppealQueue:[],
  puppetCycleHistory:[],
  puppetNextCycleCredits:[]
};
const event={id:'gl-market',date:'2026-09-20',callTime:'20:30',noShows:[],puppetCannotBidIds:[],ineligibleFeatherIds:[],featherIneligibleReasons:{},auction:null};
const deal={id:'sale-7',right_type:'puppet',status:'sold',seller_player_id:'p7',seller_ign:'Seller',buyer_player_id:'p8',buyer_ign:'Gab'};

const sandbox={
  state,
  selectedEventId:event.id,
  currentView:'auctionbuilder',
  accessMode:'commander',
  window:{
    havocMarketplacePuppetDeal:id=>id==='p7'?deal:null,
    havocIsMemberEligibleForEvent:()=>true
  },
  document:{addEventListener:()=>{}},
  eventById:id=>id===event.id?event:null,
  player:id=>players.find(p=>p.id===id),
  slotAt:(index,category,tab)=>({page:Math.floor(index/4)+1,item:index%4+1,category,tab}),
  buildAuction:()=>[],
  buildAuctionFromDistribution:()=>[],
  renderPuppetQueue:()=>'<div></div>',
  formatDate:x=>x,
  esc:x=>String(x),
  toast:()=>{},
  save:()=>{},
  render:()=>{},
  console
};
vm.createContext(sandbox);
vm.runInContext(source,sandbox);

const assignments=sandbox.buildAuction(event,{puppetCount:8}).filter(x=>x.category==='Puppet Fragment');
assert.equal(assignments.length,8);
assert.equal(new Set(assignments.map(x=>x.playerId)).size,8,'each actual bidder must be unique');
const sold=assignments.find(x=>x.marketplaceListingId==='sale-7');
assert.ok(sold,'sold Puppet right must appear in generated assignments');
assert.equal(sold.playerId,'p8','Gab is the actual bidder for Seller');
assert.equal(sold.puppetRotationOwnerId,'p7','Seller remains the rotation owner consumed by the sale');
assert.ok(!assignments.some(x=>x.playerId==='p7'),'Seller must be replaced by the buyer in the published bidder pool');
assert.ok(assignments.some(x=>x.playerId==='p9'),'Tricia must replace Gab natural slot');
assert.ok(!assignments.some(x=>x.puppetRotationOwnerId==='p8'||(!x.puppetRotationOwnerId&&x.playerId==='p8'&&x!==sold)),'Gab natural turn must not also be consumed');

event.auction={assignments};
const result=sandbox.window.__havocPuppetV2Confirm(event);
assert.equal(result.assigned,8);
assert.equal(players.find(p=>p.id==='p7').puppetComplete,true,'Seller turn is DONE');
assert.equal(players.find(p=>p.id==='p8').puppetComplete,false,'Gab natural turn carries forward');
assert.equal(players.find(p=>p.id==='p9').puppetComplete,true,'Tricia replacement uses her natural turn');
assert.equal(players.find(p=>p.id==='p10').puppetComplete,false,'Mygo remains next after Gab');

console.log('Marketplace Puppet replacement scenario passed');
