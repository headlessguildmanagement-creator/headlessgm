import test from "node:test";
import assert from "node:assert/strict";
import { completePastEvents } from "../api/auction-auto-complete.js";

test("recovery completes only past incomplete events and is idempotent", () => {
  const state = {
    players: [],
    events: [
      { id: "past", date: "2026-09-17", type: "GL", activeGroup: 2, auction: { assignments: [], settings: {} }, puppetCannotBidIds: ["x"] },
      { id: "future", date: "2026-09-20", type: "EO", activeGroup: 3, auction: { assignments: [], settings: {} } }
    ],
    featherHistory: [],
    puppetCycle: 1,
    puppetCycleHistory: []
  };
  const first = completePastEvents(state, "2026-09-18", "2026-09-18T01:00:00.000Z", "RECOVERY · Tester");
  assert.deepEqual(first, ["past"]);
  assert.equal(state.events[0].auctionCompletedBy, "RECOVERY · Tester");
  assert.equal(state.events[0].eventCompletedAt, "2026-09-18T01:00:00.000Z");
  assert.deepEqual(state.events[0].puppetCannotBidIds, []);
  assert.equal(state.events[1].eventCompletedAt, undefined);
  const historyCount = state.featherHistory.length;
  const second = completePastEvents(state, "2026-09-18", "2026-09-18T01:01:00.000Z", "RECOVERY · Tester");
  assert.deepEqual(second, []);
  assert.equal(state.featherHistory.length, historyCount);
});