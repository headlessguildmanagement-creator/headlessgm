import assert from 'node:assert/strict';
import fs from 'node:fs';
import { legacyCurrentCycleTurn } from '../lib/puppet-appeals-compat.js';

const state = {
  puppetCycle: 1,
  players: [
    { id: 'done', name: 'DonePlayer', active: true, puppetComplete: true, puppetCompletedAt: '2026-09-06' },
    { id: 'pending', name: 'PendingPlayer', active: true, puppetComplete: false, puppetCompletedAt: null }
  ],
  events: [
    { id: 'eo-2026-09-06', date: '2026-09-06', callTime: '20:30', auction: { assignments: [] } }
  ]
};

assert.ok(legacyCurrentCycleTurn(state, 'done', 'eo-2026-09-06'), 'completed current-cycle member must have a legacy appealable turn');
assert.ok(legacyCurrentCycleTurn(state, 'pending', 'eo-2026-09-06')?.error, 'pending member must be explicitly rejected and must not gain an appeal turn');
assert.ok(legacyCurrentCycleTurn(state, 'done', 'wrong-event')?.error, 'fallback must stay tied to the recorded completion date/event');

const frontend = fs.readFileSync(new URL('../puppet-appeal-legacy-fallback.js', import.meta.url), 'utf8');
assert.match(frontend, /Recorded completion \(Page \/ Item unavailable\)/);
assert.match(frontend, /puppetComplete !== true/);
assert.match(frontend, /__havocEndedPuppetAssignmentsFor/);

const stateStore = fs.readFileSync(new URL('../api/state-store.js', import.meta.url), 'utf8');
assert.match(stateStore, /puppet-appeals-compat/);

const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
assert.ok(html.indexOf('puppet-appeals.js') < html.indexOf('puppet-appeal-legacy-fallback.js'));
assert.ok(html.indexOf('puppet-appeal-legacy-fallback.js') < html.indexOf('puppet-appeal-window.js'));
assert.ok(html.indexOf('puppet-appeal-window.js') < html.indexOf('member-puppet-view.js'));

console.log('Legacy Puppet appeal fallback tests passed');
