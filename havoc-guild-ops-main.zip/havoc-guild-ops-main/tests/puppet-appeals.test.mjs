import assert from 'node:assert/strict';
import fs from 'node:fs';
import { selectPuppetBidders, applyPuppetAssignments } from '../lib/puppet-cycle.js';
import { isAppealWindowOpen } from '../lib/puppet-appeals-compat.js';

function players() {
  return Array.from({length:6},(_,i)=>({
    id:`p${i+1}`, name:`P${i+1}`, active:true, puppetOrder:i+1,
    puppetComplete:i<2, memberAddedAt:'2026-08-01T00:00:00Z'
  }));
}

const event={id:'gl-test',date:'2026-09-10',callTime:'20:30',noShows:[],puppetCannotBidIds:[],ineligibleFeatherIds:[],featherIneligibleReasons:{},auction:null};
const state={
  players:players(),loas:[],puppetCycle:3,puppetDeferredTurns:[],
  puppetCycleHistory:[
    {cycle:2,completedAt:'2026-09-07T12:00:00Z',members:[]},
    {cycle:1,completedAt:'2026-08-20T12:00:00Z',members:[]}
  ],
  puppetAppealQueue:[
    {appealId:'recent',playerId:'p1',sourceCycle:2,approvedAt:'2026-09-08T00:00:00Z',consumedAt:null},
    {appealId:'expired',playerId:'p2',sourceCycle:1,approvedAt:'2026-08-21T00:00:00Z',consumedAt:null}
  ]
};

const selected=selectPuppetBidders(state,event,4);
assert.deepEqual(selected.assignments.map(x=>x.playerId),['p1','p3','p4','p5'],'approved make-up must be before the normal queue when no deferred turn exists');
assert.equal(selected.assignments[0].puppetAppealId,'recent');
assert.ok(!selected.assignments.some(x=>x.puppetAppealId==='expired'),'expired appeals must never be selected');
assert.equal(new Set(selected.assignments.map(x=>x.playerId)).size,selected.assignments.length,'a member cannot receive make-up and normal Puppet in the same event');

assert.equal(isAppealWindowOpen(state,2,new Date('2026-09-10T00:00:00Z')),true);
assert.equal(isAppealWindowOpen(state,2,new Date('2026-09-15T13:00:00Z')),false);

const penaltyPlayers=players().map(p=>({...p,puppetComplete:true}));
penaltyPlayers[5].puppetComplete=false;
penaltyPlayers[5].memberAddedAt='2026-09-09T00:00:00Z';
const penaltyState={players:penaltyPlayers,loas:[],puppetCycle:3,puppetCycleHistory:[],puppetDeferredTurns:[],puppetAppealQueue:[],puppetNextCycleCredits:[]};
const penaltyEvent={...event,id:'gl-penalty'};
const penaltySelection=selectPuppetBidders(penaltyState,penaltyEvent,3);
assert.deepEqual(penaltySelection.assignments.map(x=>x.playerId),['p1','p2','p3'],'excess Puppet fragments must return to queue #1 when only a 96H member remains');
assert.deepEqual(penaltySelection.assignments.map(x=>x.puppetCycleOffset),[1,1,1]);
assert.equal(penaltySelection.cycleCanFinish,true,'96H penalty must not hold the entire cycle open');
penaltyEvent.auction={assignments:penaltySelection.assignments.map((x,i)=>({...x,category:'Puppet Fragment',page:1,item:i+1}))};
const penaltyApplied=applyPuppetAssignments(penaltyState,penaltyEvent,'2026-09-10T13:00:00Z');
assert.equal(penaltyApplied.cycleAdvanced,true,'cycle must advance even though the new member is still under 96H penalty');
assert.equal(penaltyState.puppetCycle,4);
assert.equal(penaltyState.players.find(p=>p.id==='p6').puppetComplete,false,'penalized newcomer remains pending in the new cycle');
assert.equal(penaltyState.players.find(p=>p.id==='p1').puppetComplete,true,'queue #1 excess credit becomes DONE in the new cycle');
assert.ok(penaltyState.puppetCycleHistory[0].members.find(m=>m.playerId==='p6').deferred96h,'history records that the newcomer was skipped by 96H');
assert.equal(penaltyState.puppetDeferredTurns.length,0,'96H must never create an old-cycle make-up debt');
assert.ok(penaltyState.puppetCycleHistory[0].appealOpenUntil,'closed cycle gets a seven-day appeal deadline');

const blockedPlayers=players().map(p=>({...p,puppetComplete:true}));
blockedPlayers[5].puppetComplete=false;
const blockedState={players:blockedPlayers,loas:[{eventId:'gl-blocked',playerId:'p6',cancelledAt:null}],puppetCycle:3,puppetCycleHistory:[],puppetDeferredTurns:[],puppetAppealQueue:[],puppetNextCycleCredits:[]};
const blockedEvent={...event,id:'gl-blocked'};
const blocked=selectPuppetBidders(blockedState,blockedEvent,3);
assert.equal(blocked.rolloverCount,3,'LOA now skips the member and allows the next cycle to continue');
assert.equal(blocked.cycleCanFinish,true);
blockedEvent.auction={assignments:blocked.assignments.map((x,i)=>({...x,category:'Puppet Fragment',page:1,item:i+1}))};
applyPuppetAssignments(blockedState,blockedEvent,'2026-09-10T13:00:00Z');
assert.equal(blockedState.puppetCycle,4);
assert.equal(blockedState.puppetDeferredTurns.filter(x=>x.playerId==='p6'&&!x.consumedAt).length,1,'LOA member carries one old-cycle make-up');

const makeState={players:players().map(p=>({...p,puppetComplete:false})),loas:[],puppetCycle:3,puppetDeferredTurns:[],puppetCycleHistory:[{cycle:2,completedAt:'2026-09-07T12:00:00Z',members:[]}],puppetAppealQueue:[{appealId:'m1',playerId:'p1',sourceCycle:2,approvedAt:'2026-09-08T00:00:00Z',consumedAt:null}]};
const makeEvent={...event,id:'gl-makeup'};
const makeSel=selectPuppetBidders(makeState,makeEvent,1);
assert.equal(makeSel.assignments[0].puppetAppealId,'m1');
makeEvent.auction={assignments:[{...makeSel.assignments[0],category:'Puppet Fragment',page:1,item:1}]};
applyPuppetAssignments(makeState,makeEvent,'2026-09-10T13:00:00Z');
assert.ok(makeState.puppetAppealQueue[0].consumedAt);
assert.equal(makeState.players[0].puppetComplete,false,'old-cycle make-up is not a bonus completion in the new cycle');

const ui=fs.readFileSync(new URL('../puppet-appeals.js',import.meta.url),'utf8');
const windowPatch=fs.readFileSync(new URL('../puppet-appeal-window.js',import.meta.url),'utf8');
const cycleV2=fs.readFileSync(new URL('../puppet-cycle-v2.js',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
assert.match(ui,/1 APPEAL PER CYCLE/);
assert.match(ui,/did <strong>not<\/strong> sell, give, transfer/);
assert.match(ui,/Clear Appeal/,'officer must have a case-to-case appeal reset control');
assert.match(ui,/puppet_appeal_clear/);
assert.match(windowPatch,/7-day appeal window/i);
assert.match(cycleV2,/Complete Make-up/i);
assert.match(cycleV2,/MAKE-UP BIDDER/);
assert.ok(html.includes('puppet-appeal-window.js'));
assert.ok(html.includes('puppet-cycle-v2.js'));

const apiEntry=fs.readFileSync(new URL('../api/state-store.js',import.meta.url),'utf8');
assert.match(apiEntry,/puppet-appeals-compat/,'shared Hobby-plan endpoint must use the compatibility appeal handler');
const compat=fs.readFileSync(new URL('../lib/puppet-appeals-compat.js',import.meta.url),'utf8');
assert.match(compat,/puppet_appeal_clear/,'server must support officer appeal reset');
assert.match(compat,/storage\.from\(BUCKET\)\.remove/,'clearing an appeal must also remove its screenshot object');
const schema=fs.readFileSync(new URL('../supabase/puppet-appeals.sql',import.meta.url),'utf8');
assert.match(schema,/grant select, insert, update, delete on table public\.puppet_appeals to service_role/i);

console.log('Puppet appeal tests passed');