import assert from "node:assert/strict";
import fs from "node:fs";
import { memberEligibilityDate, isMemberEligibleForEvent } from "../lib/member-eligibility.js";

const sundayBeforeCutoff = "2026-09-06T19:00:00+08:00";
assert.equal(memberEligibilityDate(sundayBeforeCutoff), "2026-09-10");
assert.equal(isMemberEligibleForEvent({ active: true, memberAddedAt: sundayBeforeCutoff }, { date: "2026-09-08" }), false);
assert.equal(isMemberEligibleForEvent({ active: true, memberAddedAt: sundayBeforeCutoff }, { date: "2026-09-10" }), true);

const sundayAtCutoff = "2026-09-06T20:30:00+08:00";
assert.equal(memberEligibilityDate(sundayAtCutoff), "2026-09-11");
assert.equal(isMemberEligibleForEvent({ active: true, memberAddedAt: sundayAtCutoff }, { date: "2026-09-10" }), false);
assert.equal(isMemberEligibleForEvent({ active: true, memberAddedAt: sundayAtCutoff }, { date: "2026-09-13" }), true);

const tuesdayBeforeCutoff = "2026-09-08T20:29:00+08:00";
assert.equal(memberEligibilityDate(tuesdayBeforeCutoff), "2026-09-12");
assert.equal(isMemberEligibleForEvent({ active: true, memberAddedAt: tuesdayBeforeCutoff }, { date: "2026-09-10" }), false);
assert.equal(isMemberEligibleForEvent({ active: true, memberAddedAt: tuesdayBeforeCutoff }, { date: "2026-09-13" }), true);

assert.equal(memberEligibilityDate(null), null);
assert.equal(isMemberEligibleForEvent({ active: true, memberAddedAt: null }, { date: "2026-09-13" }), true);

const browserSource = fs.readFileSync(new URL("../member-eligibility.js", import.meta.url), "utf8");
const indexSource = fs.readFileSync(new URL("../index.html", import.meta.url), "utf8");
const manualSource = fs.readFileSync(new URL("../manual-tentative-next20.js", import.meta.url), "utf8");
const officerStateSource = fs.readFileSync(new URL("../api/officer-state.js", import.meta.url), "utf8");
const scheduledReminderSource = fs.readFileSync(new URL("../api/pre-event-bidders.js", import.meta.url), "utf8");

assert.match(browserSource, /if \(value == null \|\| value === ""\) return null/);
assert.match(browserSource, /isPuppetUnavailable = function penaltyAwarePuppetUnavailable/);
assert.match(browserSource, /eligibleFeatherPlayers = function penaltyAwareFeatherPlayers/);
assert.match(browserSource, /96H PENALTY/);
assert.match(browserSource, /INELIGIBLE · 96-HOUR PENALTY/);
assert.match(indexSource, /member-eligibility\.js/);
assert.ok(indexSource.indexOf("puppet-cycle-rollover.js") < indexSource.indexOf("member-eligibility.js"));
assert.ok(indexSource.indexOf("member-eligibility.js") < indexSource.indexOf("manual-tentative-next20.js"));
assert.match(manualSource, /havocIsMemberEligibleForEvent/);
assert.match(officerStateSource, /select\("id,ign,created_at"\)/);
assert.match(officerStateSource, /memberAddedAt:/);
assert.match(scheduledReminderSource, /isMemberEligibleForEvent/);
assert.match(scheduledReminderSource, /select\("id,ign,created_at"\)/);

console.log("Member 96-hour eligibility tests passed");
