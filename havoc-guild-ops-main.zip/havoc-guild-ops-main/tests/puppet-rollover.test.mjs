import assert from "node:assert/strict";
import { completePastEvents } from "../api/auction-auto-complete.js";
import { selectPuppetBidders } from "../lib/puppet-cycle.js";

function players(count, pendingFrom = 1) {
  return Array.from({ length: count }, (_, index) => ({
    id: `p${index + 1}`,
    name: `Player ${index + 1}`,
    active: true,
    puppetOrder: index + 1,
    puppetComplete: index + 1 < pendingFrom,
    puppetCompletedAt: index + 1 < pendingFrom ? "2026-09-01" : null
  }));
}

function event(overrides = {}) {
  return {
    id: "gl-rollover",
    date: "2026-09-10",
    type: "GL",
    activeGroup: 1,
    noShows: [],
    puppetCannotBidIds: [],
    ineligibleFeatherIds: [],
    featherIneligibleReasons: {},
    ...overrides
  };
}

// 12-member rotation, only last 4 remain. Eight fragments should finish the old cycle
// and immediately assign four unique members from the top of the next cycle.
const rolloverState = { players: players(12, 9), loas: [], puppetCycle: 1 };
const rolloverEvent = event();
const rollover = selectPuppetBidders(rolloverState, rolloverEvent, 8);
assert.equal(rollover.assignments.length, 8);
assert.deepEqual(rollover.assignments.slice(0, 4).map(row => row.playerId), ["p9", "p10", "p11", "p12"]);
assert.deepEqual(rollover.assignments.slice(4).map(row => row.playerId), ["p1", "p2", "p3", "p4"]);
assert.deepEqual(rollover.assignments.map(row => row.puppetCycleOffset), [0, 0, 0, 0, 1, 1, 1, 1]);
assert.equal(new Set(rollover.assignments.map(row => row.playerId)).size, 8);
assert.equal(rollover.cycleCanFinish, true);

// No double dipping in one event.
const freshState = { players: players(12, 1), loas: [], puppetCycle: 1 };
const fresh = selectPuppetBidders(freshState, event(), 20);
assert.equal(fresh.assignments.length, 12);
assert.equal(new Set(fresh.assignments.map(row => row.playerId)).size, 12);
assert.ok(fresh.assignments.every(row => row.puppetCycleOffset === 0));

const largeRollover = selectPuppetBidders({ players: players(12, 9), loas: [], puppetCycle: 1 }, event(), 20);
assert.equal(largeRollover.assignments.length, 12);
assert.equal(new Set(largeRollover.assignments.map(row => row.playerId)).size, 12);
assert.equal(largeRollover.currentCycleCount, 4);
assert.equal(largeRollover.rolloverCount, 8);

// Cannot Bid now defers that member instead of freezing the guild.
const skippedState = { players: players(12, 9), loas: [], puppetCycle: 1 };
const skipped = selectPuppetBidders(skippedState, event({ puppetCannotBidIds: ["p10"] }), 8);
assert.deepEqual(skipped.assignments.map(row => row.playerId), ["p9", "p11", "p12", "p1", "p2", "p3", "p4", "p5"]);
assert.equal(skipped.cycleCanFinish, true);
assert.equal(skipped.rolloverCount, 5);
assert.ok(!skipped.assignments.some(row => row.playerId === "p10"));

// Midnight completion must archive/reset Cycle 1 and leave rollover bidders DONE in Cycle 2.
const midnightState = {
  players: players(12, 9),
  loas: [],
  events: [],
  featherHistory: [],
  puppetCycle: 1,
  puppetCycleHistory: [],
  puppetDeferredTurns: [],
  officerRotationIndex: 0
};
const midnightEvent = event({
  auction: {
    settings: {},
    assignments: rollover.assignments.map((row, index) => ({
      category: "Puppet Fragment",
      tab: "Cards",
      page: Math.floor(index / 4) + 1,
      item: index % 4 + 1,
      playerId: row.playerId,
      puppetCycleOffset: row.puppetCycleOffset,
      puppetTurnKind: row.puppetTurnKind,
      puppetSourceCycle: row.puppetSourceCycle
    }))
  }
});
midnightState.events.push(midnightEvent);
assert.deepEqual(completePastEvents(midnightState, "2026-09-11", "2026-09-10T16:00:00.000Z"), ["gl-rollover"]);
assert.equal(midnightState.puppetCycle, 2);
assert.equal(midnightState.puppetCycleHistory.length, 1);
assert.deepEqual(midnightState.players.filter(player => player.puppetComplete).map(player => player.id), ["p1", "p2", "p3", "p4"]);
assert.ok(midnightState.players.slice(4).every(player => player.puppetComplete === false));

console.log("Puppet rollover tests passed");