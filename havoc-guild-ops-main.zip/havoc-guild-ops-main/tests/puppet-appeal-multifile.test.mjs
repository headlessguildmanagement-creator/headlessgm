import assert from 'node:assert/strict';
import fs from 'node:fs';

const patch = fs.readFileSync(new URL('../puppet-appeal-multifile.js', import.meta.url), 'utf8');
const compat = fs.readFileSync(new URL('../lib/puppet-appeals-compat.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');

assert.match(patch, /const MAX_FILES = 20/);
assert.match(patch, /input\.multiple = true/);
assert.match(patch, /1 to \$\{MAX_FILES\} separate/);
assert.match(patch, /screenshotDataUrls/,'client must send separate screenshots, not a contact sheet');
assert.doesNotMatch(patch, /MutationObserver/,'page-wide MutationObserver caused member navigation lag');
assert.doesNotMatch(patch, /buildContactSheet/,'screenshots must remain separate files');
assert.match(patch, /const originalRender = render/,'input should be configured during normal render without observing the whole DOM');
assert.match(patch, /stopImmediatePropagation/);
assert.match(patch, /puppet_appeal_submit/);

assert.match(compat, /MAX_SCREENSHOTS = 20/);
assert.match(compat, /screenshotDataUrls/);
assert.match(compat, /JSON\.stringify\(uploadedPaths\)/,'multiple stored object paths must stay attached to one appeal without a schema-breaking migration');
assert.match(compat, /screenshotUrls/,'officer API must return every uploaded screenshot');
assert.match(compat, /screenshotPaths\(appeal\.screenshot_path\)/,'old single-image and new multi-image appeals must both clean up correctly');

assert.ok(html.includes('puppet-appeal-multifile.js'));
assert.ok(html.indexOf('puppet-appeals.js') < html.indexOf('puppet-appeal-multifile.js'));

console.log('Puppet appeal separate multi-file tests passed');
