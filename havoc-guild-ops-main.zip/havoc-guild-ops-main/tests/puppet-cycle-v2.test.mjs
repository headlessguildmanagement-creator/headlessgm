import assert from 'node:assert/strict';
import { applyPuppetAssignments, selectPuppetBidders } from '../lib/puppet-cycle.js';

function member(id, order, complete = false, extra = {}) {
  return { id, name: id, active: true, puppetOrder: order, puppetComplete: complete, puppetCompletedAt: complete ? '2026-09-01' : null, ...extra };
}

function event(id='gl-test', date='2026-09-10', extra={}) {
  return { id, date, callTime:'20:30', noShows:[], puppetCannotBidIds:[], ineligibleFeatherIds:[], featherIneligibleReasons:{}, ...extra };
}

function slots(assignments) {
  return assignments.map((row, index) => ({ category:'Puppet Fragment', tab:'Cards', page:Math.floor(index/4)+1, item:index%4+1, ...row }));
}

// Deferred old-cycle turn is priority #1, then approved appeal, then normal current cycle.
{
  const state = {
    puppetCycle: 2,
    loas: [],
    puppetDeferredTurns: [{ id:'d1', playerId:'old', playerName:'old', sourceCycle:1, createdAt:'2026-09-01T00:00:00Z', consumedAt:null }],
    puppetAppealQueue: [{ appealId:'a1', playerId:'appeal', playerName:'appeal', sourceCycle:1, approvedAt:'2026-09-02T00:00:00Z', consumedAt:null }],
    puppetCycleHistory: [{ cycle:1, completedAt:'2026-09-07T00:00:00Z' }],
    puppetNextCycleCredits: [],
    players: [member('old',1,false), member('appeal',2,false), member('normal',3,false)]
  };
  const result = selectPuppetBidders(state, event(), 3);
  assert.deepEqual(result.assignments.map(x => [x.playerId,x.puppetTurnKind,x.puppetSourceCycle]), [
    ['old','deferred',1], ['appeal','appeal',1], ['normal','normal',2]
  ]);
}

// Kaito scenario: old Cycle 1 make-up completion must not consume Kaito's normal Cycle 2 turn.
{
  const state = {
    puppetCycle: 2,
    loas: [],
    puppetDeferredTurns: [],
    puppetAppealQueue: [{ appealId:'k-a1', playerId:'Kaito', sourceCycle:1, consumedAt:null }],
    puppetCycleHistory: [{ cycle:1, completedAt:'2026-09-07T00:00:00Z' }],
    puppetNextCycleCredits: [],
    players: [member('Kaito',77,false), member('Jenaissante',78,false)]
  };
  const e = event('gl-kaito');
  e.auction = { assignments: slots([{playerId:'Kaito',puppetTurnKind:'appeal',puppetSourceCycle:1,puppetCycleOffset:0,puppetAppealId:'k-a1'}]) };
  const applied = applyPuppetAssignments(state, e, '2026-09-10T12:00:00Z');
  assert.equal(applied.appealsConsumed,1);
  assert.equal(state.players[0].puppetComplete,false,'old-cycle make-up must not mark current cycle DONE');
  assert.ok(state.puppetAppealQueue[0].consumedAt);
}

// End-of-Cycle-1 + Kaito + final five scenario: final five close Cycle 1, then all begin Cycle 2 pending.
{
  const finalFive = ['Jenaissante','Bam','Trick','Hitch','Lockheart'];
  const players = [member('Kaito',77,true), ...finalFive.map((id,i)=>member(id,78+i,false))];
  const state = {
    puppetCycle:1, loas:[], puppetCycleHistory:[], puppetDeferredTurns:[], puppetNextCycleCredits:[],
    puppetAppealQueue:[{appealId:'ka',playerId:'Kaito',sourceCycle:1,consumedAt:null}], players
  };
  const e = event('gl-close');
  e.auction = { assignments: slots([
    {playerId:'Kaito',puppetTurnKind:'appeal',puppetSourceCycle:1,puppetAppealId:'ka'},
    ...finalFive.map(id=>({playerId:id,puppetTurnKind:'normal',puppetSourceCycle:1}))
  ])};
  const applied = applyPuppetAssignments(state,e,'2026-09-10T12:00:00Z');
  assert.equal(applied.cycleAdvanced,true);
  assert.equal(state.puppetCycle,2);
  assert.ok(state.players.every(p=>p.puppetComplete===false),'all normal Cycle 2 turns should start pending after Cycle 1 closes');
  assert.ok(state.puppetAppealQueue[0].consumedAt);
}

// Ascendum scenario: everyone else DONE, Ascendum LOA. Requested 5 should be #1,#2,#4,#5,#6 for next cycle.
{
  const players = [1,2,3,4,5,6].map(n=>member(`p${n}`,n,n!==3));
  const state = { puppetCycle:1, loas:[{eventId:'gl-asc',playerId:'p3',cancelledAt:null}], puppetCycleHistory:[], puppetDeferredTurns:[], puppetAppealQueue:[], puppetNextCycleCredits:[], players };
  const e = event('gl-asc');
  const selected = selectPuppetBidders(state,e,5);
  assert.deepEqual(selected.assignments.map(x=>x.playerId),['p1','p2','p4','p5','p6']);
  assert.ok(selected.assignments.every(x=>x.puppetTurnKind==='rollover'));
  e.auction = { assignments: slots(selected.assignments) };
  const applied = applyPuppetAssignments(state,e,'2026-09-10T12:00:00Z');
  assert.equal(applied.cycleAdvanced,true);
  assert.equal(state.puppetCycle,2);
  const debt = state.puppetDeferredTurns.find(x=>x.playerId==='p3'&&!x.consumedAt);
  assert.equal(debt.sourceCycle,1);
  assert.equal(debt.reason,'LOA');
  assert.deepEqual(state.players.filter(p=>p.puppetComplete).map(p=>p.id),['p1','p2','p4','p5','p6']);
  assert.equal(state.players.find(p=>p.id==='p3').puppetComplete,false,'Ascendum Cycle 2 normal turn remains pending');

  const next = event('gl-next','2026-09-12');
  const nextSelected = selectPuppetBidders(state,next,3);
  assert.equal(nextSelected.assignments[0].playerId,'p3');
  assert.equal(nextSelected.assignments[0].puppetTurnKind,'deferred');
  assert.equal(nextSelected.assignments[0].puppetSourceCycle,1);
  assert.equal(nextSelected.assignments.filter(x=>x.playerId==='p3').length,1,'old and current turn cannot both be assigned in same event');
}

// 96H: no old-cycle debt is created. Member simply starts in the next cycle once eligible.
{
  const players = [
    member('p1',1,true),
    member('new',2,false,{memberAddedAt:'2026-09-08T13:00:00Z'})
  ];
  const state = { puppetCycle:1, loas:[], puppetCycleHistory:[], puppetDeferredTurns:[], puppetAppealQueue:[], puppetNextCycleCredits:[], players };
  const e = event('gl-96','2026-09-10');
  const selected = selectPuppetBidders(state,e,1);
  assert.equal(selected.assignments[0].playerId,'p1');
  assert.equal(selected.assignments[0].puppetTurnKind,'rollover');
  e.auction = { assignments: slots(selected.assignments) };
  const applied = applyPuppetAssignments(state,e,'2026-09-10T12:00:00Z');
  assert.equal(applied.cycleAdvanced,true);
  assert.equal(state.puppetDeferredTurns.length,0,'96H member must not receive Cycle 1 deferred debt');
  assert.equal(state.players.find(p=>p.id==='new').puppetComplete,false);
}

// 100 varied regressions: unavailable member never freezes rollover, never gets assigned,
// exactly one deferred old-cycle obligation is created, and no duplicate bidder exists.
for (let run=0; run<100; run++) {
  const size = 10;
  const blockedIndex = run % size;
  const reason = run % 3;
  const players = Array.from({length:size},(_,i)=>member(`r${run}-p${i+1}`,i+1,i!==blockedIndex));
  const blockedId = players[blockedIndex].id;
  const e = event(`gl-r${run}`,'2026-09-10');
  const loas = [];
  if (reason===0) loas.push({eventId:e.id,playerId:blockedId,cancelledAt:null});
  if (reason===1) e.puppetCannotBidIds=[blockedId];
  if (reason===2) e.noShows=[blockedId];
  const state = { puppetCycle:1, loas, puppetCycleHistory:[], puppetDeferredTurns:[], puppetAppealQueue:[], puppetNextCycleCredits:[], players };
  const selected = selectPuppetBidders(state,e,5);
  assert.equal(selected.assignments.length,5,`run ${run}: should fill all five slots`);
  assert.equal(new Set(selected.assignments.map(x=>x.playerId)).size,5,`run ${run}: no duplicates`);
  assert.ok(!selected.assignments.some(x=>x.playerId===blockedId),`run ${run}: unavailable member must be skipped`);
  assert.ok(selected.assignments.every(x=>x.puppetTurnKind==='rollover'),`run ${run}: selections should be next-cycle turns`);
  e.auction={assignments:slots(selected.assignments)};
  const applied=applyPuppetAssignments(state,e,`2026-09-10T12:${String(run%60).padStart(2,'0')}:00Z`);
  assert.equal(applied.cycleAdvanced,true,`run ${run}: cycle should advance`);
  const debts=state.puppetDeferredTurns.filter(x=>x.playerId===blockedId&&!x.consumedAt);
  assert.equal(debts.length,1,`run ${run}: exactly one deferred obligation`);
  assert.equal(debts[0].sourceCycle,1);
}


// Marketplace sale: the actual bidder must not consume their own natural turn.
// The original seller/rotation owner is the turn that becomes DONE.
{
  const state = {
    puppetCycle:1, loas:[], puppetCycleHistory:[], puppetDeferredTurns:[], puppetAppealQueue:[], puppetNextCycleCredits:[],
    players:[member('Seller',1,false),member('Buyer',2,false),member('Next',3,false)]
  };
  const e=event('gl-market','2026-09-10');
  e.auction={assignments:slots([{
    playerId:'Buyer',
    puppetRotationOwnerId:'Seller',
    marketplaceListingId:'listing-1',
    marketplaceOriginalPlayerId:'Seller',
    marketplaceBuyerPlayerId:'Buyer',
    marketplaceRightType:'puppet',
    puppetTurnKind:'normal',
    puppetSourceCycle:1
  }])};
  const applied=applyPuppetAssignments(state,e,'2026-09-10T12:00:00Z');
  assert.equal(applied.assigned,1);
  assert.equal(state.players.find(p=>p.id==='Seller').puppetComplete,true,'seller turn must be consumed');
  assert.equal(state.players.find(p=>p.id==='Buyer').puppetComplete,false,'buyer natural turn must remain pending');
}

console.log('Puppet cycle v2 tests passed, including 100 varied rollover regressions');