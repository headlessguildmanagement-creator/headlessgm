import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const patchSource = fs.readFileSync(new URL("../loa-auction-caps-safe.js", import.meta.url), "utf8");
const indexSource = fs.readFileSync(new URL("../index.html", import.meta.url), "utf8");
const apiSource = fs.readFileSync(new URL("../api/public-member-action.js", import.meta.url), "utf8");

const regular = [
  { id: "m1", name: "Member 1" },
  { id: "m2", name: "Member 2" }
];
const officers = [
  { id: "o1", name: "Officer 1" },
  { id: "o2", name: "Officer 2" }
];
const all = [...regular, ...officers];

const baseDistribution = () => ({
  regular,
  baseLd: 4,
  baseTs: 10,
  ldRemainder: 0,
  tsRemainder: 0,
  combinedRemainder: 0,
  bonusRounds: 0,
  equalTotal: 14,
  excessTotal: 0,
  excess: { ld: 0, ts: 0 },
  quotas: {
    m1: { ld: 4, ts: 10, regular: true, extras: [] },
    m2: { ld: 4, ts: 10, regular: true, extras: [] }
  },
  allocations: [],
  startIndex: 0,
  nextIndex: 0,
  nextOfficer: "Officer 1",
  valid: true
});

const context = {
  cutoff: () => new Date(0),
  renderLoa: () => "Everyone attends by default. LOA closes six hours before call time.",
  featherTotals: settings => ({ ld: 8, ts: 20, total: 28, valid: true, ...settings }),
  computeFeatherDistribution: () => baseDistribution(),
  renderCommanderAuctionV2: () => '<form id="auction-form-v2"><div class="toolbar" style="margin:14px 0"><button class="button ghost" type="button" id="recalculate-auction"></button></div></form>',
  confirmAuctionInputs: (_settings, onConfirm) => onConfirm(),
  officerAtRotation: index => ({ player: officers[index % officers.length], index: index % officers.length }),
  OFFICER_ROTATION: officers.map(o => o.name),
  player: id => all.find(p => p.id === id),
  document: { addEventListener() {}, querySelector() { return null; } },
  FormData: class {},
  toast() {},
  eventById() { return null; },
  selectedEventId: null,
  state: { officerRotationIndex: 0 },
  save() {},
  render() {},
  window: {}
};

vm.createContext(context);
vm.runInContext(patchSource, context);

const deadline = context.cutoff({ date: "2026-09-17" });
assert.equal(deadline.toISOString(), "2026-09-17T11:30:00.000Z");

const capped = context.computeFeatherDistribution({}, {
  ld: 8,
  ts: 20,
  total: 28,
  valid: true,
  maxLdPerBidder: 4,
  maxTsPerBidder: 8
}, 0);

assert.equal(capped.quotas.m1.ld, 4);
assert.equal(capped.quotas.m1.ts, 8);
assert.equal(capped.quotas.m2.ld, 4);
assert.equal(capped.quotas.m2.ts, 8);
assert.equal(capped.excess.ts, 4);
assert.equal(capped.excessTotal, 4);
assert.equal(capped.quotas.o1.ts, 2);
assert.equal(capped.quotas.o2.ts, 2);
assert.equal(capped.allocations.length, 28);
assert.equal(capped.nextIndex, 0);

const saturated = context.computeFeatherDistribution({}, {
  ld: 8,
  ts: 20,
  total: 28,
  valid: true,
  maxLdPerBidder: 4,
  maxTsPerBidder: 1
}, 0);

assert.equal(saturated.quotas.m1.ts, 1);
assert.equal(saturated.quotas.m2.ts, 1);
assert.equal(saturated.quotas.o1.ts, 1);
assert.equal(saturated.quotas.o2.ts, 1);
assert.equal(saturated.unassignedExcess.ts, 16);
assert.equal(saturated.unassignedExcessTotal, 16);
assert.equal(saturated.valid, false);
for (const quota of Object.values(saturated.quotas)) {
  assert.ok((quota.ts || 0) <= 1, "No member or officer may exceed the T/S cap");
}

assert.match(indexSource, /loa-auction-caps-safe\.js/);
assert.ok(indexSource.indexOf("loa-auction-caps-safe.js") > indexSource.indexOf("officer-preview-overview.js"));
assert.match(apiSource, /T19:30:00\+08:00/);
assert.match(patchSource, /MAX L\/D PER REGULAR BIDDER/);
assert.match(patchSource, /MAX T\/S PER REGULAR BIDDER/);
assert.match(patchSource, /originalRenderCommanderAuctionV2/);
assert.match(patchSource, /querySelector\?\.\("#auction-form-v2"\)/);
assert.match(patchSource, /name="maxLdPerBidder"/);
assert.match(patchSource, /name="maxTsPerBidder"/);

console.log("Safe LOA and Feather cap patch tests passed");
