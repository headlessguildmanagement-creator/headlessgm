import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import { buildBiddersSvg, confirmedGroupForDate, selectEventBidders } from "../api/pre-event-bidders.js";
import { completePastEvents } from "../api/auction-auto-complete.js";
import { canDeleteRosterMember, isCanonicalAdministrator, scrubPlayer } from "../api/admin-users.js";
import { memberRows, publicGuildState, sanitizeOfficerState } from "../api/officer-state.js";
import { normalizeIgn, validateIgnChange } from "../api/public-member-action.js";

// Rotation schedule and officer rules.
assert.equal(confirmedGroupForDate("2026-08-27"), 3);
assert.equal(confirmedGroupForDate("2026-09-01"), 2);
assert.equal(confirmedGroupForDate("2026-09-03"), 1);
assert.equal(confirmedGroupForDate("2026-08-30"), 2);
assert.equal(confirmedGroupForDate("2026-09-06"), 3);
assert.equal(isCanonicalAdministrator({ active: true, login_name: "Zonzi" }), true);
assert.equal(isCanonicalAdministrator({ active: true, members: { ign: "OZAWA" } }), true);
assert.equal(isCanonicalAdministrator({ active: true, can_manage_access: true, login_name: "BossRems" }), true);
assert.equal(isCanonicalAdministrator({ active: true, can_manage_access: false, login_name: "BossRems" }), false);
assert.equal(canDeleteRosterMember({ active: true }), true);
assert.equal(canDeleteRosterMember({ active: false }), false);

// State sanitizing and member validation.
const privateState = {
  players: [], events: [], officerAccounts: [{ authUserId: "secret" }], officerReadState: { x: 1 },
  history: [1], lineupHistory: [1], jobChangeLog: [1], accountChangeLog: [1], publicActionLog: [1],
  loas: [], featherHistory: []
};
const sanitized = sanitizeOfficerState(privateState);
assert.equal("officerAccounts" in sanitized, false);
const publicState = publicGuildState(privateState);
for (const key of ["officerAccounts","officerReadState","history","lineupHistory","jobChangeLog","accountChangeLog","publicActionLog"]) assert.equal(key in publicState, false);
assert.ok(Array.isArray(publicState.players));
assert.ok(Array.isArray(publicState.events));
assert.equal(normalizeIgn("  New   Name  "), "New Name");
assert.deepEqual(validateIgnChange("OldName", "NewName", "Renamed in game"), { cleanIgn: "NewName", cleanReason: "Renamed in game" });
assert.match(validateIgnChange("OldName", "oldname", "Renamed").error, /same as the current IGN/);
assert.match(validateIgnChange("OldName", "Taken<Name", "Renamed").error, /unsupported/);
const mirrored = memberRows({ players: [{ dbId: "00000000-0000-0000-0000-000000000001", name: "Renamed", active: true }] });
assert.equal(mirrored[0].id, "00000000-0000-0000-0000-000000000001");
assert.equal(mirrored[0].ign, "Renamed");

// Tentative bidder helper remains valid for the manual publish feature.
const reminderPlayers = Array.from({ length: 20 }, (_, index) => ({ id: `p${index + 1}`, name: `Player ${index + 1}`, active: true, auctionGroup: 2, puppetOrder: index + 1, puppetComplete: false }));
const reminderEvent = { id: "gl-2026-09-01", type: "GL", name: "Guild League", date: "2026-09-01", activeGroup: 2, noShows: ["p2"], ineligibleFeatherIds: ["p3", "p4"], featherIneligibleReasons: { p3: "No Gold", p4: "Absent" } };
const reminderState = { players: reminderPlayers, loas: [{ eventId: reminderEvent.id, playerId: "p1", cancelledAt: null }] };
const reminder = selectEventBidders(reminderState, reminderEvent, 8);
assert.equal(reminder.featherPlayers.length, 16);
assert.deepEqual(reminder.puppetPlayers.map(player => player.id), ["p3","p5","p6","p7","p8","p9","p10","p11"]);
assert.match(buildBiddersSvg({ event: reminderEvent, featherNames: reminder.featherPlayers.map(p => p.name), puppetNames: reminder.puppetPlayers.map(p => p.name), excludedCount: reminder.excludedCount }), /TOMORROW&apos;S TENTATIVE BIDDERS/);

// Integration wiring and deployment gate.
const appSource = fs.readFileSync(new URL("../app.js", import.meta.url), "utf8");
const featureSource = fs.readFileSync(new URL("../features.js", import.meta.url), "utf8");
const hardeningSource = fs.readFileSync(new URL("../state-hardening.js", import.meta.url), "utf8");
const puppetSkipSource = fs.readFileSync(new URL("../puppet-cannot-bid.js", import.meta.url), "utf8");
const vercelConfig = fs.readFileSync(new URL("../vercel.json", import.meta.url), "utf8");
const indexSource = fs.readFileSync(new URL("../index.html", import.meta.url), "utf8");
const resolveLoginSource = fs.readFileSync(new URL("../api/resolve-login.js", import.meta.url), "utf8");
assert.match(appSource, /fetch\("\/api\/officer-state"/);
assert.doesNotMatch(appSource, /from\("guild_app_state"\)\.upsert/);
assert.match(featureSource, /profile: "\/update-account"/);
assert.match(featureSource, /"\/update-job": "profile"/);
assert.match(indexSource, /data-view="profile">Account Changes/);
assert.ok(indexSource.indexOf("state-hardening.js") < indexSource.indexOf("member-edit-safety-patch.js"));
assert.ok(indexSource.indexOf("puppet-cannot-bid.js") > indexSource.indexOf("app.js"));
assert.match(hardeningSource, /expectedVersion/);
assert.match(hardeningSource, /SAVE BLOCKED/);
assert.match(hardeningSource, /\/api\/resolve-login/);
assert.match(hardeningSource, /fetch\("\/api\/officer-state"/);
assert.match(puppetSkipSource, /puppetCannotBidIds/);
assert.match(puppetSkipSource, /Cannot Bid/);
assert.match(puppetSkipSource, /Complete Puppet/);
assert.match(puppetSkipSource, /PUPPET_TENTATIVE_LIMIT = 20/);
assert.match(puppetSkipSource, /NEXT IN LINE/);
assert.match(puppetSkipSource, /NEXT CYCLE BIDDER/);
assert.match(puppetSkipSource, /puppetCycleOffset/);
assert.ok(puppetSkipSource.indexOf("NEXT CYCLE BIDDER") < puppetSkipSource.indexOf("NEXT IN LINE", puppetSkipSource.indexOf("const status")));
assert.match(vercelConfig, /"buildCommand"\s*:\s*"npm test\s*&&/);
assert.match(vercelConfig, /"outputDirectory"\s*:\s*"public"/);
assert.match(resolveLoginSource, /login_email/);
assert.doesNotMatch(resolveLoginSource, /res\.status\(200\)\.json\(\{\s*email:/);

// Puppet pending logic.
const puppetStart = appSource.indexOf("function isPuppetUnavailable");
const puppetEnd = appSource.indexOf("function pendingPuppetPlayers", puppetStart);
const puppetFunctionEnd = appSource.indexOf("\n", puppetEnd);
assert.ok(puppetStart >= 0 && puppetFunctionEnd > puppetEnd);
const puppetContext = { state: { players: reminderPlayers }, isAbsent: (_event, playerId) => ["p1","p2"].includes(playerId), result: null };
vm.runInNewContext(`${appSource.slice(puppetStart, puppetFunctionEnd)}; result=pendingPuppetPlayers(${JSON.stringify(reminderEvent)}).slice(0,8).map(player=>player.id);`, puppetContext);
assert.deepEqual(Array.from(puppetContext.result), ["p3","p5","p6","p7","p8","p9","p10","p11"]);

// Feather allocation math.
const allocationStart = appSource.indexOf("function computeFeatherDistribution");
const allocationEnd = appSource.indexOf("function buildAuctionFromDistribution", allocationStart);
assert.ok(allocationStart >= 0 && allocationEnd > allocationStart);
const regular = Array.from({ length: 20 }, (_, i) => ({ id: `m${i + 1}`, name: `Member ${i + 1}` }));
const officers = Array.from({ length: 8 }, (_, i) => ({ id: `o${i + 1}`, name: `Officer ${i + 1}` }));
const allPlayers = [...regular, ...officers];
const allocationContext = {
  eligibleFeatherPlayers: () => regular,
  officerAtRotation: index => ({ player: officers[index % officers.length], index: index % officers.length }),
  OFFICER_ROTATION: officers.map(o => o.name),
  player: id => allPlayers.find(p => p.id === id),
  result: null
};
vm.runInNewContext(`${appSource.slice(allocationStart, allocationEnd)}; result=computeFeatherDistribution({}, {ld:80,ts:120,total:200}, 0);`, allocationContext);
assert.equal(allocationContext.result.equalTotal, 10);
assert.equal(allocationContext.result.excessTotal, 0);
for (const member of regular) assert.deepEqual({ ld: allocationContext.result.quotas[member.id].ld, ts: allocationContext.result.quotas[member.id].ts }, { ld: 4, ts: 6 });
vm.runInNewContext(`${appSource.slice(allocationStart, allocationEnd)}; result=computeFeatherDistribution({}, {ld:40,ts:133,total:173}, 0);`, allocationContext);
assert.equal(allocationContext.result.equalTotal, 8);
assert.equal(allocationContext.result.excessTotal, 13);
assert.equal(allocationContext.result.allocations.length, 173);

// Auto-complete and Puppet cycle.
const completionState = {
  players: [
    { id: "a", name: "A", active: true, puppetOrder: 1, puppetComplete: true, puppetCompletedAt: "2026-08-27" },
    { id: "b", name: "B", active: true, puppetOrder: 2, puppetComplete: true, puppetCompletedAt: "2026-08-27" },
    { id: "c", name: "C", active: true, puppetOrder: 3, puppetComplete: false, puppetCompletedAt: null }
  ],
  events: [{ id: "gl-old", date: "2026-08-31", type: "GL", activeGroup: 2, auction: { settings: { officerRotationNext: 4 }, assignments: [{ category: "Puppet Fragment", playerId: "c" }] } }],
  featherHistory: [], puppetCycle: 1, puppetCycleHistory: [], officerRotationIndex: 0
};
assert.deepEqual(completePastEvents(completionState, "2026-09-01", "2026-09-01T16:00:00.000Z"), ["gl-old"]);
assert.equal(completionState.officerRotationIndex, 4);
assert.equal(completionState.puppetCycle, 2);
assert.ok(completionState.players.every(player => player.puppetComplete === false));

// Cannot Bid skips that event, carries one old-cycle obligation, and lets the guild advance.
const skipState = {
  players: [
    { id: "skip", name: "Skip Me", active: true, puppetOrder: 1, puppetComplete: false, puppetCompletedAt: null },
    { id: "replacement", name: "Replacement", active: true, puppetOrder: 2, puppetComplete: false, puppetCompletedAt: null }
  ],
  events: [{ id: "gl-skip", date: "2026-08-31", type: "GL", activeGroup: 2, puppetCannotBidIds: ["skip"], auction: { settings: {}, assignments: [{ category: "Puppet Fragment", playerId: "replacement" }] } }],
  featherHistory: [], puppetCycle: 1, puppetCycleHistory: [], puppetDeferredTurns: [], officerRotationIndex: 0
};
assert.deepEqual(completePastEvents(skipState, "2026-09-01", "2026-09-01T16:00:00.000Z"), ["gl-skip"]);
assert.equal(skipState.puppetCycle, 2);
assert.equal(skipState.players[0].puppetComplete, false);
assert.equal(skipState.players[1].puppetComplete, false);
assert.equal(skipState.puppetDeferredTurns.length, 1);
assert.equal(skipState.puppetDeferredTurns[0].playerId, "skip");
assert.equal(skipState.puppetDeferredTurns[0].sourceCycle, 1);
assert.equal(skipState.puppetDeferredTurns[0].reason, "CANNOT_BID");
assert.deepEqual(skipState.events[0].puppetCannotBidIds, []);

// Member deletion scrub.
const deletionState = {
  players: [{ id: "gone", name: "Gone" }, { id: "stay", name: "Stay" }],
  loas: [{ playerId: "gone" }, { playerId: "stay" }], jobChangeLog: [{ playerId: "gone" }], accountChangeLog: [{ playerId: "gone" }], publicActionLog: [{ playerId: "gone" }],
  history: [{ playerId: "gone" }], lineupHistory: [{ details: { playerId: "gone" } }], puppetCycleHistory: [{ members: [{ playerId: "gone", name: "Gone" }, { playerId: "stay", name: "Stay" }] }],
  events: [{ lineups: { main: [["gone","stay"]], sub: [[null]] }, noShows: ["gone"], ineligibleFeatherIds: ["gone"], featherIneligibleReasons: { gone: "Absent" }, auction: { settings: { playerQuotas: { gone: { ld: 1 }, stay: { ld: 1 } } }, assignments: [{ playerId: "gone" }, { playerId: "stay" }] } }]
};
scrubPlayer(deletionState, "gone", "Gone");
assert.deepEqual(deletionState.players.map(p => p.id), ["stay"]);
assert.equal(deletionState.loas.length, 1);
assert.equal(deletionState.accountChangeLog.length, 0);
assert.equal(deletionState.events[0].auction.assignments.length, 1);
assert.equal(deletionState.events[0].auction.settings.playerQuotas.gone, undefined);

console.log("HAVOC logic tests passed");