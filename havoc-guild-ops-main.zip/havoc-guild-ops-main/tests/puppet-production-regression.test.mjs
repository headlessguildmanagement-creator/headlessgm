import assert from 'node:assert/strict';
import fs from 'node:fs';

const source=fs.readFileSync(new URL('../puppet-cycle-v2.js',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');

assert.match(source,/function unavailableReason\(/,'frontend must use explicit event unavailability reasons');
assert.match(source,/activeLoa/,'LOA must be recognized');
assert.match(source,/puppetCannotBidIds/,'Cannot Bid must be recognized');
assert.match(source,/noShows/,'No-show must be recognized');
assert.match(source,/is96h/,'96H must remain separate from ordinary unavailability');
assert.match(source,/activeDeferred\(event\).*Priority 1|Priority 1:[\s\S]*activeDeferred\(event\)/,'deferred old-cycle obligations must be selected first');
assert.match(source,/activeAppeals\(event\).*Priority 2|Priority 2:[\s\S]*activeAppeals\(event\)/,'approved appeals must be selected before the normal queue');
assert.match(source,/puppetTurnKind: kind/,'assignments must carry explicit Puppet turn kind');
assert.match(source,/puppetSourceCycle/,'assignments must carry source cycle');
assert.match(source,/MAKE-UP BIDDER · CYCLE/,'UI must show make-up cycle');
assert.match(source,/DONE · CYCLE/,'UI must show current cycle on completed rows');
assert.match(source,/PENDING · CYCLE/,'UI must show current cycle on pending rows');
assert.match(source,/Completing an old-cycle make-up never consumes the member's normal turn in the current cycle/);
assert.ok(!html.includes('puppet-cycle-rollover.js'),'old rollover frontend must not load');
assert.ok(!html.includes('puppet-live-regression-fix.js'),'old hotfix frontend must not load');
assert.ok(html.indexOf('puppet-appeal-window.js') < html.indexOf('marketplace.js'));
assert.ok(html.indexOf('marketplace.js') < html.indexOf('puppet-cycle-v2.js'),'Marketplace deals must load before Puppet selection');
assert.ok(html.indexOf('puppet-cycle-v2.js') < html.indexOf('member-puppet-view.js'));
assert.ok(html.indexOf('loa-auction-caps-safe.js') < html.indexOf('marketplace-auction.js'),'Marketplace auction wrapper must be last');
assert.match(source,/puppetRotationOwnerId/,'Marketplace Puppet assignments must retain the original rotation owner');
assert.match(source,/marketplaceListingId/,'Marketplace Puppet assignments must retain the deal id');

console.log('Puppet production regression tests passed');