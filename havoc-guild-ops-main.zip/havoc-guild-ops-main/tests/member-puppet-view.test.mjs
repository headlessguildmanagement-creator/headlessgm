import assert from 'node:assert/strict';
import fs from 'node:fs';

const patch = fs.readFileSync(new URL('../member-puppet-view.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const appeals = fs.readFileSync(new URL('../puppet-appeals.js', import.meta.url), 'utf8');

assert.match(patch, /accessMode !== 'member'/, 'patch must only expose the member view when appropriate');
assert.match(patch, /data-view="puppet"/, 'member Puppet nav button must be targeted');
assert.match(patch, /classList\.remove\('hidden'\)/, 'Puppet Rotation must be visible in member navigation');
assert.match(patch, /location\.pathname === MEMBER_PUPPET_PATH/, 'direct /puppet-rotation URLs must open in member mode');
assert.match(patch, /currentView = 'puppet'/, 'direct member route must render Puppet Rotation');
assert.match(patch, /const originalRender = render/, 'member visibility must survive normal app re-renders');
assert.doesNotMatch(patch, /save\s*\(|persistState\s*\(|puppetComplete\s*=/, 'member access patch must not mutate Puppet state');

assert.ok(html.indexOf('puppet-appeals.js') < html.indexOf('member-puppet-view.js'), 'appeal renderer must load before the member access patch');
assert.ok(html.indexOf('member-puppet-view.js') < html.indexOf('nav-compact.js'), 'member Puppet visibility must be established before compact navigation groups are built');
assert.match(appeals, /Read-only Puppet Rotation/, 'member Puppet Rotation remains read-only');

console.log('Member Puppet view tests passed');
