(() => {
  function appealPageBody() {
    const memberForm = typeof window.__havocRenderPuppetAppealForm === 'function'
      ? window.__havocRenderPuppetAppealForm()
      : document.createElement('div').outerHTML;
    if (accessMode === 'commander') {
      setTimeout(() => window.__havocLoadOfficerAppeals?.(), 0);
      return `<div class="card"><div class="section-head"><div><p class="eyebrow">PUPPET APPEALS</p><h2>Appeal Review</h2><p>Review member evidence, approve or reject make-up turns, and keep Puppet Rotation focused on the active queue.</p></div><span class="pill amber">OFFICER REVIEW</span></div></div><div class="card" id="puppet-appeals-panel"><div class="empty-state">Loading appeals…</div></div>`;
    }
    return `<div class="card"><div class="section-head"><div><p class="eyebrow">PUPPET APPEALS</p><h2>Submit an Appeal</h2><p>Appeals are separate from the Puppet Rotation. Submit proof here and track the recorded result through the guild appeal process.</p></div><span class="pill purple">MEMBER</span></div></div>${memberForm}`;
  }

  // Puppet appeal implementation exports are added by puppet-appeals.js below.
  window.renderPuppetAppealsPage = appealPageBody;

  const originalRender = render;
  render = function puppetAppealsNavigationRender() {
    if (currentView !== 'puppetappeals') return originalRender();
    const login=document.querySelector("#officer-login-trigger"),logout=document.querySelector("#officer-logout"),changePassword=document.querySelector("#officer-change-password");
    login?.classList.toggle("hidden",accessMode==="commander");
    logout?.classList.toggle("hidden",accessMode!=="commander");
    changePassword?.classList.toggle("hidden",accessMode!=="commander");
    document.querySelectorAll("#nav button").forEach(button => {
      const view=button.dataset.view;
      button.classList.toggle("active",view===currentView);
    });
    const eyebrow=document.querySelector("#page-eyebrow"), title=document.querySelector("#page-title");
    if (eyebrow) eyebrow.textContent='REWARD ROTATION';
    if (title) title.textContent='Puppet Appeals';
    document.querySelector("#app").innerHTML=appealPageBody();
    bindView();
  };

  function exposeNav() {
    const nav=document.querySelector("#nav");
    if (!nav || nav.querySelector('[data-view="puppetappeals"]')) return;
    const puppet=nav.querySelector('[data-view="puppet"]');
    const button=document.createElement('button');
    button.dataset.view='puppetappeals';
    button.textContent='Puppet Appeals';
    puppet?.after(button);
    button.addEventListener('click', () => { currentView='puppetappeals'; history.replaceState({},'', '/puppet-appeals'); render(); });
  }

  const observer=new MutationObserver(exposeNav);
  observer.observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener('load',exposeNav);
  exposeNav();

  if (location.pathname === '/puppet-appeals') currentView='puppetappeals';
})();