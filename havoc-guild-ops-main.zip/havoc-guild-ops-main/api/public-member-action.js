import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";
import { conflictPayload, readGuildState, saveGuildState } from "./state-store.js";
import { isPreviewEnvironment } from "../lib/environment-scope.js";

const JOBS = new Set(["Assassin Cross", "Biochemist", "Champion", "Gypsy", "High Priest", "High Wizard", "Lord Knight", "Minstrel", "Paladin", "Professor", "Rebellion", "Sniper", "Stalker", "Summoner", "Whitesmith"]);
const ROLES = new Set(["DPS", "Support", "Utility"]);
const IGN_PATTERN = /^[A-Za-z0-9]+$/;

export function normalizeIgn(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 40);
}

export function validateIgnChange(currentIgn, nextIgn, reason) {
  const cleanIgn = normalizeIgn(nextIgn);
  const cleanReason = String(reason || "").trim().slice(0, 500);
  if (cleanIgn.length < 2) return { error: "Enter a valid new IGN" };
  if (!IGN_PATTERN.test(cleanIgn)) return { error: "IGN contains unsupported characters. Only English letters A-Z and numbers 0-9 are allowed." };
  if (cleanReason.length < 3) return { error: "Please enter a reason or note for the IGN change" };
  if (cleanIgn.toLowerCase() === String(currentIgn || "").toLowerCase()) return { error: "The new IGN is the same as the current IGN" };
  return { cleanIgn, cleanReason };
}

function eventTime(event) {
  return new Date(`${event.date}T${event.callTime || "20:30"}:00+08:00`);
}

function removeFromLineups(event, playerId) {
  for (const raid of ["main", "sub"]) {
    event.lineups?.[raid]?.forEach(party => party.forEach((id, index) => {
      if (id === playerId) party[index] = null;
    }));
  }
}

async function postLoaWebhook(action, event, player, reason) {
  if (isPreviewEnvironment()) return;
  const webhook = process.env.DISCORD_LOA_WEBHOOK_URL;
  if (!webhook) return;
  const verb = action === "loa_cancel" ? "cancelled an LOA" : "filed an LOA";
  const response = await fetch(webhook, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: "Havoc Guild Operations",
      content: `**${player.name}** ${verb} for **${event.name} · ${event.date}**.${reason ? `\nReason: ${reason}` : ""}`,
      allowed_mentions: { parse: [] }
    })
  });
  if (!response.ok) throw new Error("The change was saved, but the LOA Discord notification failed");
}

function conflictResponse(res, result) {
  const conflict = conflictPayload(result);
  if (!conflict) return false;
  res.status(409).json(conflict);
  return true;
}

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  if (!process.env.SUPABASE_URL || !serviceKey) return res.status(503).json({ error: "Server storage is not configured" });
  const admin = createClient(process.env.SUPABASE_URL, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
  try {
    const { action, playerId, eventId, loaId, reason, job, role, newIgn } = req.body || {};
    const snapshot = await readGuildState(admin);
    if (!snapshot?.state) return res.status(404).json({ error: "Guild state not found" });
    const state = structuredClone(snapshot.state);
    const expectedVersion = Number(snapshot.version || 1);
    state.loas ??= [];
    state.jobChangeLog ??= [];
    state.accountChangeLog ??= state.jobChangeLog.map(row => ({ ...row, type: "job_change", migratedFromJobChangeLog: true }));
    state.publicActionLog ??= [];
    const player = (state.players || []).find(item => item.id === playerId && item.active !== false);
    if (!player) return res.status(404).json({ error: "Active member not found" });
    const now = new Date().toISOString();
    let event;
    let message;
    let warning;

    if (action === "loa_file") {
      event = (state.events || []).find(item => item.id === eventId);
      if (!event) return res.status(404).json({ error: "Event not found" });
      if (new Date() >= new Date(`${event.date}T19:30:00+08:00`)) return res.status(400).json({ error: "LOA deadline has passed (7:30 PM PHT)" });
      if (state.loas.some(item => item.eventId === event.id && item.playerId === player.id && !item.cancelledAt)) return res.status(409).json({ error: "This member already has an active LOA for the event" });
      const cleanReason = String(reason || "").trim().slice(0, 500);
      if (cleanReason.length < 3) return res.status(400).json({ error: "Please enter an LOA reason" });
      state.loas.push({ id: crypto.randomUUID(), eventId: event.id, playerId: player.id, reason: cleanReason, filedAt: now, cancelledAt: null });
      removeFromLineups(event, player.id);
      event.auction = null;
      delete event.auctionPublishedAt;
      state.publicActionLog.push({ id: crypto.randomUUID(), action, playerId: player.id, playerName: player.name, eventId: event.id, at: now });
      state.publicActionLog = state.publicActionLog.slice(-500);
      const saved = await saveGuildState(admin, { state, expectedVersion, changedBy: player.name, changeKind: "Member filed LOA", syncMembers: false });
      if (conflictResponse(res, saved)) return;
      message = "LOA filed";
      try { await postLoaWebhook(action, event, player, cleanReason); } catch (error) { warning = error.message; }
    } else if (action === "loa_cancel") {
      const loa = state.loas.find(item => item.id === loaId && item.playerId === player.id && !item.cancelledAt);
      if (!loa) return res.status(404).json({ error: "Active LOA not found" });
      event = (state.events || []).find(item => item.id === loa.eventId);
      if (!event) return res.status(404).json({ error: "Event not found" });
      loa.cancelledAt = now;
      event.auction = null;
      delete event.auctionPublishedAt;
      state.publicActionLog.push({ id: crypto.randomUUID(), action, playerId: player.id, playerName: player.name, eventId: event.id, at: now });
      state.publicActionLog = state.publicActionLog.slice(-500);
      const saved = await saveGuildState(admin, { state, expectedVersion, changedBy: player.name, changeKind: "Member cancelled LOA", syncMembers: false });
      if (conflictResponse(res, saved)) return;
      message = "LOA cancelled";
      try { await postLoaWebhook(action, event, player, loa.reason || ""); } catch (error) { warning = error.message; }
    } else if (action === "job_change") {
      const cleanJob = String(job || "");
      const cleanRole = String(role || "");
      const cleanReason = String(reason || "").trim().slice(0, 500);
      if (!JOBS.has(cleanJob) || !ROLES.has(cleanRole)) return res.status(400).json({ error: "Select a valid job and lineup role" });
      if (cleanReason.length < 5) return res.status(400).json({ error: "Please explain the job change" });
      const previousJob = player.job || "Unknown";
      const previousRole = player.role || "Unknown";
      player.job = cleanJob;
      player.role = cleanRole;
      const jobChange = { id: crypto.randomUUID(), type: "job_change", playerId: player.id, playerName: player.name, previousJob, previousRole, newJob: cleanJob, newRole: cleanRole, reason: cleanReason, changedAt: now, submittedPublicly: true };
      state.jobChangeLog.push(jobChange);
      state.accountChangeLog.push({ ...jobChange });
      state.publicActionLog.push({ id: crypto.randomUUID(), action, playerId: player.id, playerName: player.name, at: now });
      state.publicActionLog = state.publicActionLog.slice(-500);
      const saved = await saveGuildState(admin, { state, expectedVersion, changedBy: player.name, changeKind: "Member changed job", syncMembers: true });
      if (conflictResponse(res, saved)) return;
      message = `${player.name} job change submitted`;
    } else if (action === "ign_change") {
      const validated = validateIgnChange(player.name, newIgn, reason);
      if (validated.error) return res.status(400).json({ error: validated.error });
      const { cleanIgn, cleanReason } = validated;
      if ((state.players || []).some(item => item.id !== player.id && item.active !== false && String(item.name || "").toLowerCase() === cleanIgn.toLowerCase())) return res.status(409).json({ error: "That IGN is already used by another active member" });

      const previousIgn = player.name;
      if (isPreviewEnvironment()) {
        player.name = cleanIgn;
        const ignChange = { id: crypto.randomUUID(), type: "ign_change", playerId: player.id, playerName: cleanIgn, previousIgn, newIgn: cleanIgn, reason: cleanReason, changedAt: now, submittedPublicly: true, previewOnly: true };
        state.accountChangeLog.push(ignChange);
        state.publicActionLog.push({ id: crypto.randomUUID(), action, playerId: player.id, playerName: cleanIgn, previousIgn, at: now, previewOnly: true });
        state.publicActionLog = state.publicActionLog.slice(-500);
        const saved = await saveGuildState(admin, { state, expectedVersion, changedBy: cleanIgn, changeKind: `Preview IGN change from ${previousIgn}`, syncMembers: false });
        if (conflictResponse(res, saved)) return;
        return res.status(200).json({ ok: true, message: `${previousIgn} changed IGN to ${cleanIgn} in preview only`, preview: true });
      }
      const { data: dbMember, error: memberLookupError } = await admin.from("members").select("id,ign,auth_user_id").ilike("ign", previousIgn).maybeSingle();
      if (memberLookupError) throw memberLookupError;
      if (!dbMember?.id) return res.status(409).json({ error: "The normalized member record could not be found. Ask an officer to save the roster once, then try again." });
      const { data: duplicate, error: duplicateError } = await admin.from("members").select("id,ign").ilike("ign", cleanIgn).maybeSingle();
      if (duplicateError) throw duplicateError;
      if (duplicate && duplicate.id !== dbMember.id) return res.status(409).json({ error: "That IGN already exists in the member database" });

      const { data: officerProfile, error: officerLookupError } = dbMember.auth_user_id
        ? await admin.from("officer_access_profiles").select("auth_user_id,login_name,active").eq("member_id", dbMember.id).maybeSingle()
        : { data: null, error: null };
      if (officerLookupError) throw officerLookupError;

      const { error: renameMemberError } = await admin.from("members").update({ ign: cleanIgn, updated_at: now }).eq("id", dbMember.id);
      if (renameMemberError) throw renameMemberError;
      let officerUpdated = false;
      try {
        if (officerProfile?.auth_user_id) {
          const { error: profileUpdateError } = await admin.from("officer_access_profiles").update({ login_name: cleanIgn }).eq("member_id", dbMember.id);
          if (profileUpdateError) throw profileUpdateError;
          officerUpdated = true;
          const { data: authUserResult, error: authLookupError } = await admin.auth.admin.getUserById(officerProfile.auth_user_id);
          if (authLookupError) throw authLookupError;
          const metadata = { ...(authUserResult?.user?.user_metadata || {}), havoc_ign: cleanIgn };
          const { error: authUpdateError } = await admin.auth.admin.updateUserById(officerProfile.auth_user_id, { user_metadata: metadata });
          if (authUpdateError) throw authUpdateError;
        }

        player.name = cleanIgn;
        const ignChange = { id: crypto.randomUUID(), type: "ign_change", playerId: player.id, playerName: cleanIgn, previousIgn, newIgn: cleanIgn, reason: cleanReason, changedAt: now, submittedPublicly: true };
        state.accountChangeLog.push(ignChange);
        state.publicActionLog.push({ id: crypto.randomUUID(), action, playerId: player.id, playerName: cleanIgn, previousIgn, at: now });
        state.publicActionLog = state.publicActionLog.slice(-500);
        const saved = await saveGuildState(admin, { state, expectedVersion, changedBy: cleanIgn, changeKind: `Member changed IGN from ${previousIgn}`, syncMembers: false });
        if (saved?.conflict) {
          const conflict = conflictPayload(saved);
          throw Object.assign(new Error(conflict.error), { havocConflict: conflict });
        }
        message = `${previousIgn} changed IGN to ${cleanIgn}`;
      } catch (renameError) {
        await admin.from("members").update({ ign: previousIgn, updated_at: now }).eq("id", dbMember.id);
        if (officerUpdated && officerProfile?.auth_user_id) {
          await admin.from("officer_access_profiles").update({ login_name: officerProfile.login_name || previousIgn }).eq("member_id", dbMember.id);
          try {
            const { data: rollbackUser } = await admin.auth.admin.getUserById(officerProfile.auth_user_id);
            await admin.auth.admin.updateUserById(officerProfile.auth_user_id, { user_metadata: { ...(rollbackUser?.user?.user_metadata || {}), havoc_ign: previousIgn } });
          } catch (_) {}
        }
        if (renameError.havocConflict) return res.status(409).json(renameError.havocConflict);
        throw renameError;
      }
    } else {
      return res.status(400).json({ error: "Unknown action" });
    }

    return res.status(200).json({ ok: true, message, warning });
  } catch (error) {
    console.error("Public member action failed", error);
    return res.status(500).json({ error: error?.message || "Server error" });
  }
}
