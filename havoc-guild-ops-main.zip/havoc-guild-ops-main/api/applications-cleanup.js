import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  const auth = String(req.headers.authorization || "");
  if (!process.env.CRON_SECRET || auth !== `Bearer ${process.env.CRON_SECRET}`) return res.status(401).json({ error: "Unauthorized" });
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  const admin = createClient(process.env.SUPABASE_URL, key, { auth: { autoRefreshToken: false, persistSession: false } });
  const now = new Date().toISOString(), draftCutoff = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();
  try {
    const [{ data: closed, error: closedError }, { data: drafts, error: draftError }] = await Promise.all([
      admin.from("guild_applications").select("id").in("status", ["rejected", "joined"]).lte("purge_after", now),
      admin.from("guild_applications").select("id").eq("status", "draft").lte("updated_at", draftCutoff)
    ]);
    if (closedError) throw closedError; if (draftError) throw draftError;
    const apps = [...(closed || []), ...(drafts || [])], seen = new Set();
    let removed = 0;
    for (const app of apps) {
      if (seen.has(app.id)) continue; seen.add(app.id);
      const { data: files, error: fileError } = await admin.from("guild_application_files").select("storage_path").eq("application_id", app.id);
      if (fileError) throw fileError;
      const paths = (files || []).map(file => file.storage_path).filter(Boolean);
      if (paths.length) { const { error: storageError } = await admin.storage.from("guild-applications").remove(paths); if (storageError) throw storageError; }
      const { error: deleteError } = await admin.from("guild_applications").delete().eq("id", app.id);
      if (deleteError) throw deleteError;
      removed++;
    }
    return res.status(200).json({ ok: true, removed, closedCandidates: (closed || []).length, abandonedDraftCandidates: (drafts || []).length });
  } catch (error) {
    console.error("Application cleanup failed", error);
    return res.status(500).json({ error: error.message || "Cleanup failed" });
  }
}
