import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";
import { handlePuppetAppeals } from "../lib/puppet-appeals-compat.js";
import { handleMarketplace } from "../lib/marketplace.js";
import { handlePublicMarketplace } from "../lib/public-marketplace.js";
export { readGuildState, saveGuildState, conflictPayload } from "../lib/state-store.js";

export default async function handler(req, res) {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  if (!process.env.SUPABASE_URL || !serviceKey) return res.status(503).json({ error: "Server storage is not configured" });
  const admin = createClient(process.env.SUPABASE_URL, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
  if (isPublicSiteProject()) {
    if (req.query?.resource === "public-marketplace") return handlePublicMarketplace(req, res, admin);
    return res.status(404).json({ error: "Not found" });
  }
  if (req.query?.resource === "marketplace") return handleMarketplace(req, res, admin);
  if (req.query?.resource === "public-marketplace") return handlePublicMarketplace(req, res, admin);
  return handlePuppetAppeals(req, res, admin);
}
