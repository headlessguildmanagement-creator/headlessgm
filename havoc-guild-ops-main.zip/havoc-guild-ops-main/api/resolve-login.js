import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const url = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !serviceKey || !publishableKey) return res.status(503).json({ error: "Officer login is not configured" });

  const username = String(req.body?.username || "").trim().slice(0, 180);
  const password = String(req.body?.password || "");
  if (!username || !password) return res.status(400).json({ error: "Username and password are required" });

  const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
  let email = username.includes("@") ? username.toLowerCase() : null;
  if (!email) {
    const { data: profile, error } = await admin
      .from("officer_access_profiles")
      .select("login_email,active")
      .ilike("login_name", username)
      .eq("active", true)
      .maybeSingle();
    if (error) return res.status(500).json({ error: "Officer login lookup failed" });
    if (!profile?.login_email) return res.status(401).json({ error: "Invalid username or password" });
    email = profile.login_email;
  }

  const authClient = createClient(url, publishableKey, { auth: { autoRefreshToken: false, persistSession: false } });
  const { data, error } = await authClient.auth.signInWithPassword({ email, password });
  if (error || !data?.session || !data?.user) return res.status(401).json({ error: "Invalid username or password" });

  const { data: activeProfile, error: profileError } = await admin
    .from("officer_access_profiles")
    .select("active")
    .eq("auth_user_id", data.user.id)
    .maybeSingle();
  if (profileError || !activeProfile?.active) return res.status(403).json({ error: "Officer access is not active" });

  return res.status(200).json({
    ok: true,
    accessToken: data.session.access_token,
    refreshToken: data.session.refresh_token
  });
}
