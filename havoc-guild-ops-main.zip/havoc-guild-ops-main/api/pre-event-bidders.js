import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";
import { readFileSync } from "node:fs";
import { isMemberEligibleForEvent } from "../lib/member-eligibility.js";
import { selectPuppetBidders } from "../lib/puppet-cycle.js";
import { isPreviewEnvironment } from "../lib/environment-scope.js";

const EMBEDDED_FONT = readFileSync(new URL("../assets/DejaVuSans.ttf", import.meta.url)).toString("base64");

const MANILA_TIME_ZONE = "Asia/Manila";
const GL_SEQUENCE = [3, 2, 1, 4];
const EO_SEQUENCE = [2, 3, 4, 1];

function manilaDate(now = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: MANILA_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(now);
}

function utcDay(date) {
  return new Date(`${date}T00:00:00Z`).getUTCDay();
}

function addUtcDay(date, days = 1) {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}

function occurrenceIndex(anchor, date, validDays) {
  let index = 0;
  for (let cursor = addUtcDay(anchor); cursor <= date; cursor = addUtcDay(cursor)) {
    if (validDays.includes(utcDay(cursor))) index++;
  }
  return index;
}

export function confirmedGroupForDate(date) {
  const day = utcDay(date);
  if (day === 0 && date >= "2026-08-30") {
    return EO_SEQUENCE[occurrenceIndex("2026-08-30", date, [0]) % EO_SEQUENCE.length];
  }
  if ([2, 4].includes(day) && date >= "2026-08-27") {
    return GL_SEQUENCE[occurrenceIndex("2026-08-27", date, [2, 4]) % GL_SEQUENCE.length];
  }
  return null;
}

function xml(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;"
  })[character]);
}

function eventLabel(event) {
  return event.type === "EO" ? "EMPERIUM OVERRUN" : "GUILD LEAGUE";
}

function displayDate(date) {
  return new Intl.DateTimeFormat("en-PH", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: MANILA_TIME_ZONE
  }).format(new Date(`${date}T12:00:00+08:00`));
}

function emptyRaid() {
  return Array.from({ length: 8 }, () => Array(5).fill(null));
}

function createEvent(date, day) {
  const type = day === 0 ? "EO" : "GL";
  return { id: `${type.toLowerCase()}-${date}`, type, name: type === "EO" ? "Emperium Overrun" : "Guild League", date, callTime: "20:30", activeGroup: confirmedGroupForDate(date), finalized: false, noShows: [], ineligibleFeatherIds: [], featherIneligibleReasons: {}, lineups: { main: emptyRaid(), sub: emptyRaid() }, auction: null, remainderDistributionVersion: 2 };
}

function nameRows(names, x, startY, width, columns = 1) {
  const gap = 18;
  const columnWidth = (width - gap * (columns - 1)) / columns;
  const rows = Math.ceil(names.length / columns);
  return names.map((name, index) => {
    const column = Math.floor(index / rows);
    const row = index % rows;
    const left = x + column * (columnWidth + gap);
    const top = startY + row * 58;
    return `<g><rect x="${left}" y="${top}" width="${columnWidth}" height="46" rx="10" fill="#1b1c22" stroke="#343640"/><circle cx="${left + 28}" cy="${top + 23}" r="15" fill="#8f1d2c"/><text x="${left + 28}" y="${top + 29}" text-anchor="middle" class="rank">${index + 1}</text><text x="${left + 55}" y="${top + 30}" class="name">${xml(name)}</text></g>`;
  }).join("");
}

export function buildBiddersSvg({ event, featherNames, puppetNames, excludedCount = 0 }) {
  const width = 1600;
  const height = 1120;
  const leftX = 62;
  const rightX = 822;
  const panelWidth = 716;
  const puppetColumns = puppetNames.length > 10 ? 2 : 1;
  const featherColumns = featherNames.length > 10 ? 2 : 1;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
  <defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#090a0e"/><stop offset="1" stop-color="#231014"/></linearGradient></defs>
  <style>@font-face{font-family:HAVOCFont;src:url(data:font/ttf;base64,${EMBEDDED_FONT})}.eyebrow{font:800 23px HAVOCFont,sans-serif;letter-spacing:3px;fill:#ef4658}.title{font:900 54px HAVOCFont,sans-serif;fill:#f5eee2}.subtitle{font:600 25px HAVOCFont,sans-serif;fill:#b8b2aa}.panelTitle{font:900 29px HAVOCFont,sans-serif;fill:#f5eee2}.panelSub{font:700 20px HAVOCFont,sans-serif;fill:#f0a342}.name{font:700 20px HAVOCFont,sans-serif;fill:#f5eee2}.rank{font:900 16px HAVOCFont,sans-serif;fill:#fff}.footer{font:600 18px HAVOCFont,sans-serif;fill:#aaa6a0}.badge{font:900 20px HAVOCFont,sans-serif;fill:#fff}</style>
  <rect width="1600" height="1120" fill="url(#bg)"/><rect width="16" height="1120" fill="#c51f35"/>
  <text x="62" y="62" class="eyebrow">HAVOC GUILD OPERATIONS</text>
  <text x="62" y="126" class="title">TOMORROW&apos;S TENTATIVE BIDDERS</text>
  <text x="62" y="169" class="subtitle">${xml(eventLabel(event))} · ${xml(displayDate(event.date))}</text>
  <rect x="1292" y="62" width="246" height="62" rx="31" fill="#c51f35"/><text x="1415" y="102" text-anchor="middle" class="badge">FEATHER GROUP ${event.activeGroup}</text>
  <rect x="${leftX}" y="212" width="${panelWidth}" height="806" rx="22" fill="#111218" stroke="#383943" stroke-width="2"/>
  <text x="${leftX + 30}" y="262" class="panelTitle">FEATHER GROUP ${event.activeGroup}</text>
  <text x="${leftX + 30}" y="296" class="panelSub">TENTATIVE FEATHER BIDDERS · ${featherNames.length}</text>
  ${featherNames.length ? nameRows(featherNames, leftX + 30, 332, panelWidth - 60, featherColumns) : `<text x="${leftX + 30}" y="370" class="subtitle">No eligible Feather bidders recorded.</text>`}
  <rect x="${rightX}" y="212" width="${panelWidth}" height="806" rx="22" fill="#111218" stroke="#383943" stroke-width="2"/>
  <text x="${rightX + 30}" y="262" class="panelTitle">NEXT IN LINE FOR PUPPET ROTATION</text>
  <text x="${rightX + 30}" y="296" class="panelSub">${puppetNames.length} TENTATIVE PUPPET BIDDERS</text>
  ${puppetNames.length ? nameRows(puppetNames, rightX + 30, 332, panelWidth - 60, puppetColumns) : `<text x="${rightX + 30}" y="370" class="subtitle">No eligible Puppet bidders recorded.</text>`}
  <text x="62" y="1045" class="footer">TENTATIVE LIST · Eligibility reflects records saved before 3:00 PM PHT.${excludedCount ? ` ${excludedCount} unavailable bidder${excludedCount === 1 ? " was" : "s were"} excluded.` : ""}</text>
  <text x="62" y="1073" class="panelSub">If you are part of this list, kindly save up some Gold for tomorrow&apos;s auction.</text>
  <text x="62" y="1103" class="footer">Note: This is a tentative list and may vary depending on the attendance or attendees of the event.</text>
  </svg>`;
}

export function selectEventBidders(state, event, puppetLimit = 20) {
  const unavailable = new Set([...(event.noShows || []), ...(event.puppetCannotBidIds || [])]);
  for (const loa of state.loas || []) {
    if (loa.eventId === event.id && !loa.cancelledAt) unavailable.add(loa.playerId);
  }
  for (const playerId of event.ineligibleFeatherIds || []) {
    if (event.featherIneligibleReasons?.[playerId] === "Absent") unavailable.add(playerId);
  }
  for (const member of state.players || []) {
    if (member.active && !isMemberEligibleForEvent(member, event)) unavailable.add(member.id);
  }
  const featherBlocked = new Set([...(event.ineligibleFeatherIds || []), ...unavailable]);
  const featherPlayers = (state.players || [])
    .filter(player => player.active && player.auctionGroup === event.activeGroup && !featherBlocked.has(player.id))
    .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));

  const limit = Math.max(0, Math.floor(Number(puppetLimit) || 0));
  const selected = selectPuppetBidders(state, event, limit).assignments;
  const playersById = new Map((state.players || []).map(player => [player.id, player]));
  const puppetPlayers = selected.map(row => playersById.get(row.playerId)).filter(Boolean);

  return { featherPlayers, puppetPlayers, excludedCount: unavailable.size };
}

async function postDiscord(webhookUrl, payload, png) {
  const form = new FormData();
  form.append("payload_json", JSON.stringify(payload));
  form.append("files[0]", new Blob([png], { type: "image/png" }), "havoc-tomorrow-tentative-bidders.png");
  const response = await fetch(`${webhookUrl}${webhookUrl.includes("?") ? "&" : "?"}wait=true`, { method: "POST", body: form });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.message || "Discord rejected the pre-event bidders announcement");
  return body;
}

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
  const expected = process.env.CRON_SECRET;
  const supplied = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!expected || supplied !== expected) return res.status(401).json({ error: "Invalid cron authorization" });
  if (isPreviewEnvironment()) return res.status(200).json({ ok: true, sent: false, preview: true, reason: "Preview mode: pre-event Discord send suppressed" });
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) return res.status(503).json({ error: "Supabase server environment variables are not configured" });
  if (!process.env.DISCORD_AUCTION_WEBHOOK_URL) return res.status(503).json({ error: "DISCORD_AUCTION_WEBHOOK_URL is not configured in Vercel" });
  if (!process.env.PUBLIC_SITE_URL) return res.status(503).json({ error: "PUBLIC_SITE_URL is not configured in Vercel" });

  const today = manilaDate();
  const eventDate = addUtcDay(today, 1);
  const day = utcDay(eventDate);
  if (![0, 2, 4].includes(day)) return res.status(200).json({ ok: true, sent: false, reason: "No HAVOC event tomorrow" });
  const admin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { autoRefreshToken: false, persistSession: false } });
  const { data, error } = await admin.from("guild_app_state").select("state").eq("id", true).maybeSingle();
  if (error) return res.status(500).json({ error: error.message });
  if (!data?.state) return res.status(200).json({ ok: true, sent: false, reason: "No guild state found" });

  const state = structuredClone(data.state);
  const { data: memberRows, error: memberError } = await admin.from("members").select("id,ign,created_at").eq("active", true);
  if (memberError) return res.status(500).json({ error: memberError.message });
  const membersById = new Map((memberRows || []).map(row => [String(row.id), row]));
  const membersByIgn = new Map((memberRows || []).map(row => [String(row.ign || "").toLowerCase(), row]));
  state.players = (state.players || []).map(player => {
    const row = (player.dbId && membersById.get(String(player.dbId))) || membersByIgn.get(String(player.name || "").toLowerCase());
    return { ...player, memberAddedAt: row?.created_at || player.memberAddedAt || null };
  });
  state.events ??= [];
  let event = state.events.find(item => item.date === eventDate && item.type === (day === 0 ? "EO" : "GL"));
  if (!event) {
    event = createEvent(eventDate, day);
    state.events.push(event);
    state.events.sort((a, b) => a.date.localeCompare(b.date));
  }
  if (event.preEventReminderSentAt) return res.status(200).json({ ok: true, sent: false, reason: "Reminder already sent", eventId: event.id });
  event.activeGroup = confirmedGroupForDate(eventDate) ?? event.activeGroup;
  const puppetLimit = 20;
  const { featherPlayers, puppetPlayers, excludedCount } = selectEventBidders(state, event, puppetLimit);
  const svg = buildBiddersSvg({ event, featherNames: featherPlayers.map(player => player.name), puppetNames: puppetPlayers.map(player => player.name), excludedCount });
  const { default: sharp } = await import("sharp");
  const png = await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toBuffer();
  const site = process.env.PUBLIC_SITE_URL.replace(/\/+$/, "");
  const link = `${site}/?event=${encodeURIComponent(event.id)}`;
  const tentativeNote = "Note: This is a tentative list and may vary depending on the attendance or attendees of the event.";
  const description = `TENTATIVE LIST FOR TOMORROW\n${event.name} · ${displayDate(event.date)}\nFeather Group ${event.activeGroup}: ${featherPlayers.length} tentative bidders\nNext in Line for Puppet Rotation: ${puppetPlayers.length}\n\nIf you are part of this list, kindly save up some Gold for tomorrow's auction.\n\n${tentativeNote}\n\nView the live HAVOC website:\n${link}`;
  const payload = {
    username: "Havoc Guild Operations",
    content: `📢 **Tentative bidders for tomorrow**\nIf you are part of this list, kindly save up some Gold for tomorrow's auction.\n\n**${tentativeNote}**\n\n🔗 **View the event:**\n${link}`,
    allowed_mentions: { parse: [] },
    embeds: [{ title: "HAVOC · Tomorrow's Tentative Bidders", description, url: link, color: 12918581, timestamp: new Date().toISOString(), image: { url: "attachment://havoc-tomorrow-tentative-bidders.png" } }]
  };
  const discord = await postDiscord(process.env.DISCORD_AUCTION_WEBHOOK_URL, payload, png);
  event.preEventReminderSentAt = new Date().toISOString();
  event.preEventBiddersMessageId = discord.id || null;
  event.preEventBiddersPuppetCount = puppetPlayers.length;
  event.preEventBiddersGroup = event.activeGroup;
  const { error: saveError } = await admin.from("guild_app_state").upsert({ id: true, state, updated_at: new Date().toISOString() }, { onConflict: "id" });
  if (saveError) return res.status(500).json({ error: saveError.message, discordSent: true });
  return res.status(200).json({ ok: true, sent: true, eventId: event.id, group: event.activeGroup, featherBidders: featherPlayers.length, puppetBidders: puppetPlayers.length, messageId: discord.id || null });
}