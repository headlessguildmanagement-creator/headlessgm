import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";

const BUCKET = "guild-applications";
function client() { const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY; if (!process.env.SUPABASE_URL || !key) throw new Error("Supabase server configuration is missing"); return createClient(process.env.SUPABASE_URL, key, { auth: { autoRefreshToken: false, persistSession: false } }); }
async function requireOfficer(admin, req) { const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, ""); if (!token) return null; const { data: { user }, error } = await admin.auth.getUser(token); if (error || !user) return null; const { data: profile } = await admin.from("officer_access_profiles").select("active,login_name,members:member_id(ign)").eq("auth_user_id", user.id).maybeSingle(); if (!profile?.active) return null; return { user, name: profile.login_name || profile.members?.ign || "Officer" }; }
async function addFilesAndMessages(admin, rows) {
  const ids = rows.map(row => row.id); if (!ids.length) return rows;
  const [{ data: files, error: fileError }, { data: messages, error: messageError }] = await Promise.all([
    admin.from("guild_application_files").select("id,application_id,storage_path,original_name,content_type,size_bytes,revision,attachment_group,message_id,created_at").in("application_id", ids).order("created_at"),
    admin.from("guild_application_messages").select("id,application_id,sender_type,sender_name,message,created_at").in("application_id", ids).order("created_at")
  ]);
  if (fileError) throw fileError; if (messageError) throw messageError;
  const byApp = new Map(), msgByApp = new Map();
  for (const file of files || []) { const { data } = await admin.storage.from(BUCKET).createSignedUrl(file.storage_path, 3600); if (!byApp.has(file.application_id)) byApp.set(file.application_id, []); byApp.get(file.application_id).push({ ...file, url: data?.signedUrl || null }); }
  for (const msg of messages || []) { if (!msgByApp.has(msg.application_id)) msgByApp.set(msg.application_id, []); msgByApp.get(msg.application_id).push(msg); }
  return rows.map(row => ({ ...row, files: byApp.get(row.id) || [], messages: msgByApp.get(row.id) || [] }));
}

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const admin = client();
  try {
    const officer = await requireOfficer(admin, req); if (!officer) return res.status(403).json({ error: "Officer access required" });
    const { action } = req.body || {};
    if (action === "list") { const { data, error } = await admin.from("guild_applications").select("*").neq("status", "draft").order("submitted_at", { ascending: false }).limit(250); if (error) throw error; const applications = await addFilesAndMessages(admin, data || []); return res.status(200).json({ ok: true, applications, newCount: applications.filter(row => row.status === "new").length }); }
    if (action === "send_message") {
      const id = String(req.body.id || ""), message = String(req.body.message || "").trim().slice(0, 3000); if (!message) return res.status(400).json({ error: "Enter a message." });
      const { data: app, error } = await admin.from("guild_applications").select("*").eq("id", id).maybeSingle(); if (error) throw error; if (!app) return res.status(404).json({ error: "Application not found" }); if (["rejected", "joined"].includes(app.status)) return res.status(409).json({ error: "This conversation is closed." });
      const { error: messageError } = await admin.rpc("post_application_message_with_attachments", { p_application_id: id, p_sender_type: "officer", p_sender_name: officer.name, p_message: message, p_attachment_group: null }); if (messageError) throw messageError;
      return res.status(200).json({ ok: true });
    }
    if (action === "set_status") {
      const id = String(req.body.id || ""), status = String(req.body.status || ""), feedback = String(req.body.feedback || "").trim().slice(0, 3000);
      if (!["pending", "approved", "rejected"].includes(status)) return res.status(400).json({ error: "Invalid application status" });
      const { data: app, error: lookupError } = await admin.from("guild_applications").select("*").eq("id", id).maybeSingle(); if (lookupError) throw lookupError; if (!app) return res.status(404).json({ error: "Application not found" });
      if (["rejected", "joined"].includes(app.status)) return res.status(409).json({ error: "This application is already closed." });
      const now = new Date().toISOString();
      const decisionAt = status === "pending" ? null : now;
      const { error } = await admin.from("guild_applications").update({ status, officer_feedback: feedback || null, reviewed_by: officer.name, updated_at: now, decision_at: decisionAt, purge_after: status === "rejected" ? new Date(Date.now() + 30 * 86400000).toISOString() : null }).eq("id", id); if (error) throw error;
      const statusMessage = status === "pending" ? (feedback || "Your application is pending. Continue the conversation here if officers need additional information.") : status === "approved" ? "Application approved. An officer will contact you using your application IGN for the in-game invite." : "Application rejected.";
      const { error: messageError } = await admin.from("guild_application_messages").insert({ application_id: id, sender_type: "system", sender_name: "HAVOC", message: statusMessage }); if (messageError) throw messageError;
      return res.status(200).json({ ok: true });
    }
    if (action === "join_applicant") {
      const id = String(req.body.id || ""), rosterIgn = String(req.body.rosterIgn || "").trim(), job = String(req.body.job || "").trim(), role = String(req.body.role || "").trim(), group = Number(req.body.group);
      if (!/^[A-Za-z0-9]{2,40}$/.test(rosterIgn)) return res.status(400).json({ error: "Final roster IGN may only contain English letters A-Z and numbers 0-9" });
      if (![1,2,3,4].includes(group)) return res.status(400).json({ error: "Select a valid Feather Group" });
      if (!job || !role) return res.status(400).json({ error: "Job and lineup role are required" });
      const { data, error } = await admin.rpc("join_approved_application", { p_application_id: id, p_roster_ign: rosterIgn, p_job: job, p_role: role, p_group: group, p_officer_name: officer.name });
      if (error) {
        if (/already in the active roster/i.test(error.message || "")) return res.status(409).json({ error: "That IGN is already in the active roster" });
        if (/Only an approved application/i.test(error.message || "")) return res.status(409).json({ error: "Only an approved application can be joined" });
        throw error;
      }
      return res.status(200).json({ ok: true, member: data });
    }
    return res.status(400).json({ error: "Unknown officer application action" });
  } catch (error) { console.error("Applications officer API error", error); return res.status(500).json({ error: error.message || "Officer application request failed" }); }
}
