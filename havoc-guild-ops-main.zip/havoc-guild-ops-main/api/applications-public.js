import { createClient } from "@supabase/supabase-js";
import { handlePublicApplicationUtility } from "../lib/public-application-utils.js";

const BUCKET = "guild-applications";
const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);
const MAX_FILE_SIZE = 2 * 1024 * 1024;

function adminClient() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  if (!process.env.SUPABASE_URL || !key) throw new Error("Supabase server configuration is missing");
  return createClient(process.env.SUPABASE_URL, key, { auth: { autoRefreshToken: false, persistSession: false } });
}
function cleanText(value, max = 1000) { return String(value || "").trim().slice(0, max); }
function validEmail(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim()); }
function validUuid(value) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || "")); }
function safeFileName(name) { const raw = String(name || "screenshot").replace(/[^A-Za-z0-9._-]/g, "-").replace(/-+/g, "-").slice(-80); return raw || "screenshot.jpg"; }
async function loadByToken(admin, token) { const { data, error } = await admin.from("guild_applications").select("*").eq("public_token", token).maybeSingle(); if (error) throw error; return data; }
async function signedFiles(admin, applicationId) {
  const { data: files, error } = await admin.from("guild_application_files").select("id,storage_path,original_name,content_type,size_bytes,revision,attachment_group,message_id,created_at").eq("application_id", applicationId).order("created_at");
  if (error) throw error;
  const output = [];
  for (const file of files || []) { const { data } = await admin.storage.from(BUCKET).createSignedUrl(file.storage_path, 3600); output.push({ ...file, url: data?.signedUrl || null }); }
  return output;
}
async function messages(admin, applicationId) {
  const { data, error } = await admin.from("guild_application_messages").select("id,sender_type,sender_name,message,created_at").eq("application_id", applicationId).order("created_at");
  if (error) throw error;
  return data || [];
}
async function sendPrivateLinkEmail(app, req) {
  if (!app.email) return { sent: false, skipped: true };
  if (!process.env.RESEND_API_KEY) return { sent: false, warning: "Email delivery is not configured yet" };
  try {
    const origin = process.env.PUBLIC_SITE_URL || `${req.headers["x-forwarded-proto"] || "https"}://${req.headers.host}`;
    const url = `${origin.replace(/\/$/, "")}/apply?token=${app.public_token}`;
    const safe = value => String(value || "").replace(/[&<>\"]/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;" }[c]));
    const html = `<!doctype html><html><body style="font-family:Arial,sans-serif;background:#0b0c11;color:#f4efe5;padding:28px"><div style="max-width:620px;margin:auto;background:#15171d;border:1px solid #31343e;border-radius:16px;padding:28px"><h1 style="margin-top:0">HAVOC</h1><p>Hi ${safe(app.ign)},</p><p>Here is the private link to your Havoc guild application. Use this page to review your status and chat directly with Havoc Officers.</p><p><a href="${safe(url)}" style="display:inline-block;padding:12px 18px;background:#ef5b3f;color:white;text-decoration:none;border-radius:8px">Open private application</a></p><p style="color:#a6a6ad">Keep this link private. Anyone with the link can open your application conversation.</p></div></body></html>`;
    const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" }, body: JSON.stringify({ from: process.env.HAVOC_FROM_EMAIL || "Havoc Guild <onboarding@resend.dev>", to: [app.email], subject: "Your private Havoc application link", html }) });
    if (response.ok) return { sent: true };
    const providerBody = await response.text().catch(() => "");
    console.warn("Application backup email failed", { status: response.status, provider: providerBody.slice(0, 300) });
    return { sent: false, warning: `Email provider returned ${response.status}` };
  } catch (error) {
    console.warn("Application backup email failed", { message: error?.message || "Unknown email error" });
    return { sent: false, warning: "Backup email could not be sent" };
  }
}
async function deleteDraft(admin, app) {
  if (!app || app.status !== "draft") return false;
  const { data: files } = await admin.from("guild_application_files").select("storage_path").eq("application_id", app.id);
  const paths = (files || []).map(file => file.storage_path).filter(Boolean);
  if (paths.length) await admin.storage.from(BUCKET).remove(paths);
  const { error } = await admin.from("guild_applications").delete().eq("id", app.id).eq("status", "draft");
  if (error) throw error;
  return true;
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const admin = adminClient();
  try {
    const body = req.body || {}, action = body.action;
    const utility = await handlePublicApplicationUtility(admin, body);
    if (utility) return res.status(utility.status).json(utility.body);
    if (action === "create") {
      const ign = cleanText(body.ign, 40), rawEmail = cleanText(body.email, 180), email = rawEmail ? rawEmail.toLowerCase() : null, jobClass = cleanText(body.jobClass, 50);
      if (ign.length < 2) return res.status(400).json({ error: "Enter your exact current in-game name." });
      if (email && !validEmail(email)) return res.status(400).json({ error: "Enter a valid email address or leave it blank." });
      if (!jobClass) return res.status(400).json({ error: "Select your current job/class." });
      if (body.organizedBidding !== true) return res.status(400).json({ error: "You must acknowledge Havoc's organized bidding system before submitting." });
      const { data: active, error: duplicateError } = await admin.from("guild_applications").select("id,status,ign,email").in("status", ["draft", "new", "pending", "approved"]);
      if (duplicateError) throw duplicateError;
      const ignKey = ign.toLocaleLowerCase(), emailKey = email ? email.toLowerCase() : null;
      if ((active || []).some(row => String(row.ign || "").toLocaleLowerCase() === ignKey || (emailKey && String(row.email || "").toLowerCase() === emailKey))) return res.status(409).json({ error: "An active application already exists for this IGN or email. Use your private application link to update it." });
      const row = { ign, email, job_class: jobClass, previous_guild: cleanText(body.previousGuild, 120) || null, availability: { willingAdjust: body.willingAdjust === true, organizedBidding: true }, status: "draft", updated_at: new Date().toISOString() };
      const { data, error } = await admin.from("guild_applications").insert(row).select("id,public_token").single();
      if (error?.code === "23505") return res.status(409).json({ error: "An active application already exists for this IGN or email. Use your private application link to continue it." });
      if (error) throw error;
      return res.status(200).json({ ok: true, applicationId: data.id, token: data.public_token });
    }
    if (action === "upload_url") {
      const app = await loadByToken(admin, body.token); if (!app) return res.status(404).json({ error: "Application not found" });
      if (!["draft", "new", "pending", "approved"].includes(app.status)) return res.status(409).json({ error: "Screenshots cannot be uploaded for this application." });
      const type = cleanText(body.contentType, 80), size = Number(body.size || 0);
      if (!ALLOWED_TYPES.has(type)) return res.status(400).json({ error: "Screenshots must be JPG, PNG, or WebP." });
      if (!size || size > MAX_FILE_SIZE) return res.status(400).json({ error: "Each screenshot must be 2 MB or smaller after compression." });
      const attachmentGroup = body.attachmentGroup ? cleanText(body.attachmentGroup, 64) : null;
      if (app.status !== "draft" && !validUuid(attachmentGroup)) return res.status(400).json({ error: "Invalid message attachment group." });
      const revision = app.status === "draft" ? 0 : app.revision_count + 1;
      let countQuery = admin.from("guild_application_files").select("id", { count: "exact", head: true }).eq("application_id", app.id);
      countQuery = app.status === "draft" ? countQuery.eq("revision", 0) : countQuery.eq("attachment_group", attachmentGroup);
      const { count, error: countError } = await countQuery; if (countError) throw countError;
      if ((count || 0) >= 4) return res.status(400).json({ error: "Maximum 4 screenshots per message." });
      const name = safeFileName(body.fileName), path = app.status === "draft" ? `${app.id}/r0/${crypto.randomUUID()}-${name}` : `${app.id}/messages/${attachmentGroup}/${crypto.randomUUID()}-${name}`;
      const { data, error } = await admin.storage.from(BUCKET).createSignedUploadUrl(path); if (error) throw error;
      return res.status(200).json({ ok: true, path, uploadToken: data.token, revision, attachmentGroup });
    }
    if (action === "register_file") {
      const app = await loadByToken(admin, body.token); if (!app) return res.status(404).json({ error: "Application not found" });
      const path = cleanText(body.path, 500); if (!path.startsWith(`${app.id}/`)) return res.status(403).json({ error: "Invalid screenshot path" });
      const attachmentGroup = body.attachmentGroup ? cleanText(body.attachmentGroup, 64) : null;
      if (attachmentGroup && !validUuid(attachmentGroup)) return res.status(400).json({ error: "Invalid message attachment group." });
      const { error } = await admin.from("guild_application_files").insert({ application_id: app.id, storage_path: path, original_name: safeFileName(body.fileName), content_type: cleanText(body.contentType, 80), size_bytes: Number(body.size || 0) || null, revision: Number(body.revision || 0), attachment_group: attachmentGroup || null }); if (error) throw error;
      await admin.from("guild_applications").update({ updated_at: new Date().toISOString() }).eq("id", app.id);
      return res.status(200).json({ ok: true });
    }
    if (action === "finalize") {
      const app = await loadByToken(admin, body.token); if (!app || app.status !== "draft") return res.status(409).json({ error: "This draft cannot be submitted." });
      const { count, error: countError } = await admin.from("guild_application_files").select("id", { count: "exact", head: true }).eq("application_id", app.id).eq("revision", 0); if (countError) throw countError;
      if (!count) return res.status(400).json({ error: "Attach at least one account screenshot before submitting." });
      const now = new Date().toISOString(); const { error } = await admin.from("guild_applications").update({ status: "new", submitted_at: now, updated_at: now }).eq("id", app.id).eq("status", "draft"); if (error) throw error;
      const { error: messageError } = await admin.from("guild_application_messages").insert({ application_id: app.id, sender_type: "system", sender_name: "HAVOC", message: "Application submitted. Officers can now review your account." }); if (messageError) console.warn("Application system message failed", { message: messageError.message });
      const email = await sendPrivateLinkEmail(app, req);
      return res.status(200).json({ ok: true, token: app.public_token, linkEmailSent: email.sent, linkEmailWarning: email.warning || null });
    }
    if (action === "status") {
      const app = await loadByToken(admin, body.token); if (!app) return res.status(404).json({ error: "Application not found" });
      return res.status(200).json({ ok: true, application: { ign: app.ign, email: app.email, jobClass: app.job_class, previousGuild: app.previous_guild, availability: app.availability || {}, status: app.status, officerFeedback: app.officer_feedback, submittedAt: app.submitted_at, updatedAt: app.updated_at, revisionCount: app.revision_count }, files: await signedFiles(admin, app.id), messages: app.status === "draft" ? [] : await messages(admin, app.id) });
    }
    if (action === "discard_draft") {
      const app = await loadByToken(admin, body.token); if (!app) return res.status(200).json({ ok: true });
      if (app.status !== "draft") return res.status(409).json({ error: "Only an unfinished draft can be discarded." });
      await deleteDraft(admin, app);
      return res.status(200).json({ ok: true });
    }
    if (action === "send_message") {
      const app = await loadByToken(admin, body.token); if (!app || app.status === "draft") return res.status(404).json({ error: "Application not found" });
      if (["rejected", "joined"].includes(app.status)) return res.status(409).json({ error: "This conversation is closed." });
      const message = cleanText(body.message, 3000); if (!message) return res.status(400).json({ error: "Enter a message." });
      const attachmentGroup = body.attachmentGroup ? cleanText(body.attachmentGroup, 64) : null;
      if (attachmentGroup && !validUuid(attachmentGroup)) return res.status(400).json({ error: "Invalid message attachment group." });
      const { error } = await admin.rpc("post_application_message_with_attachments", { p_application_id: app.id, p_sender_type: "applicant", p_sender_name: app.ign, p_message: message, p_attachment_group: attachmentGroup || null }); if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(400).json({ error: "Unknown application action" });
  } catch (error) { console.error("Applications public API error", error); return res.status(500).json({ error: error.message || "Application request failed" }); }
}
