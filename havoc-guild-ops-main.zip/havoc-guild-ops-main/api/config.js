import { isPublicSiteProject } from "../lib/project-mode.js";

const INTERNAL_ORIGIN = "https://havoc-guild-ops.vercel.app";

async function proxyRequest(req, res, target) {
  const options = {
    method: req.method,
    headers: { "Content-Type": "application/json" }
  };
  if (req.method !== "GET" && req.method !== "HEAD") options.body = JSON.stringify(req.body || {});
  const response = await fetch(INTERNAL_ORIGIN + target, options);
  const text = await response.text();
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Content-Type", response.headers.get("content-type") || "application/json; charset=utf-8");
  return res.status(response.status).send(text);
}

export default async function handler(req, res) {
  if (isPublicSiteProject()) {
    const proxy = String(req.query?.proxy || "");
    if (proxy === "roster") {
      if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
      const response = await fetch(INTERNAL_ORIGIN + "/api/applications-public", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "roster_status" })
      });
      const text = await response.text();
      res.setHeader("Cache-Control", "no-store");
      res.setHeader("Content-Type", response.headers.get("content-type") || "application/json; charset=utf-8");
      return res.status(response.status).send(text);
    }
    if (proxy === "marketplace") {
      if (!["GET", "POST"].includes(req.method)) return res.status(405).json({ error: "Method not allowed" });
      return proxyRequest(req, res, "/api/state-store?resource=public-marketplace");
    }
    if (proxy === "applications") {
      if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
      return proxyRequest(req, res, "/api/applications-public");
    }
    if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
    return proxyRequest(req, res, "/api/config");
  }

  const url = process.env.SUPABASE_URL;
  const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !publishableKey) return res.status(500).json({ error: "Supabase environment variables are not configured" });
  res.setHeader("Cache-Control", "no-store");
  return res.status(200).json({
    url,
    publishableKey,
    emailConfigured: Boolean(process.env.RESEND_API_KEY),
    preview: process.env.VERCEL_ENV !== "production",
    gitRef: process.env.VERCEL_GIT_COMMIT_REF || null
  });
}
