import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";
import { conflictPayload, readGuildState, saveGuildState } from "../lib/state-store.js";

const IGN_PATTERN = /^[A-Za-z0-9]+$/;

export function sanitizeOfficerState(value) {
  const state = structuredClone(value || {});
  delete state.officerAccounts;
  return state;
}

export function publicGuildState(value) {
  const state = sanitizeOfficerState(value);
  delete state.officerReadState;
  delete state.history;
  delete state.lineupHistory;
  delete state.jobChangeLog;
  delete state.accountChangeLog;
  delete state.publicActionLog;
  return state;
}

export function memberRows(state) {
  const updatedAt = new Date().toISOString();
  return (state.players || []).map(player => ({
    ...(player.dbId ? { id: player.dbId } : {}),
    ign: player.name,
    job_class: player.job || null,
    combat_role: player.role || null,
    auction_group: player.auctionGroup ?? null,
    puppet_complete: Boolean(player.puppetComplete),
    puppet_completed_at: player.puppetCompletedAt || null,
    puppet_rotation_order: player.puppetOrder ?? null,
    guild_title: player.guildTitle || "Member",
    is_officer: Boolean(player.isOfficer),
    can_manage: Boolean(player.canManage),
    officer_rotation_order: player.officerOrder ?? null,
    active: Boolean(player.active),
    updated_at: updatedAt
  }));
}

async function stateWithMemberCreatedAt(admin, value) {
  const state = structuredClone(value || {});
  const { data: members, error } = await admin.from("members").select("id,ign,created_at");
  if (error) throw error;
  const byId = new Map((members || []).map(row => [String(row.id), row]));
  const byIgn = new Map((members || []).map(row => [String(row.ign || "").toLowerCase(), row]));
  state.players = (state.players || []).map(player => {
    const row = (player.dbId && byId.get(String(player.dbId))) || byIgn.get(String(player.name || "").toLowerCase());
    return {
      ...player,
      ...(row?.id ? { dbId: row.id } : {}),
      memberAddedAt: row?.created_at || player.memberAddedAt || null
    };
  });
  return state;
}

async function officerIdentity(admin, req) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data: { user }, error: authError } = await admin.auth.getUser(token);
  if (authError || !user) return null;
  const { data: profile, error: profileError } = await admin.from("officer_access_profiles").select("active,login_name,members:member_id(ign)").eq("auth_user_id", user.id).maybeSingle();
  if (profileError) throw profileError;
  if (!profile?.active) return null;
  return { user, profile, name: profile.members?.ign || profile.login_name || "Officer" };
}

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  if (!process.env.SUPABASE_URL || !serviceKey) return res.status(503).json({ error: "Supabase server environment variables are not configured" });
  const admin = createClient(process.env.SUPABASE_URL, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });

  if (req.method === "GET") {
    try {
      const identity = await officerIdentity(admin, req);
      const row = await readGuildState(admin);
      if (!row?.state) return res.status(404).json({ error: "Guild state not found" });
      const enrichedState = await stateWithMemberCreatedAt(admin, row.state);
      res.setHeader("Cache-Control", "no-store");
      return res.status(200).json({
        ok: true,
        state: identity ? enrichedState : publicGuildState(enrichedState),
        version: Number(row.version || 1),
        lastChange: {
          by: row.last_changed_by || "Unknown",
          kind: row.last_change_kind || "Guild data update",
          at: row.last_changed_at || row.updated_at || null
        },
        officer: Boolean(identity)
      });
    } catch (error) {
      console.error("Guild state load failed", error);
      return res.status(500).json({ error: error.message || "Guild state could not be loaded" });
    }
  }

  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const identity = await officerIdentity(admin, req);
    if (!identity) return res.status(401).json({ error: "Officer access required" });
    const state = sanitizeOfficerState(req.body?.state);
    const expectedVersion = Number(req.body?.expectedVersion);
    if (!Number.isInteger(expectedVersion) || expectedVersion < 1) return res.status(400).json({ error: "Refresh the app before saving. Guild state version is missing." });
    if (!Array.isArray(state.players) || !Array.isArray(state.events)) return res.status(400).json({ error: "Invalid guild state" });

    const { data: existingMembers, error: existingMembersError } = await admin.from("members").select("ign");
    if (existingMembersError) return res.status(500).json({ error: existingMembersError.message });
    const existingIgns = new Set((existingMembers || []).map(row => String(row.ign || "").toLowerCase()));
    for (const player of state.players) {
      const ign = String(player?.name || "").trim();
      if (!ign) return res.status(400).json({ error: "Every member must have an IGN" });
      if (!IGN_PATTERN.test(ign) && !existingIgns.has(ign.toLowerCase())) {
        return res.status(400).json({ error: `IGN "${ign}" is invalid. New member IGNs may only contain English letters A-Z and numbers 0-9. Spaces and special characters are not allowed.` });
      }
    }

    const result = await saveGuildState(admin, {
      state,
      expectedVersion,
      changedBy: identity.name,
      changeKind: "Officer save",
      syncMembers: true
    });
    const conflict = conflictPayload(result);
    if (conflict) return res.status(409).json(conflict);
    return res.status(200).json({
      ok: true,
      version: result.version,
      lastChange: { by: result.lastChangedBy, kind: result.lastChangeKind, at: result.lastChangedAt },
      memberSyncWarning: null
    });
  } catch (error) {
    console.error("Officer state save failed", error);
    return res.status(500).json({ error: error.message || "Guild state save failed" });
  }
}
