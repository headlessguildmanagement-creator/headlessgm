import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";
import { isPreviewEnvironment } from "../lib/environment-scope.js";

const EVENT_ID_PATTERN = /^(eo|gl)-\d{4}-\d{2}-\d{2}$/;
const WEBHOOK_ENV = {
  lineup: "DISCORD_LINEUP_WEBHOOK_URL",
  auction: "DISCORD_AUCTION_WEBHOOK_URL",
  tentative: "DISCORD_AUCTION_WEBHOOK_URL",
  loa_filed: "DISCORD_LOA_WEBHOOK_URL",
  loa_cancelled: "DISCORD_LOA_WEBHOOK_URL"
};

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ error: "Missing authorization" });
  const preview = isPreviewEnvironment();
  if (!preview && !process.env.PUBLIC_SITE_URL) return res.status(503).json({ error: "PUBLIC_SITE_URL is not configured in Vercel" });

  const admin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false }
  });
  const { data: { user }, error: authError } = await admin.auth.getUser(token);
  if (authError || !user) return res.status(401).json({ error: "Invalid session" });
  const { data: profile, error: profileError } = await admin
    .from("officer_access_profiles")
    .select("active,login_name,members:member_id(ign)")
    .eq("auth_user_id", user.id)
    .maybeSingle();
  if (profileError) return res.status(500).json({ error: profileError.message });
  if (!profile?.active) return res.status(403).json({ error: "Active officer access is required" });

  const { type, eventId, eventName, eventDate, playerName, reason, imageData, images } = req.body || {};
  if (!WEBHOOK_ENV[type]) return res.status(400).json({ error: "Unknown publication type" });
  const webhookUrl = process.env[WEBHOOK_ENV[type]];
  if (!preview && !webhookUrl) return res.status(503).json({ error: `${WEBHOOK_ENV[type]} is not configured in Vercel` });
  if (!EVENT_ID_PATTERN.test(String(eventId || ""))) return res.status(400).json({ error: "Invalid event identifier" });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(eventDate || ""))) return res.status(400).json({ error: "Invalid event date" });
  const safeEventName = String(eventName || "").trim().slice(0, 100);
  if (!safeEventName) return res.status(400).json({ error: "Event name is required" });

  const site = preview ? `https://${req.headers.host}` : process.env.PUBLIC_SITE_URL.replace(/\/+$/, "");
  const isLoa = type.startsWith("loa_");
  const slug = type === "lineup" ? "line-up" : ["auction", "tentative"].includes(type) ? "auction" : "loa";
  const link = `${site}/${slug}?event=${encodeURIComponent(eventId)}`;
  const date = new Intl.DateTimeFormat("en-PH", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    timeZone: "Asia/Manila"
  }).format(new Date(`${eventDate}T12:00:00+08:00`));
  const officer = String(profile.members?.ign || profile.login_name || "Officer").slice(0, 80);
  const isLineup = type === "lineup";
  const isAuction = ["auction", "tentative"].includes(type);
  const safePlayerName = String(playerName || "").trim().slice(0, 80);
  const safeReason = String(reason || "").trim().slice(0, 500);
  if (isLoa && !safePlayerName) return res.status(400).json({ error: "Player name is required" });
  const title = isLineup ? "HAVOC Lineup Published" : type === "tentative" ? `Possible Bidders — ${safeEventName}` : isAuction ? "HAVOC Auction Assignments Published" : type === "loa_filed" ? "HAVOC LOA Filed" : "HAVOC LOA Cancelled";
  const actionText = isLineup ? "View the published lineup" : type === "tentative" ? "View auction page" : isAuction ? "View auction assignments" : "View event LOAs";
  const loaDetails = isLoa ? `\nPlayer: ${safePlayerName}${safeReason ? `\nReason: ${safeReason}` : ""}` : "";
  const description = type === "tentative" ? `${safeEventName} · ${date}\nEarly reminder prepared by ${officer}.\n\n⚠️ THIS IS NOT THE OFFICIAL BIDDING LIST.\nThese are possible bidders only, shared early so members who may be called tomorrow can prepare and save Gold.\n\nPuppet bidders may change depending on the final ranking/results of the event. The preview shows up to 20 possible Puppet bidders because the actual number of Puppet slots can vary.\n\nPlease wait for the official bidding list after the event results are finalized.\n\n${actionText}:\n${link}` : `${safeEventName} · ${date}${loaDetails}\n${isLoa ? "Recorded" : "Published"} by ${officer}\n\n${actionText}:\n${link}`;
  const imageFiles = [];
  if (isLineup || isAuction) {
    const supplied = Array.isArray(images) ? images : imageData ? [{ title, data: imageData }] : [];
    if (!supplied.length || supplied.length > 5) return res.status(400).json({ error: "One to five generated PNG previews are required" });
    let totalBytes = 0;
    for (let index = 0; index < supplied.length; index++) {
      const match = String(supplied[index]?.data || "").match(/^data:image\/png;base64,([A-Za-z0-9+/=]+)$/);
      if (!match) return res.status(400).json({ error: `Generated preview ${index + 1} is not a PNG` });
      const buffer = Buffer.from(match[1], "base64");
      totalBytes += buffer.length;
      if (!buffer.length || buffer.length > 3_000_000 || totalBytes > 7_000_000) return res.status(413).json({ error: "Generated images are too large" });
      imageFiles.push({
        buffer,
        filename: `havoc-${type}-${index + 1}.png`,
        title: String(supplied[index]?.title || `${title} · Part ${index + 1}`).trim().slice(0, 100)
      });
    }
  }

  if (preview) {
    return res.status(200).json({ ok: true, preview: true, messageId: null, link, message: "Preview mode: Discord send suppressed" });
  }

  try {
    const embeds = imageFiles.length ? imageFiles.map((file, index) => ({
      title: index === 0 ? title : file.title,
      ...(index === 0 ? { description } : {}),
      url: link,
      color: 12918581,
      ...(index === 0 ? { timestamp: new Date().toISOString() } : {}),
      image: { url: `attachment://${file.filename}` }
    })) : [{ title, description, url: link, color: 12918581, timestamp: new Date().toISOString() }];
    const payload = {
      username: "Havoc Guild Operations",
      ...(imageFiles.length ? { content: type === "tentative" ? `@everyone\n**POSSIBLE BIDDERS — ${safeEventName} · ${date}**\n⚠️ **EARLY REMINDER ONLY — THIS IS NOT THE OFFICIAL BIDDING LIST.**\n\nThis is being shared so members who **might be bidding tomorrow** have time to prepare and **save Gold**.\n\n**Puppet bidders:** the final names/number of bidders can change depending on the **event ranking/results**. We show up to **20 possible Puppet bidders** in advance for this reason.\n\nPlease wait for the **official bidding list** after the event results are finalized.\n\n🔗 **${actionText}:**\n${link}` : `🔗 **${actionText}:**\n${link}` } : {}),
      allowed_mentions: { parse: type === "tentative" ? ["everyone"] : [] },
      embeds
    };
    const request = imageFiles.length ? (() => {
      const form = new FormData();
      form.append("payload_json", JSON.stringify(payload));
      imageFiles.forEach((file, index) => form.append(`files[${index}]`, new Blob([file.buffer], { type: "image/png" }), file.filename));
      return { method: "POST", body: form };
    })() : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) };
    const webhookResponse = await fetch(`${webhookUrl}${webhookUrl.includes("?") ? "&" : "?"}wait=true`, request);
    const body = await webhookResponse.json().catch(() => ({}));
    if (!webhookResponse.ok) return res.status(502).json({ error: body.message || "Discord rejected the notification" });
    return res.status(200).json({ ok: true, messageId: body.id || null, link });
  } catch (error) {
    return res.status(502).json({ error: error?.message || "Discord notification failed" });
  }
}
