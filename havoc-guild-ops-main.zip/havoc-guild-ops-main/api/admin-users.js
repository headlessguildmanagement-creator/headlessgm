import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from '@supabase/supabase-js';

export function isCanonicalAdministrator(profile) {
  const names = [profile?.login_name, profile?.members?.ign]
    .map(value => String(value || '').trim().toLowerCase());
  return Boolean(profile?.can_manage_access || names.includes('ozawa') || names.includes('zonzi'));
}

export function canDeleteRosterMember(profile) {
  return Boolean(profile?.active);
}

export function scrubPlayer(state, playerId, playerName) {
  state.players = (state.players || []).filter(player => player.id !== playerId);
  state.loas = (state.loas || []).filter(row => row.playerId !== playerId);
  state.jobChangeLog = (state.jobChangeLog || []).filter(row => row.playerId !== playerId);
  state.accountChangeLog = (state.accountChangeLog || []).filter(row => row.playerId !== playerId);
  state.publicActionLog = (state.publicActionLog || []).filter(row => row.playerId !== playerId);
  state.history = (state.history || []).filter(row => !JSON.stringify(row).includes(playerId));
  state.lineupHistory = (state.lineupHistory || []).filter(row => !JSON.stringify(row).includes(playerId));
  state.puppetCycleHistory = (state.puppetCycleHistory || []).map(cycle => ({ ...cycle, members: (cycle.members || []).filter(member => member.playerId !== playerId && member.name !== playerName) }));
  state.puppetDeferredTurns = (state.puppetDeferredTurns || []).filter(row => row.playerId !== playerId);
  state.puppetAppealQueue = (state.puppetAppealQueue || []).filter(row => row.playerId !== playerId);
  state.puppetNextCycleCredits = (state.puppetNextCycleCredits || []).filter(row => row.playerId !== playerId);
  for (const event of state.events || []) {
    for (const raid of ['main', 'sub']) event.lineups?.[raid]?.forEach(party => party.forEach((id, index) => { if (id === playerId) party[index] = null; }));
    event.noShows = (event.noShows || []).filter(id => id !== playerId);
    event.puppetCannotBidIds = (event.puppetCannotBidIds || []).filter(id => id !== playerId);
    event.ineligibleFeatherIds = (event.ineligibleFeatherIds || []).filter(id => id !== playerId);
    if (event.featherIneligibleReasons) delete event.featherIneligibleReasons[playerId];
    if (event.auction?.assignments) event.auction.assignments = event.auction.assignments.filter(item => item.playerId !== playerId);
    if (event.auction?.settings?.playerQuotas) delete event.auction.settings.playerQuotas[playerId];
  }
  return state;
}

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Missing authorization' });
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  if (!process.env.SUPABASE_URL || !serviceKey) return res.status(503).json({ error: 'Supabase server environment variables are not configured' });
  const admin = createClient(process.env.SUPABASE_URL, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
  const { data: { user }, error: authError } = await admin.auth.getUser(token);
  if (authError || !user) return res.status(401).json({ error: 'Invalid session' });
  const { data: profile, error: profileError } = await admin.from('officer_access_profiles').select('member_id,can_manage_access,active,login_name').eq('auth_user_id', user.id).maybeSingle();
  if (profileError) return res.status(500).json({ error: `Officer profile lookup failed: ${profileError.message}` });
  if (!canDeleteRosterMember(profile)) return res.status(403).json({ error: 'Officer access required' });
  const requestedAction = req.body?.action;
  if (requestedAction !== 'delete_member' && !isCanonicalAdministrator(profile)) return res.status(403).json({ error: 'Administrator access required' });
  try {
    const { action, memberId, ign, email, password, userId } = req.body || {};
    if (action === 'create') {
      if (!memberId || !email || !password) return res.status(400).json({ error: 'Member, email and temporary password are required' });
      let { data: member } = memberId ? await admin.from('members').select('id,ign,active').eq('id', memberId).maybeSingle() : { data: null };
      if (!member && ign) { const result = await admin.from('members').select('id,ign,active').ilike('ign', ign.trim()).maybeSingle(); if (result.error) throw result.error; member = result.data; }
      if (!member?.active) return res.status(400).json({ error: 'Active member not found' });
      const { data: existingProfile, error: existingProfileError } = await admin.from('officer_access_profiles').select('auth_user_id,active').eq('member_id', member.id).maybeSingle();
      if (existingProfileError) throw existingProfileError;
      if (existingProfile) {
        if (existingProfile.active) return res.status(409).json({ error: 'This member already has officer access' });
        const { error: ue } = await admin.auth.admin.updateUserById(existingProfile.auth_user_id, { email, password, email_confirm: true, ban_duration: 'none', user_metadata: { havoc_first_login: true, havoc_ign: member.ign } });
        if (ue) throw ue;
        const { error: pe } = await admin.from('officer_access_profiles').update({ active: true, can_manage_access: false, login_name: member.ign, login_email: email, must_change_password: true }).eq('auth_user_id', existingProfile.auth_user_id);
        if (pe) throw pe;
        const { error: me } = await admin.from('members').update({ auth_user_id: existingProfile.auth_user_id, guild_title: 'Officer', is_officer: true, can_manage: false }).eq('id', member.id);
        if (me) throw me;
        return res.status(200).json({ ok: true, reactivated: true });
      }
      const { data: created, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { havoc_first_login: true, havoc_ign: member.ign } });
      if (error) throw error;
      const { error: pe } = await admin.from('officer_access_profiles').insert({ auth_user_id: created.user.id, member_id: member.id, can_manage_access: false, active: true, login_name: member.ign, login_email: email, must_change_password: true });
      if (pe) { await admin.auth.admin.deleteUser(created.user.id); throw pe; }
      const { error: me } = await admin.from('members').update({ auth_user_id: created.user.id, guild_title: 'Officer', is_officer: true, can_manage: false }).eq('id', member.id);
      if (me) { await admin.from('officer_access_profiles').delete().eq('auth_user_id', created.user.id); await admin.auth.admin.deleteUser(created.user.id); throw me; }
      return res.status(200).json({ ok: true });
    }
    if (action === 'reset_password') {
      if (!userId || !password) return res.status(400).json({ error: 'User and password are required' });
      const { error } = await admin.auth.admin.updateUserById(userId, { password, user_metadata: { havoc_first_login: true } });
      if (error) throw error;
      const { error: pe } = await admin.from('officer_access_profiles').update({ must_change_password: true, active: true }).eq('auth_user_id', userId);
      if (pe) throw pe;
      return res.status(200).json({ ok: true });
    }
    if (action === 'revoke') {
      if (!userId || !memberId) return res.status(400).json({ error: 'User and member are required' });
      const { error } = await admin.auth.admin.updateUserById(userId, { ban_duration: '876000h' });
      if (error) throw error;
      const { error: pe } = await admin.from('officer_access_profiles').update({ active: false, can_manage_access: false }).eq('auth_user_id', userId);
      if (pe) throw pe;
      await admin.from('members').update({ auth_user_id: null, guild_title: 'Member', is_officer: false, can_manage: false }).eq('id', memberId);
      return res.status(200).json({ ok: true });
    }
    if (action === 'delete_member') {
      const { playerId } = req.body || {};
      if (!playerId || !ign) return res.status(400).json({ error: 'Member is required' });
      const { data: snapshot, error: stateError } = await admin.from('guild_app_state').select('state').eq('id', true).maybeSingle();
      if (stateError) throw stateError;
      const appPlayer = snapshot?.state?.players?.find(player => player.id === playerId && player.name.toLowerCase() === String(ign).toLowerCase());
      if (!appPlayer) return res.status(404).json({ error: 'Member not found in the active roster' });
      const { data: dbMember, error: memberLookupError } = await admin.from('members').select('id,auth_user_id').ilike('ign', appPlayer.name).maybeSingle();
      if (memberLookupError) throw memberLookupError;
      if (dbMember?.id === profile.member_id) return res.status(400).json({ error: 'You cannot delete your own active officer record' });
      if (dbMember?.auth_user_id && !isCanonicalAdministrator(profile)) {
        const { data: targetOfficer, error: targetOfficerError } = await admin.from('officer_access_profiles').select('active').eq('auth_user_id', dbMember.auth_user_id).maybeSingle();
        if (targetOfficerError) throw targetOfficerError;
        if (targetOfficer?.active) return res.status(403).json({ error: 'Only OZAWA or Zonzi can remove a member with active officer access' });
      }
      const state = scrubPlayer(structuredClone(snapshot.state), appPlayer.id, appPlayer.name);
      const updatedAt = new Date().toISOString();
      const { error: saveError } = await admin.from('guild_app_state').upsert({ id: true, state, updated_at: updatedAt }, { onConflict: 'id' });
      if (saveError) throw saveError;
      if (dbMember) {
        const authUserId = dbMember.auth_user_id;
        const { error: assignmentDeleteError } = await admin.from('auction_assignments').delete().eq('member_id', dbMember.id);
        if (assignmentDeleteError) throw assignmentDeleteError;
        const { error: quotaDeleteError } = await admin.from('auction_player_quotas').delete().eq('member_id', dbMember.id);
        if (quotaDeleteError) throw quotaDeleteError;
        await admin.from('audit_log').delete().in('entity_id', [appPlayer.id, dbMember.id]);
        const { error: deleteError } = await admin.from('members').delete().eq('id', dbMember.id);
        if (deleteError) throw deleteError;
        if (authUserId && authUserId !== user.id) await admin.auth.admin.deleteUser(authUserId);
      }
      return res.status(200).json({ ok: true, deleted: appPlayer.name });
    }
    return res.status(400).json({ error: 'Unknown action' });
  } catch (e) {
    return res.status(500).json({ error: e?.message || 'Server error' });
  }
}