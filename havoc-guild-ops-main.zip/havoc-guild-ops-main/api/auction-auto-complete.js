import { isPublicSiteProject } from "../lib/project-mode.js";
import { createClient } from "@supabase/supabase-js";
import { readGuildState, saveGuildState } from "./state-store.js";
import { applyPuppetAssignments } from "../lib/puppet-cycle.js";

function manilaDate() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Manila",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date());
}

function clearPuppetCannotBid(event) {
  if (!Array.isArray(event.puppetCannotBidIds) || !event.puppetCannotBidIds.length) return false;
  event.puppetCannotBidIds = [];
  return true;
}

function snapshotAuctionHistory(state, event, completionTime) {
  const assignments = event?.auction?.assignments || [];
  if (!assignments.length) return;
  state.auctionHistory ??= [];
  if (state.auctionHistory.some(row => row.eventId === event.id)) return;
  const playerName = id => state.players?.find(player => player.id === id)?.name || id;
  const unique = values => [...new Set(values.filter(Boolean))];
  const feather = unique(assignments.filter(item => item.tab === "Feather" || item.category === "Light/Dark" || item.category === "Time/Space").map(item => playerName(item.playerId)));
  const puppet = unique(assignments.filter(item => item.tab === "Cards" || item.category === "Puppet Fragment").map(item => playerName(item.playerId)));
  const regularGroup = new Set((state.players || []).filter(player => player.active !== false && Number(player.auctionGroup) === Number(event.activeGroup)).map(player => player.id));
  const excessOfficers = unique(assignments.filter(item => {
    if (!(item.tab === "Feather" || item.category === "Light/Dark" || item.category === "Time/Space")) return false;
    const ownerId = item.marketplaceOriginalPlayerId || item.playerId;
    return !regularGroup.has(ownerId) && state.players?.find(player => player.id === ownerId)?.isOfficer;
  }).map(item => playerName(item.marketplaceOriginalPlayerId || item.playerId)));
  const marketplaceDeals = [];
  const seenDeals = new Set();
  for (const item of assignments.filter(row => row.marketplaceListingId && row.marketplaceOriginalPlayerId)) {
    if (seenDeals.has(item.marketplaceListingId)) continue;
    seenDeals.add(item.marketplaceListingId);
    marketplaceDeals.push({
      listingId: item.marketplaceListingId,
      rightType: item.marketplaceRightType || (item.category === "Puppet Fragment" ? "puppet" : "feather"),
      category: item.category,
      originalPlayerId: item.marketplaceOriginalPlayerId,
      originalPlayerName: playerName(item.marketplaceOriginalPlayerId),
      bidderPlayerId: item.playerId,
      bidderPlayerName: playerName(item.playerId),
      source: "Marketplace · SOLD"
    });
  }
  state.auctionHistory.push({ eventId:event.id, date:event.date, eventName:event.name, eventType:event.type, group:event.activeGroup, featherBidders:feather, puppetBidders:puppet, excessOfficerBidders:excessOfficers, marketplaceDeals, recordedAt:completionTime });
}

export function completePastEvents(state, today, completionTime = new Date().toISOString(), completedBy = "AUTO · 12:00 AM PHT") {
  const completed = [];
  state.featherHistory ??= [];
  state.puppetCycle ??= 1;
  state.puppetCycleHistory ??= [];
  for (const event of [...(state.events || [])].sort((a, b) => a.date.localeCompare(b.date))) {
    if (event.date >= today) continue;
    if (event.eventCompletedAt) {
      snapshotAuctionHistory(state, event, completionTime);
      const puppetSkipReset = clearPuppetCannotBid(event);
      if (!state.featherHistory.some(row => row.date === event.date && row.group === event.activeGroup)) {
        state.featherHistory.push({ date: event.date, group: event.activeGroup, eventType: event.type, completed: true, completedBy: "AUTO · RECONCILED" });
        completed.push(event.id);
      } else if (puppetSkipReset) {
        completed.push(event.id);
      }
      continue;
    }
    if (event.auctionCompletedAt || (event.puppetCompletionRecordedAt && event.featherCompletionRecordedAt)) {
      snapshotAuctionHistory(state, event, completionTime);
      if (!state.featherHistory.some(row => row.date === event.date && row.group === event.activeGroup)) {
        state.featherHistory.push({ date: event.date, group: event.activeGroup, eventType: event.type, completed: true, completedBy: "AUTO · RECONCILED" });
      }
      event.eventCompletedAt = event.auctionCompletedAt || event.featherCompletionRecordedAt;
      clearPuppetCannotBid(event);
      completed.push(event.id);
      continue;
    }

    snapshotAuctionHistory(state, event, completionTime);
    applyPuppetAssignments(state, event, completionTime);

    if (!state.featherHistory.some(row => row.date === event.date && row.group === event.activeGroup)) {
      state.featherHistory.push({ date: event.date, group: event.activeGroup, eventType: event.type, completed: true, completedBy: "AUTO" });
    }
    const nextOfficer = Number(event.auction?.settings?.officerRotationNext);
    if (Number.isInteger(nextOfficer)) state.officerRotationIndex = nextOfficer;
    event.puppetCompletionRecordedAt ??= completionTime;
    event.featherCompletionRecordedAt ??= completionTime;
    event.eventCompletedAt = completionTime;
    event.auctionCompletedAt = completionTime;
    event.auctionCompletedBy = completedBy;
    clearPuppetCannotBid(event);
    completed.push(event.id);
  }
  return completed;
}

export default async function handler(req, res) {
  if (isPublicSiteProject()) return res.status(404).json({ error: "Not found" });
  if (!["GET", "POST"].includes(req.method)) return res.status(405).json({ error: "Method not allowed" });
  const supplied = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  let actor = "System";
  let changeKind = "Auction auto-complete";
  let completedBy = "AUTO · 12:00 AM PHT";
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  if (!process.env.SUPABASE_URL || !serviceKey) return res.status(503).json({ error: "Supabase server environment variables are not configured" });

  const admin = createClient(process.env.SUPABASE_URL, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
  if (req.method === "GET") {
    const expected = process.env.CRON_SECRET;
    if (!expected || supplied !== expected) return res.status(401).json({ error: "Invalid cron authorization" });
  } else {
    if (!supplied) return res.status(401).json({ error: "Officer access required" });
    const { data: { user }, error: authError } = await admin.auth.getUser(supplied);
    if (authError || !user) return res.status(401).json({ error: "Officer access required" });
    const { data: profile, error: profileError } = await admin.from("officer_access_profiles").select("active,login_name,members:member_id(ign)").eq("auth_user_id", user.id).maybeSingle();
    if (profileError) return res.status(500).json({ error: profileError.message });
    if (!profile?.active) return res.status(403).json({ error: "Active officer access required" });
    actor = profile.members?.ign || profile.login_name || "Officer";
    changeKind = "Manual auto-complete recovery";
    completedBy = `RECOVERY · ${actor}`;
  }
  try {
    const snapshot = await readGuildState(admin);
    if (!snapshot?.state) return res.status(200).json({ ok: true, completed: [], message: "No guild state found" });
    const state = structuredClone(snapshot.state);
    const completed = completePastEvents(state, manilaDate(), new Date().toISOString(), completedBy);
    if (!completed.length) return res.status(200).json({ ok: true, completed: [] });

    const saved = await saveGuildState(admin, {
      state,
      expectedVersion: Number(snapshot.version || 1),
      changedBy: actor,
      changeKind,
      syncMembers: true
    });
    if (saved?.conflict) return res.status(409).json({ ok: false, conflict: true, retry: true, message: "Guild state changed during auto-complete. The cron did not overwrite newer data and can safely retry on the next run." });
    return res.status(200).json({ ok: true, completed, completedAt: saved.lastChangedAt, version: saved.version });
  } catch (error) {
    console.error("Auction auto-complete failed", error);
    return res.status(500).json({ error: error.message || "Auction auto-complete failed" });
  }
}
