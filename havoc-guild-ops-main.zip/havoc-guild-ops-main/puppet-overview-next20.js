(() => {
  function currentEvent() {
    return eventById(selectedEventId) || state.events.find(event => eventRotationEndsAt(event) > new Date()) || state.events.at(-1);
  }

  function activeDeferredFor(playerId) {
    return (state.puppetDeferredTurns || []).find(row => row.playerId === playerId && !row.consumedAt) || null;
  }

  function activeAppealFor(playerId) {
    return (state.puppetAppealQueue || []).find(row => row.playerId === playerId && !row.consumedAt && (
      typeof window.__havocAppealWindowOpen !== 'function' || window.__havocAppealWindowOpen(row.sourceCycle)
    )) || null;
  }

  renderPendingPuppetOverview = function renderEligiblePuppetNext20() {
    const event = currentEvent();
    const cycle = Number(state.puppetCycle || 1);
    const picker = window.__havocTentativePuppetPlayers;
    const next20 = typeof picker === 'function' && event ? picker(event, 20) : [];

    let currentQueueNo = 0;
    let nextCycleQueueNo = 0;
    const rows = next20.map((member, index) => {
      const deferred = activeDeferredFor(member.id);
      const appeal = activeAppealFor(member.id);
      let detail = '';
      let tag = '';

      if (deferred) {
        detail = `Make-up · Cycle ${Number(deferred.sourceCycle || cycle)}`;
        tag = '<span class="pill purple">MAKE-UP</span>';
      } else if (appeal) {
        detail = `Approved appeal · Cycle ${Number(appeal.sourceCycle || cycle)}`;
        tag = '<span class="pill purple">APPEAL</span>';
      } else if (!member.puppetComplete) {
        currentQueueNo += 1;
        detail = `Current Cycle ${cycle} · Next in line #${currentQueueNo}`;
        tag = '<span class="pill green">CURRENT</span>';
      } else {
        nextCycleQueueNo += 1;
        detail = `Cycle ${cycle + 1} · Queue #${nextCycleQueueNo}`;
        tag = '<span class="pill amber">NEXT CYCLE</span>';
      }

      return `<div class="puppet-pending-member"><span>${index + 1}</span><div><strong>${esc(member.name)}</strong><small>${detail}</small></div>${tag}</div>`;
    }).join('');

    const currentCount = next20.filter(member => !member.puppetComplete && !activeDeferredFor(member.id) && !activeAppealFor(member.id)).length;
    const makeUpCount = next20.filter(member => activeDeferredFor(member.id) || activeAppealFor(member.id)).length;
    const nextCycleCount = next20.length - currentCount - makeUpCount;

    return `<div class="card puppet-pending-overview"><div class="section-head"><div><h2>Next in Line for Puppet Rotation</h2><p>Up to 20 eligible bidders. 96H, LOA, Cannot Bid and no-show members are excluded. Approved make-ups come first, then current-cycle bidders, then the next-cycle queue.</p></div><span class="pill amber">NEXT ${next20.length}</span></div>${next20.length ? `<div class="rotation-note">${makeUpCount ? `${makeUpCount} make-up${makeUpCount === 1 ? '' : 's'} · ` : ''}${currentCount} current-cycle · ${nextCycleCount} next-cycle</div><div class="puppet-pending-grid">${rows}</div>` : '<div class="empty-state">No eligible Puppet bidders for this event.</div>'}</div>`;
  };
})();
