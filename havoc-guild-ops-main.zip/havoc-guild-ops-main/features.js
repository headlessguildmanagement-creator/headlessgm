(function () {
  "use strict";

  const ROUTES = {
    overview: "/",
    lineup: "/lineup-builder",
    lineupview: "/line-up",
    loa: "/loa",
    profile: "/update-account",
    jobchanges: "/job-changes",
    marketplace: "/marketplace",
    auctionbuilder: "/auction-builder",
    auction: "/auction",
    auctionhistory: "/auction-history",
    puppet: "/puppet-rotation",
    puppetappeals: "/puppet-appeals",
    members: "/members",
    access: "/access"
  };
  const PATH_VIEWS = {
    "/": "overview",
    "/line-up": "lineupview",
    "/lineup-builder": "lineup",
    "/loa": "loa",
    "/update-job": "profile",
    "/update-account": "profile",
    "/job-changes": "jobchanges",
    "/marketplace": "marketplace",
    "/auction-builder": "auctionbuilder",
    "/auction": "auction",
    "/auction-history": "auctionhistory",
    "/puppet-rotation": "puppet",
    "/puppet-appeals": "puppetappeals",
    "/members": "members",
    "/access": "access"
  };
  const OFFICER_ONLY = new Set(["lineup", "lineupview", "jobchanges", "auctionbuilder", "puppet", "members", "access"]);
  let requestedInitialView = PATH_VIEWS[location.pathname] || "overview";
  if (location.pathname === "/update-job") {
    history.replaceState({}, "", `/update-account${location.search}`);
  }
  let routeEventApplied = false;
  let pendingLineupSync = false;
  let lineupChangeVersion = 0;
  let lastPersistFailed = false;

  if (requestedInitialView === "lineupview" && accessMode === "member") currentView = "lineup";
  else if (!OFFICER_ONLY.has(requestedInitialView)) currentView = requestedInitialView;
  else currentView = "overview";

  const originalPersistState = persistState;
  persistState = async function () {
    try {
      const result = await originalPersistState();
      lastPersistFailed = false;
      return result;
    } catch (error) {
      lastPersistFailed = true;
      throw error;
    }
  };

  function currentOfficerName() {
    return currentAdmin || currentAccount?.()?.owner || "Officer";
  }

  function locationOfPlayer(event, playerId) {
    for (const raid of ["main", "sub"]) {
      for (let party = 0; party < event.lineups[raid].length; party++) {
        const slot = event.lineups[raid][party].indexOf(playerId);
        if (slot >= 0) return { raid, party: party + 1, slot: slot + 1 };
      }
    }
    return null;
  }

  function recordLineupChange(action, details = {}) {
    if (!state || !eventById(selectedEventId)) return;
    state.lineupHistory ??= [];
    state.lineupHistory.push({
      id: crypto.randomUUID(),
      eventId: selectedEventId,
      eventName: eventById(selectedEventId).name,
      officer: currentOfficerName(),
      action,
      details,
      changedAt: new Date().toISOString()
    });
    state.lineupHistory = state.lineupHistory.slice(-300);
    pendingLineupSync = true;
    lineupChangeVersion++;
  }
  window.havocRecordLineupChange = recordLineupChange;

  function watchCurrentSync() {
    const watchedVersion = lineupChangeVersion;
    const watchedQueue = syncQueue;
    Promise.resolve(watchedQueue).then(() => {
      if (watchedVersion === lineupChangeVersion && !lastPersistFailed) pendingLineupSync = false;
    });
  }
  window.havocWatchLineupSync = watchCurrentSync;

  const originalMovePlayer = movePlayer;
  movePlayer = function (playerId, party, slot) {
    const event = eventById(selectedEventId);
    const member = player(playerId);
    if (!event || !member || isAbsent(event, playerId)) return originalMovePlayer(playerId, party, slot);
    const from = locationOfPlayer(event, playerId);
    const replacedId = event.lineups[selectedRaid]?.[party]?.[slot] || null;
    recordLineupChange(from ? "Player moved" : "Player assigned", {
      playerId,
      playerName: member.name,
      from,
      to: { raid: selectedRaid, party: party + 1, slot: slot + 1 },
      replacedPlayer: replacedId ? player(replacedId)?.name || null : null
    });
    const result = originalMovePlayer(playerId, party, slot);
    watchCurrentSync();
    return result;
  };

  const originalRemoveFromLineup = removeFromLineup;
  removeFromLineup = function (playerId) {
    const event = eventById(selectedEventId);
    const member = player(playerId);
    const from = event ? locationOfPlayer(event, playerId) : null;
    if (event && member && from) recordLineupChange("Player removed", { playerId, playerName: member.name, from });
    const result = originalRemoveFromLineup(playerId);
    if (from) watchCurrentSync();
    return result;
  };

  const originalMarkNoShow = markNoShow;
  markNoShow = function (playerId, absent) {
    const event = eventById(selectedEventId);
    const member = player(playerId);
    const alreadyAbsent = Boolean(event?.noShows?.includes(playerId));
    if (event && member && alreadyAbsent !== absent) recordLineupChange(absent ? "Player marked absent" : "Player restored", { playerId, playerName: member.name });
    const result = originalMarkNoShow(playerId, absent);
    if (alreadyAbsent !== absent) watchCurrentSync();
    return result;
  };

  const originalCopyPreviousLineup = copyPreviousLineup;
  copyPreviousLineup = function () {
    const current = eventById(selectedEventId);
    const previous = state.events.filter(event => event.id !== current?.id && event.date < current?.date && event.lineups && assignedIds(event).size).sort((a, b) => b.date.localeCompare(a.date))[0];
    if (current && previous) recordLineupChange("Previous lineup imported", { sourceEventId: previous.id, sourceEventName: previous.name, sourceDate: previous.date });
    const result = originalCopyPreviousLineup();
    if (current && previous) watchCurrentSync();
    return result;
  };

  const originalSaveCurrentLineup = saveCurrentLineup;
  saveCurrentLineup = async function (button) {
    const versionBeforeSave = lineupChangeVersion;
    const result = await originalSaveCurrentLineup(button);
    if (!lastPersistFailed) {
      pendingLineupSync = false;
      if (state.lineupHistory?.at(-1)?.action !== "Lineup saved") {
        recordLineupChange("Lineup saved", { assigned: assignedIds(eventById(selectedEventId)).size });
        try {
          await persistState();
          pendingLineupSync = false;
        } catch (_) {
          pendingLineupSync = true;
        }
      } else if (versionBeforeSave === lineupChangeVersion) pendingLineupSync = false;
    }
    return result;
  };

  function routeForCurrentView() {
    if (currentView === "lineup" && accessMode === "member") return "/line-up";
    return ROUTES[currentView] || "/";
  }

  function updateAddress(replace = false) {
    const event = eventById(selectedEventId);
    const path = routeForCurrentView();
    const query = ["lineup", "lineupview", "auctionbuilder", "auction", "puppet", "loa"].includes(currentView) && event ? `?event=${encodeURIComponent(event.id)}` : "";
    const url = `${path}${query}`;
    if (`${location.pathname}${location.search}` === url) return;
    history[replace ? "replaceState" : "pushState"]({ view: currentView, eventId: event?.id || null }, "", url);
  }

  function confirmPendingChange() {
    return !pendingLineupSync || confirm("The latest Lineup change has not finished saving to Supabase. Leave this view anyway?");
  }

  window.addEventListener("beforeunload", event => {
    if (!pendingLineupSync) return;
    event.preventDefault();
    event.returnValue = "";
  });

  document.querySelector("#nav")?.addEventListener("click", event => {
    const button = event.target.closest("button[data-view]");
    if (!button) return;
    if (!confirmPendingChange()) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);

  document.addEventListener("click", event => {
    if (event.target.closest("#nav button[data-view], [data-go-lineup]")) {
      requestedInitialView = null;
      queueMicrotask(() => updateAddress());
    }
  });

  document.addEventListener("change", event => {
    if (!event.target.matches("#event-select")) return;
    queueMicrotask(() => updateAddress(true));
  });

  window.addEventListener("popstate", () => {
    if (!confirmPendingChange()) {
      updateAddress(true);
      return;
    }
    const requested = PATH_VIEWS[location.pathname] || "overview";
    if ((OFFICER_ONLY.has(requested) && accessMode !== "commander") || (requested === "access" && !isSuperAdmin())) currentView = requested === "lineupview" ? "lineup" : "overview";
    else currentView = requested;
    const eventId = new URLSearchParams(location.search).get("event");
    if (eventId && eventById(eventId)) selectedEventId = eventId;
    render();
  });

  function jobSummaryData(event = null) {
    const activePlayers = state.players.filter(member => member.active);
    const jobOf = member => member.job || "Job not set";
    const totals = activePlayers.reduce((result, member) => ((result[jobOf(member)] = (result[jobOf(member)] || 0) + 1), result), {});
    const ordered = [...JOBS.filter(Boolean), "Job not set"];
    const jobs = ordered.filter(job => totals[job]).concat(Object.keys(totals).filter(job => !ordered.includes(job)).sort((a, b) => a.localeCompare(b)));
    if (!event) return { jobs, totals, availableTotals: {}, available: [] };
    const used = assignedIds(event);
    const available = activePlayers.filter(member => !used.has(member.id) && !isAbsent(event, member.id));
    const availableTotals = available.reduce((result, member) => ((result[jobOf(member)] = (result[jobOf(member)] || 0) + 1), result), {});
    return { jobs, totals, availableTotals, available };
  }

  function iconMarkup(job, sizeClass = "") {
    return icon(job) ? `<img class="${sizeClass}" src="${icon(job)}" alt=""/>` : "";
  }

  function mountJobSummaries() {
    if (currentView === "overview" && !document.querySelector("#app .job-count-dropdown")) {
      const card = document.querySelector("#app .grid.stats .stat");
      if (!card) return;
      const { jobs, totals } = jobSummaryData();
      const details = document.createElement("details");
      details.className = "job-count-dropdown";
      details.innerHTML = `<summary>View job breakdown <span>${jobs.length} classes</span></summary><div class="job-count-grid">${jobs.map(job => `<div class="job-count-item">${iconMarkup(job)}<span>${esc(job)}</span><strong>${totals[job]}</strong></div>`).join("")}</div>`;
      card.append(details);
    }
    if (currentView === "lineup" && accessMode === "commander" && !document.querySelector("#app .lineup-job-summary")) {
      const event = eventById(selectedEventId);
      const finder = document.querySelector("#app .lineup-finder");
      if (!event || !finder) return;
      const { jobs, totals, availableTotals, available } = jobSummaryData(event);
      const panel = document.createElement("div");
      panel.className = "card lineup-job-summary";
      panel.innerHTML = `<div class="lineup-job-heading"><div><strong>Available job classes</strong><small>${available.length} players not yet assigned to Main or Sub</small></div><span class="pill green">LIVE COUNTDOWN</span></div><div class="lineup-job-grid">${jobs.map(job => `<div class="lineup-job-item">${iconMarkup(job)}<span><strong>${esc(job)}</strong><small>${availableTotals[job] || 0} available · ${totals[job]} total</small></span></div>`).join("")}</div>`;
      finder.after(panel);
    }
  }

  function formatHistoryDetails(entry) {
    const details = entry.details || {};
    if (details.playerName) return details.playerName;
    if (details.sourceEventName) return `${details.sourceEventName} · ${details.sourceDate}`;
    if (details.raid) return `${String(details.raid).toUpperCase()} · ${details.removed || 0} removed`;
    if (Number.isFinite(details.assigned)) return `${details.assigned} assigned`;
    return "";
  }

  function mountLineupHistory() {
    if (currentView !== "lineup" || accessMode !== "commander" || document.querySelector("#app .lineup-history")) return;
    const layout = document.querySelector("#app .lineup-layout");
    if (!layout) return;
    const entries = (state.lineupHistory || []).filter(entry => entry.eventId === selectedEventId).slice(-20).reverse();
    const panel = document.createElement("details");
    panel.className = "card lineup-history";
    panel.innerHTML = `<summary><span><strong>Lineup change history</strong><small>${entries.length} recent record${entries.length === 1 ? "" : "s"}</small></span><span>⌄</span></summary><div class="lineup-history-list">${entries.length ? entries.map(entry => `<div class="lineup-history-row"><div><strong>${esc(entry.action)}</strong><small>${esc(formatHistoryDetails(entry))}</small></div><div><strong>${esc(entry.officer || "Officer")}</strong><small>${new Date(entry.changedAt).toLocaleString("en-PH", { timeZone: PH_TIMEZONE })}</small></div></div>`).join("") : '<div class="empty-state">No Lineup changes recorded for this event.</div>'}</div>`;
    layout.after(panel);
  }

  function csvCell(value) {
    const text = value == null ? "" : String(value);
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  }

  function downloadFile(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function rowsToCsv(rows) {
    return rows.map(row => row.map(csvCell).join(",")).join("\n");
  }

  function exportMembers() {
    const rows = [["Player", "Job", "Lineup Role", "Guild Role", "Feather Group", "Puppet Status", "Active"]];
    state.players.forEach(member => rows.push([member.name, member.job, member.role, member.guildTitle, member.auctionGroup ? `Group ${member.auctionGroup}` : "", member.puppetComplete ? "Done" : "Pending", member.active ? "Yes" : "No"]));
    downloadFile("havoc-members.csv", rowsToCsv(rows), "text/csv;charset=utf-8");
  }

  function exportLineup() {
    const event = eventById(selectedEventId);
    const rows = [["Event", "Date", "Raid", "Party", "Slot", "Player", "Job", "Role", "Party Leader"]];
    for (const raid of ["main", "sub"]) event.lineups[raid].forEach((party, partyIndex) => party.forEach((playerId, slotIndex) => {
      if (!playerId) return;
      const member = player(playerId);
      rows.push([event.name, event.date, raid.toUpperCase(), partyIndex + 1, slotIndex + 1, member?.name, member?.job, member?.role, slotIndex === 0 ? "Yes" : "No"]);
    }));
    downloadFile(`havoc-lineup-${event.id}.csv`, rowsToCsv(rows), "text/csv;charset=utf-8");
  }

  function exportAttendance() {
    const rows = [["Event", "Date", "Player", "Status", "LOA Reason", "Filed At"]];
    state.events.forEach(event => state.players.filter(member => member.active).forEach(member => {
      const loa = state.loas.find(entry => entry.eventId === event.id && entry.playerId === member.id && !entry.cancelledAt);
      const status = loa ? "LOA" : event.noShows.includes(member.id) ? "Absent" : "Attending";
      if (status !== "Attending") rows.push([event.name, event.date, member.name, status, loa?.reason || "", loa?.filedAt || ""]);
    }));
    downloadFile("havoc-attendance-loa.csv", rowsToCsv(rows), "text/csv;charset=utf-8");
  }

  function exportAuctions() {
    const rows = [["Event", "Date", "Player", "Tab", "Category", "Page Assignment"]];
    state.events.filter(event => event.auction?.assignments).forEach(event => summarizeAssignments(event.auction.assignments).forEach(assignment => rows.push([event.name, event.date, player(assignment.playerId)?.name || "", assignment.tab, assignment.category, assignment.pageText])));
    downloadFile("havoc-auction-history.csv", rowsToCsv(rows), "text/csv;charset=utf-8");
  }

  function exportBackup() {
    downloadFile(`havoc-backup-${localISO(new Date())}.json`, JSON.stringify(publicStateSnapshot(), null, 2), "application/json;charset=utf-8");
  }

  function mountExports() {
    if (currentView !== "access" || !isSuperAdmin() || document.querySelector("#app .admin-exports")) return;
    const panel = document.createElement("div");
    panel.className = "card admin-exports";
    panel.innerHTML = `<div class="section-head"><div><h2>Data exports and backup</h2><p>Download read-only copies without changing Supabase.</p></div></div><div class="export-grid"><button class="button ghost" data-export="members">Members CSV</button><button class="button ghost" data-export="lineup">Current Lineup CSV</button><button class="button ghost" data-export="attendance">Attendance & LOA CSV</button><button class="button ghost" data-export="auctions">Auction History CSV</button><button class="button" data-export="backup">Complete JSON Backup</button></div>`;
    document.querySelector("#app")?.append(panel);
    const actions = { members: exportMembers, lineup: exportLineup, attendance: exportAttendance, auctions: exportAuctions, backup: exportBackup };
    panel.querySelectorAll("[data-export]").forEach(button => button.addEventListener("click", () => actions[button.dataset.export]()));
  }

  async function notifyLoaDiscord(action, loa) {
    if (!officerSession || accessMode !== "commander" || !loa) return;
    const event = eventById(loa.eventId);
    const member = player(loa.playerId);
    if (!event || !member) return;
    try {
      await syncQueue;
      if (lastPersistFailed) throw new Error("LOA was not saved, so Discord was not notified");
      const response = await fetch("/api/discord-publish", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${officerSession.access_token}` },
        body: JSON.stringify({
          type: action === "cancelled" ? "loa_cancelled" : "loa_filed",
          eventId: event.id,
          eventName: event.name,
          eventDate: event.date,
          playerName: member.name,
          reason: loa.reason || ""
        })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "LOA Discord notification failed");
      toast(`LOA ${action === "cancelled" ? "cancellation" : "filing"} sent to Discord`);
    } catch (error) {
      console.error("Havoc LOA Discord notification failed", error);
      toast(error.message || "LOA saved, but Discord notification failed");
    }
  }
  window.havocNotifyLoa = notifyLoaDiscord;

  function canvasRoundRect(ctx, x, y, width, height, radius = 16) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
  }

  function canvasLines(ctx, text, maxWidth) {
    const words = String(text || "").split(/\s+/);
    const lines = [];
    let line = "";
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (line && ctx.measureText(test).width > maxWidth) {
        lines.push(line);
        line = word;
      } else line = test;
    }
    if (line) lines.push(line);
    return lines.length ? lines : [""];
  }

  function paintShareBackground(ctx, width, height, eyebrow, title, subtitle) {
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, "#0b0b0f");
    gradient.addColorStop(1, "#1a1012");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = "#c51f35";
    ctx.fillRect(0, 0, 14, height);
    ctx.font = "800 22px Arial, sans-serif";
    ctx.fillStyle = "#e0444f";
    ctx.fillText(eyebrow, 62, 58);
    ctx.font = "900 46px Arial, sans-serif";
    ctx.fillStyle = "#f3ebdd";
    ctx.fillText(title, 62, 112);
    ctx.font = "500 22px Arial, sans-serif";
    ctx.fillStyle = "#aaa6a0";
    ctx.fillText(subtitle, 62, 150);
  }

  function drawShareCard(ctx, x, y, width, height) {
    canvasRoundRect(ctx, x, y, width, height, 16);
    ctx.fillStyle = "#15161b";
    ctx.fill();
    ctx.strokeStyle = "#34343d";
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  function paintShareFooter(ctx, width, height, instruction) {
    ctx.font = "700 20px Arial, sans-serif";
    ctx.fillStyle = "#f3ebdd";
    ctx.fillText(instruction, 62, height - 32);
  }

  function generateLineupDiscordImages(event) {
    const width = 1200, height = 1660;
    return [["MAIN RAID", "main", "#ff6a1a"], ["SUB RAID", "sub", "#e0444f"]].map(([label, raid, accent]) => {
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      paintShareBackground(ctx, width, height, "HAVOC GUILD OPERATIONS", `LINEUP · ${label}`, `${event.name} · ${formatDate(event.date)} · 8:30 PM PHT`);
      event.lineups[raid].forEach((party, index) => {
        const x = 54, y = 190 + index * 170;
        drawShareCard(ctx, x, y, 1092, 154);
        ctx.font = "900 24px Arial, sans-serif";
        ctx.fillStyle = accent;
        ctx.fillText(`PARTY ${index + 1}`, x + 22, y + 32);
        party.forEach((id, slot) => {
          const member = id ? player(id) : null;
          const lineY = y + 61 + slot * 19;
          ctx.font = "700 20px Arial, sans-serif";
          ctx.fillStyle = member ? "#f3ebdd" : "#69666a";
          const leader = slot === 0 && member ? " · PARTY LEADER" : "";
          ctx.fillText(`${slot + 1}. ${member ? `${member.name} · ${member.job || "Job not set"}${leader}` : "Open slot"}`, x + 22, lineY);
        });
      });
      paintShareFooter(ctx, width, height, "Use the clickable Discord message link to open the live lineup.");
      return { title: label, filename: `havoc-lineup-${raid}.png`, data: canvas.toDataURL("image/png") };
    });
  }

  function groupedAuctionEntries(rows) {
    const groups = new Map();
    for (const row of rows) {
      if (!groups.has(row.playerId)) groups.set(row.playerId, []);
      groups.get(row.playerId).push(row);
    }
    return [...groups].sort((a, b) => player(a[0]).name.localeCompare(player(b[0]).name, undefined, { sensitivity: "base" }));
  }

  function generateAuctionBidGuideImage(event) {
    const width = 1200, height = 1280;
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    paintShareBackground(ctx, width, height, "HAVOC GUILD OPERATIONS", "HOW TO BID CORRECTLY", `${event.name} · ${formatDate(event.date)}`);
    const cards = [
      { number: "1", title: "FEATHER ASSIGNMENTS", accent: "#e0444f", lines: ["Open the FEATHER tab in the in-game auction.", "Do not use the All tab."] },
      { number: "2", title: "PUPPET FRAGMENT ASSIGNMENTS", accent: "#ff6a1a", lines: ["Open the CARDS tab in the in-game auction.", "Do not use the All tab."] },
      { number: "3", title: "FOLLOW YOUR EXACT ASSIGNMENT", accent: "#a98be8", lines: ["Go to the exact PAGE listed for your IGN.", "Bid only on the exact ITEM NUMBER(S) assigned to you."] }
    ];
    cards.forEach((card, index) => {
      const x = 54, y = 210 + index * 280;
      drawShareCard(ctx, x, y, 1092, 240);
      ctx.fillStyle = card.accent;
      ctx.beginPath(); ctx.arc(x + 70, y + 72, 38, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#101016";
      ctx.font = "900 34px Arial, sans-serif";
      ctx.textAlign = "center"; ctx.fillText(card.number, x + 70, y + 84); ctx.textAlign = "left";
      ctx.fillStyle = card.accent;
      ctx.font = "900 29px Arial, sans-serif";
      ctx.fillText(card.title, x + 132, y + 62);
      ctx.fillStyle = "#f3ebdd";
      ctx.font = "700 27px Arial, sans-serif";
      card.lines.forEach((line, lineIndex) => ctx.fillText(line, x + 132, y + 116 + lineIndex * 48));
    });
    ctx.fillStyle = "#e0444f";
    ctx.fillRect(54, 1070, 1092, 92);
    ctx.fillStyle = "#fff";
    ctx.font = "900 30px Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("NEVER BID FROM THE ALL TAB", width / 2, 1128);
    ctx.textAlign = "left";
    paintShareFooter(ctx, width, height, "Check the assignment images after this guide.");
    return { title: "HOW TO BID CORRECTLY", filename: "havoc-auction-bid-guide.png", data: canvas.toDataURL("image/png") };
  }

  function generateAuctionPage(event, entries, title, filename, instruction) {
    const width = 1200, cardWidth = 1092, textWidth = cardWidth - 44;
    const measure = document.createElement("canvas").getContext("2d");
    measure.font = "700 21px Arial, sans-serif";
    const heights = entries.map(([, rows]) => 82 + rows.reduce((sum, row) => sum + 38 + canvasLines(measure, row.pageText, textWidth).length * 29, 0));
    const height = Math.max(720, 190 + heights.reduce((sum, value) => sum + value + 18, 0) + 105);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    paintShareBackground(ctx, width, height, "HAVOC GUILD OPERATIONS", title, `${event.name} · ${formatDate(event.date)} · Feather Group ${event.activeGroup}`);
    let y = 190;
    entries.forEach(([id, rows], index) => {
      const cardHeight = heights[index];
      drawShareCard(ctx, 54, y, cardWidth, cardHeight);
      ctx.font = "900 30px Arial, sans-serif";
      ctx.fillStyle = "#f3ebdd";
      ctx.fillText(player(id)?.name || "Unknown player", 78, y + 41);
      let cursor = y + 78;
      for (const row of rows) {
        ctx.font = "900 19px Arial, sans-serif";
        ctx.fillStyle = row.tab === "Cards" ? "#ff6a1a" : "#e0444f";
        ctx.fillText(`${row.tab.toUpperCase()} · ${row.category}`, 78, cursor);
        cursor += 31;
        ctx.font = "700 21px Arial, sans-serif";
        ctx.fillStyle = "#f3ebdd";
        for (const line of canvasLines(ctx, row.pageText, textWidth)) {
          ctx.fillText(line, 78, cursor);
          cursor += 29;
        }
        cursor += 9;
      }
      y += cardHeight + 18;
    });
    paintShareFooter(ctx, width, height, instruction);
    return { title, filename, data: canvas.toDataURL("image/png") };
  }

  function generateAuctionDiscordImages(event) {
    const rows = summarizeAssignments(event.auction.assignments);
    const feathers = groupedAuctionEntries(rows.filter(row => row.tab === "Feather"));
    const puppets = groupedAuctionEntries(rows.filter(row => row.tab === "Cards"));
    const images = [generateAuctionBidGuideImage(event)];
    const chunkSize = 10;
    for (let index = 0; index < feathers.length; index += chunkSize) {
      const part = Math.floor(index / chunkSize) + 1;
      const totalParts = Math.ceil(feathers.length / chunkSize);
      images.push(generateAuctionPage(event, feathers.slice(index, index + chunkSize), `FEATHER ASSIGNMENTS${totalParts > 1 ? ` · ${part}/${totalParts}` : ""}`, `havoc-auction-feathers-${part}.png`, "Open the Feather tab—not All. Live assignments:"));
    }
    if (puppets.length) images.push(generateAuctionPage(event, puppets, "PUPPET FRAGMENT ASSIGNMENTS", "havoc-auction-puppets.png", "Open the Cards tab—not All. Live assignments:"));
    return images;
  }

  function generateTentativeDiscordImages(event) {
    const width = 1200, rowHeight = 64;
    const feather = state.players.filter(p => p.active && Number(p.auctionGroup) === Number(event.activeGroup)).sort((a,b) => a.name.localeCompare(b.name));
    const puppetLimit = event.type === "EO" ? 20 : 8;
    const puppet = state.players.filter(p => p.active && Number.isInteger(p.puppetOrder) && !p.puppetComplete).sort((a,b) => a.puppetOrder-b.puppetOrder).slice(0,puppetLimit);
    const rows = Math.max(feather.length, puppet.length);
    const height = Math.max(720, 260 + rows * rowHeight);
    const canvas = document.createElement("canvas"); canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext("2d");
    paintShareBackground(ctx, width, height, "HAVOC GUILD OPERATIONS", "TOMORROW'S TENTATIVE BIDDERS", `${event.name} · ${formatDate(event.date)} · Group ${event.activeGroup}`);
    ctx.font = "900 25px Arial, sans-serif"; ctx.fillStyle = "#f5eee2"; ctx.fillText("FEATHER BIDDERS", 62, 205); ctx.fillText("NEXT IN LINE FOR PUPPET ROTATION", 635, 205);
    ctx.font = "700 22px Arial, sans-serif";
    feather.forEach((p,i)=>{ctx.fillStyle="#f5eee2";ctx.fillText(`${i+1}. ${p.name}`,62,250+i*rowHeight)});
    puppet.forEach((p,i)=>{ctx.fillStyle="#f5eee2";ctx.fillText(`${i+1}. ${p.name}`,635,250+i*rowHeight)});
    ctx.fillStyle="#b8b2aa";ctx.font="600 18px Arial, sans-serif";ctx.fillText("Tentative bidder list",62,height-40);
    return [{title:"TOMORROW'S TENTATIVE BIDDERS",filename:"havoc-tomorrow-tentative-bidders.png",data:canvas.toDataURL("image/png")}];
  }

  function generateDiscordImages(type, event) {
    return type === "lineup" ? generateLineupDiscordImages(event) : type === "tentative" ? generateTentativeDiscordImages(event) : generateAuctionDiscordImages(event);
  }

  async function publishToDiscord(type, button) {
    if (!officerSession || accessMode !== "commander") return toast("Officer login is required");
    const event = eventById(selectedEventId);
    if (!event) return toast("Selected event was not found");
    if (type === "auction" && !event.auction) return toast("Generate auction assignments before publishing");
    const publishedAtKey = type === "lineup" ? "lineupPublishedAt" : type === "tentative" ? "tentativePublishedAt" : "auctionPublishedAt";
    if (event[publishedAtKey] && !confirm(`This ${type === "lineup" ? "Lineup" : "Auction"} was already published. Publish another Discord notification?`)) return;
    button.disabled = true;
    const originalText = button.textContent;
    button.textContent = "Publishing…";
    try {
      await persistState();
      const images = generateDiscordImages(type, event);
      const response = await fetch("/api/discord-publish", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${officerSession.access_token}` },
        body: JSON.stringify({ type, eventId: event.id, eventName: event.name, eventDate: event.date, images })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "Discord notification failed");
      event[publishedAtKey] = new Date().toISOString();
      event[`${type}PublishedBy`] = currentOfficerName();
      if (type === "lineup") recordLineupChange("Lineup published", { discordMessageId: result.messageId || null });
      await persistState();
      pendingLineupSync = false;
      toast(`${type === "lineup" ? "Lineup" : "Auction assignments"} published to Discord`);
      render();
    } catch (error) {
      console.error(error);
      toast(error.message || "Discord notification failed");
    } finally {
      if (button.isConnected) {
        button.disabled = false;
        button.textContent = originalText;
      }
    }
  }

  function mountPublishButtons() {
    if (accessMode !== "commander") return;
    if (currentView === "lineup" && !document.querySelector("#publish-lineup")) {
      const toolbar = document.querySelector("#app > .section-head .toolbar");
      if (toolbar) {
        const button = document.createElement("button");
        button.className = "button publish-button";
        button.id = "publish-lineup";
        button.textContent = "Publish Lineup";
        button.addEventListener("click", () => publishToDiscord("lineup", button));
        toolbar.append(button);
      }
    }
    if (currentView === "auctionbuilder" && eventById(selectedEventId)?.auction) {
      const button = document.querySelector("#publish-auction");
      if (button && !button.dataset.discordBound) {
        button.dataset.discordBound = "true";
        button.addEventListener("click", () => publishToDiscord("auction", button));
      }
    }
  }

  function applyRequestedRoute() {
    if (requestedInitialView && accessMode === "commander") {
      const targetView = requestedInitialView === "access" && !isSuperAdmin() ? "overview" : requestedInitialView;
      requestedInitialView = null;
      if (currentView !== targetView) {
        currentView = targetView;
        render();
        return true;
      }
      return false;
    }
    if (requestedInitialView === "lineupview" && accessMode === "member" && document.querySelector("#app")?.childElementCount) requestedInitialView = null;
    return false;
  }

  function applyEventFromUrl() {
    if (routeEventApplied) return false;
    const eventId = new URLSearchParams(location.search).get("event");
    routeEventApplied = true;
    if (eventId && eventById(eventId) && selectedEventId !== eventId) {
      selectedEventId = eventId;
      render();
      return true;
    }
    return false;
  }

  function mountAllFeatures() {
    if (!document.querySelector("#app")?.childElementCount) return;
    if (applyRequestedRoute()) return;
    if (applyEventFromUrl()) return;
    mountJobSummaries();
    mountLineupHistory();
    mountExports();
    mountPublishButtons();
    updateAddress(true);
  }

  const app = document.querySelector("#app");
  if (app) {
    let scheduled = false;
    new MutationObserver(() => {
      if (scheduled) return;
      scheduled = true;
      queueMicrotask(() => {
        scheduled = false;
        mountAllFeatures();
      });
    }).observe(app, { childList: true });
    queueMicrotask(mountAllFeatures);
  }

  // Expose the browser-based publisher for the officer Overview one-click button.
  window.publishToDiscord = publishToDiscord;
})();
