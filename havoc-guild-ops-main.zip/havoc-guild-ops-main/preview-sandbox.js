(() => {
  fetch("/api/config", { cache: "no-store" }).then(response => response.json()).then(config => {
    if (!config?.preview || document.querySelector("#preview-sandbox-banner")) return;
    const banner = document.createElement("div");
    banner.id = "preview-sandbox-banner";
    banner.className = "preview-sandbox-banner";
    banner.innerHTML = '<strong>PREVIEW SANDBOX</strong><span>Guild-state changes stay in this preview branch. Discord sends are suppressed.</span>';
    document.body.prepend(banner);
  }).catch(() => {});
})();