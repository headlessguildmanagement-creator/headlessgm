import { copyFileSync, cpSync, mkdirSync, readdirSync, rmSync } from "node:fs";
import { join } from "node:path";

const PUBLIC_PROJECT_ID = "prj_WDRrueAeTyVZxS9P9qk9BE8QWXbc";
const productionUrl = String(process.env.VERCEL_PROJECT_PRODUCTION_URL || "");
const deploymentUrl = String(process.env.VERCEL_URL || "");
const isPublic = process.env.VERCEL_PROJECT_ID === PUBLIC_PROJECT_ID
  || productionUrl.includes("havoc-guild-rooc")
  || deploymentUrl.includes("havoc-guild-rooc");

const out = "public";
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
cpSync("assets", join(out, "assets"), { recursive: true });

if (isPublic) {
  copyFileSync("public-home.html", join(out, "index.html"));
  copyFileSync("public-marketplace.html", join(out, "marketplace.html"));
  copyFileSync("public-post-listing.html", join(out, "post.html"));
  copyFileSync("public-apply.html", join(out, "apply.html"));
  for (const file of ["public.css", "public-common.js", "public-marketplace.js", "public-post-listing.js", "public-apply.js"]) copyFileSync(file, join(out, file));
  console.log("Built HAVOC public site output");
} else {
  for (const file of readdirSync(".")) if (file.endsWith(".js") || file.endsWith(".css")) copyFileSync(file, join(out, file));
  copyFileSync("index.html", join(out, "index.html"));
  copyFileSync("apply.html", join(out, "apply.html"));
  const spaRoutes = ["lineup-builder","line-up","loa","update-job","update-account","job-changes","marketplace","auction-builder","auction","auction-history","puppet-rotation","puppet-appeals","members","access"];
  for (const route of spaRoutes) copyFileSync("index.html", join(out, route + ".html"));
  console.log("Built HAVOC Guild Ops output");
}
