(() => {
  function label(view) {
    if (view === 'auctionhistory') return 'Auction History';
    if (view === 'puppetappeals') return 'Puppet Appeals';
    return navLabel(view);
  }
  const originalNavLabel=navLabel;
  navLabel=function(view){
    if(view==='auctionhistory') return 'Auction History';
    if(view==='puppetappeals') return 'Puppet Appeals';
    return originalNavLabel(view);
  };

  function ensureNav() {
    const nav=document.querySelector('#nav');
    if(!nav) return;
    const auction=nav.querySelector('[data-view="auction"]');
    if(auction && !nav.querySelector('[data-view="auctionhistory"]')){
      const b=document.createElement('button'); b.dataset.view='auctionhistory'; b.textContent='Auction History'; auction.after(b);
      b.addEventListener('click',()=>{currentView='auctionhistory';history.replaceState({},'', '/auction-history');render();});
    }
    const appeal=nav.querySelector('[data-view="puppetappeals"]');
    if(appeal) appeal.textContent='Puppet Appeals';
  }

  const originalRender=render;
  render=function standaloneHistoryRender(){
    if(currentView!=='auctionhistory') { const result=originalRender(); ensureNav(); return result; }
    document.querySelectorAll('#nav button').forEach(b=>{b.classList.toggle('active',b.dataset.view==='auctionhistory'); if(b.dataset.view==='puppetappeals') b.textContent='Puppet Appeals';});
    const eyebrow=document.querySelector('#page-eyebrow'), title=document.querySelector('#page-title');
    if(eyebrow) eyebrow.textContent='AUCTION';
    if(title) title.textContent='Auction History';
    document.querySelector('#app').innerHTML=window.renderAuctionHistoryPage();
    bindView(); window.__havocBindAuctionHistory?.(); ensureNav();
  };

  if(location.pathname==='/auction-history') currentView='auctionhistory';
  const observer=new MutationObserver(ensureNav); observer.observe(document.documentElement,{childList:true,subtree:true}); ensureNav();
})();