(() => {
  let memberPreview = false;
  let returnView = 'overview';
  let attentionLoadToken = 0;

  function restrictedOfficerView(view) {
    return ['members','access','jobchanges','lineupview','auctionbuilder','puppet','applicants'].includes(view);
  }

  function ensurePreviewToggle() {
    const actions = document.querySelector('.top-actions');
    if (!actions || !officerSession) return;
    let button = document.querySelector('#member-preview-toggle');
    if (!button) {
      button = document.createElement('button');
      button.id = 'member-preview-toggle';
      button.className = 'button ghost';
      actions.prepend(button);
      button.addEventListener('click', () => {
        if (memberPreview) exitMemberPreview();
        else enterMemberPreview();
      });
    }
    button.textContent = memberPreview ? 'Return to Officer View' : 'Preview as Member';
    button.classList.remove('hidden');
  }

  function syncPreviewChrome() {
    document.querySelector('#member-preview-banner')?.remove();
    if (!memberPreview) return;

    const login = document.querySelector('#officer-login-trigger');
    const logout = document.querySelector('#officer-logout');
    const changePassword = document.querySelector('#officer-change-password');
    login?.classList.add('hidden');
    logout?.classList.add('hidden');
    changePassword?.classList.add('hidden');

    const app = document.querySelector('#app');
    if (app) {
      const banner = document.createElement('div');
      banner.id = 'member-preview-banner';
      banner.className = 'notice warning member-preview-banner';
      banner.innerHTML = '<strong>Member Preview Mode</strong> — You are still signed in as an officer. Officer controls are hidden until you return to Officer View.';
      app.before(banner);
    }
  }

  function enterMemberPreview() {
    if (!officerSession || accessMode !== 'commander') return toast('Officer login is required');
    returnView = currentView;
    memberPreview = true;
    accessMode = 'member';
    if (restrictedOfficerView(currentView)) currentView = 'overview';
    render();
  }

  function exitMemberPreview() {
    if (!officerSession) return;
    memberPreview = false;
    accessMode = 'commander';
    currentView = viewMeta[returnView] ? returnView : 'overview';
    render();
  }

  function nextOperationalEvent() {
    return state.events.find(event => eventRotationEndsAt(event) > new Date()) || state.events.at(-1);
  }

  function eventIsTodayOrTomorrow(event) {
    if (!event?.date) return false;
    const today = localISO(new Date());
    return event.date === today || event.date === addDateDays(today, 1);
  }

  function activeEventLoas(event) {
    return (state.loas || []).filter(row => row.eventId === event?.id && !row.cancelledAt);
  }

  function syncAttentionItems(event) {
    const items = [];
    const loas = activeEventLoas(event);
    const rosterMissing = typeof rosterCompletenessAlerts === 'function' ? rosterCompletenessAlerts() : [];
    const supportMissing = typeof partySupportAlerts === 'function' ? partySupportAlerts(event) : [];
    const staleAuction = Boolean(event && !event.auction && (event.auctionPublishedAt || event.auctionPublishedBy || event.puppetCompletionRecordedAt));

    if (staleAuction) {
      items.push({severity:'red', title:'Auction state needs review', detail:`${event.name} · ${formatDate(event.date)} has publication/completion metadata without a current auction.`, view:'auctionbuilder'});
    } else if (event?.auction && !event.auctionPublishedAt) {
      items.push({severity:'amber', title:'Official auction not published', detail:`The ${event.name} auction exists but has not been published to Discord yet.`, view:'auction'});
    }

    if (event && eventIsTodayOrTomorrow(event) && !event.tentativePublishedAt) {
      items.push({severity:'amber', title:'Possible Bidders not sent', detail:`No Possible Bidders reminder is recorded yet for ${event.name} · ${formatDate(event.date)}.`, view:'overview'});
    }

    if (loas.length) {
      items.push({severity:'amber', title:`${loas.length} active LOA${loas.length === 1 ? '' : 's'}`, detail:`For ${event.name} · ${formatDate(event.date)}.`, view:'loa'});
    }

    if (rosterMissing.length) {
      items.push({severity:'red', title:`${rosterMissing.length} incomplete member record${rosterMissing.length === 1 ? '' : 's'}`, detail:'Missing Job, Lineup Role, or Feather Group.', view:'members'});
    }

    if (supportMissing.length) {
      items.push({severity:'red', title:`${supportMissing.length} lineup support warning${supportMissing.length === 1 ? '' : 's'}`, detail:'Started parties without a Support role assigned.', view:'lineup'});
    }

    return items;
  }

  function attentionRow(item) {
    const button = item.view ? `<button class="button ghost small smart-overview-open" data-view="${item.view}">Open</button>` : '';
    return `<div class="event-row smart-overview-row"><span class="pill ${item.severity}">${item.severity === 'red' ? 'ACTION' : 'CHECK'}</span><div><strong>${esc(item.title)}</strong><p>${esc(item.detail)}</p></div>${button}</div>`;
  }

  function renderAttentionItems(items, loading = false) {
    const list = document.querySelector('#smart-overview-list');
    const badge = document.querySelector('#smart-overview-count');
    if (!list || !badge) return;
    badge.textContent = loading ? 'CHECKING' : `${items.length} ITEM${items.length === 1 ? '' : 'S'}`;
    badge.className = `pill ${loading ? 'purple' : items.some(x => x.severity === 'red') ? 'red' : items.length ? 'amber' : 'green'}`;
    list.innerHTML = items.length ? items.map(attentionRow).join('') : loading ? '<div class="empty-state">Checking live officer items…</div>' : '<div class="empty-state">Nothing needs officer attention right now.</div>';
    bindAttentionButtons();
  }

  function bindAttentionButtons() {
    document.querySelectorAll('.smart-overview-open').forEach(button => {
      if (button.dataset.bound === '1') return;
      button.dataset.bound = '1';
      button.addEventListener('click', () => {
        currentView = button.dataset.view || 'overview';
        render();
      });
    });
  }

  async function enrichAttentionItems(baseItems, token) {
    if (!officerSession?.access_token || accessMode !== 'commander' || memberPreview) return;
    const headers = { Authorization: `Bearer ${officerSession.access_token}` };
    const items = [...baseItems];
    const needsReply = app => {
      const messages = app.messages || [];
      const lastApplicant = [...messages].reverse().find(m => m.sender_type === 'applicant');
      const lastOfficer = [...messages].reverse().find(m => m.sender_type === 'officer');
      return Boolean(lastApplicant && (!lastOfficer || lastApplicant.created_at > lastOfficer.created_at));
    };

    const [applicationResult, appealResult] = await Promise.allSettled([
      fetch('/api/applications-officer', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'list' })
      }).then(async response => {
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || 'Application check failed');
        return body.applications || [];
      }),
      fetch('/api/state-store', { headers }).then(async response => {
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || 'Appeal check failed');
        return body.appeals || [];
      })
    ]);

    if (token !== attentionLoadToken || accessMode !== 'commander' || currentView !== 'overview' || memberPreview) return;

    if (applicationResult.status === 'fulfilled') {
      const applications = applicationResult.value;
      const count = applications.filter(app => app.status === 'new' || needsReply(app)).length;
      if (count) items.unshift({severity:'red', title:`${count} applicant${count === 1 ? '' : 's'} need attention`, detail:'New application or applicant reply waiting for officer review.', view:'applicants'});
    }

    if (appealResult.status === 'fulfilled') {
      const pending = appealResult.value.filter(row => row.status === 'pending' && !row.cycleClosed).length;
      if (pending) items.unshift({severity:'red', title:`${pending} Puppet appeal${pending === 1 ? '' : 's'} pending`, detail:'Review the recorded bidding date and submitted proof before approving a make-up.', view:'puppet'});
    }

    renderAttentionItems(items, false);
  }

  function mountSmartOverview() {
    if (accessMode !== 'commander' || memberPreview || currentView !== 'overview') return;
    const app = document.querySelector('#app');
    const anchor = app?.querySelector('.grid.stats');
    if (!app || !anchor || document.querySelector('#smart-officer-overview')) return;

    const event = nextOperationalEvent();
    const baseItems = syncAttentionItems(event);
    const card = document.createElement('div');
    card.id = 'smart-officer-overview';
    card.className = 'card smart-officer-overview';
    card.innerHTML = `<div class="section-head"><div><h2>Officer Attention</h2><p>Automatic checks only — no officer checklist to maintain.</p></div><span id="smart-overview-count" class="pill purple">CHECKING</span></div><div id="smart-overview-list"></div>`;
    anchor.before(card);
    renderAttentionItems(baseItems, true);
    const token = ++attentionLoadToken;
    enrichAttentionItems(baseItems, token).catch(error => {
      console.warn('Smart overview check failed', error);
      if (token === attentionLoadToken) renderAttentionItems(baseItems, false);
    });
  }

  const oldRender = render;
  render = function previewAndSmartOverviewRender() {
    const result = oldRender();
    ensurePreviewToggle();
    syncPreviewChrome();
    mountSmartOverview();
    return result;
  };

  const style = document.createElement('style');
  style.textContent = `
    .member-preview-banner{margin:0 0 16px}
    .smart-officer-overview{margin-bottom:18px}
    .smart-overview-row{grid-template-columns:auto minmax(0,1fr) auto;align-items:center}
    .smart-overview-row .button{white-space:nowrap}
    @media(max-width:640px){
      .smart-overview-row{grid-template-columns:auto minmax(0,1fr)}
      .smart-overview-row .button{grid-column:2;justify-self:start}
      #member-preview-toggle{order:-1;width:100%}
      .top-actions{flex-wrap:wrap}
    }
  `;
  document.head.appendChild(style);

  window.__havocEnterMemberPreview = enterMemberPreview;
  window.__havocExitMemberPreview = exitMemberPreview;
  window.__havocIsMemberPreview = () => memberPreview;

  render();
})();