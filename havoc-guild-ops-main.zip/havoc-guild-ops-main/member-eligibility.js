(() => {
  const MANILA_TIME_ZONE = "Asia/Manila";

  function manilaParts(value) {
    if (value == null || value === "") return null;
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return null;
    const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
      timeZone: MANILA_TIME_ZONE,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23"
    }).formatToParts(date).filter(part => part.type !== "literal").map(part => [part.type, part.value]));
    return {
      date: `${parts.year}-${parts.month}-${parts.day}`,
      hour: Number(parts.hour),
      minute: Number(parts.minute)
    };
  }

  function addDays(date, days) {
    const value = new Date(`${date}T00:00:00Z`);
    value.setUTCDate(value.getUTCDate() + days);
    return value.toISOString().slice(0, 10);
  }

  function eligibilityDate(member) {
    const parts = manilaParts(member?.memberAddedAt);
    if (!parts) return null;
    const beforeCallTime = parts.hour < 20 || (parts.hour === 20 && parts.minute < 30);
    return addDays(parts.date, beforeCallTime ? 4 : 5);
  }

  function isEligible(member, event) {
    if (!member?.active || !event?.date) return false;
    const eligibleOn = eligibilityDate(member);
    return Boolean(eligibleOn && event.date >= eligibleOn);
  }

  window.havocMemberEligibilityDate = eligibilityDate;
  window.havocIsMemberEligibleForEvent = isEligible;

  const originalIsPuppetUnavailable = isPuppetUnavailable;
  isPuppetUnavailable = function penaltyAwarePuppetUnavailable(event, playerId) {
    const member = player(playerId);
    return originalIsPuppetUnavailable(event, playerId) || !isEligible(member, event);
  };

  const originalEligibleFeatherPlayers = eligibleFeatherPlayers;
  eligibleFeatherPlayers = function penaltyAwareFeatherPlayers(event) {
    return originalEligibleFeatherPlayers(event).filter(member => isEligible(member, event));
  };

  const originalOfficerAtRotation = officerAtRotation;
  officerAtRotation = function penaltyAwareOfficerRotation(index, event) {
    const penaltyIds = (state.players || [])
      .filter(member => member.active && !isEligible(member, event))
      .map(member => member.id);
    if (!penaltyIds.length) return originalOfficerAtRotation(index, event);
    const clone = {
      ...event,
      ineligibleFeatherIds: [...new Set([...(event?.ineligibleFeatherIds || []), ...penaltyIds])]
    };
    return originalOfficerAtRotation(index, clone);
  };

  const originalRenderPuppetQueue = renderPuppetQueue;
  renderPuppetQueue = function penaltyAwarePuppetQueue() {
    const html = originalRenderPuppetQueue();
    const event = eventById(selectedEventId) || state.events[0];
    if (!event || typeof document === "undefined") return html;
    const list = (state.players || [])
      .filter(member => member.active && Number.isInteger(member.puppetOrder))
      .sort((a, b) => a.puppetOrder - b.puppetOrder);
    const template = document.createElement("template");
    template.innerHTML = html;
    const rows = [...template.content.querySelectorAll("tbody tr")];
    rows.forEach((row, index) => {
      const member = list[index];
      if (!member || isEligible(member, event)) return;
      const eligibleOn = eligibilityDate(member);
      if (row.children[2]) row.children[2].innerHTML = '<span class="pill red">96H PENALTY</span>';
      if (row.children[3]) row.children[3].textContent = eligibleOn ? `Eligible ${formatDate(eligibleOn)}` : "Eligibility pending";
      if (row.children[4]) row.children[4].innerHTML = "—";
    });
    return template.innerHTML;
  };

  const originalMountFeatherEligibility = typeof mountFeatherEligibility === "function" ? mountFeatherEligibility : null;
  if (originalMountFeatherEligibility) {
    mountFeatherEligibility = function penaltyAwareFeatherEligibilityPanel() {
      const result = originalMountFeatherEligibility();
      const event = eventById(selectedEventId);
      if (!event) return result;
      for (const member of state.players || []) {
        if (!member.active || Number(member.auctionGroup) !== Number(event.activeGroup) || isEligible(member, event)) continue;
        const button = document.querySelector(`.feather-eligibility-toggle[data-player="${member.id}"]`);
        const row = button?.closest(".eligibility-row");
        const status = row?.querySelector(".pill");
        const reason = row?.querySelector(".eligibility-reason");
        if (status) {
          status.className = "pill red";
          status.textContent = "INELIGIBLE · 96-HOUR PENALTY";
        }
        if (reason) {
          reason.value = "96-Hour Penalty";
          reason.disabled = true;
        }
        if (button) {
          button.disabled = true;
          button.textContent = "Automatic";
        }
      }
      return result;
    };
  }
})();
