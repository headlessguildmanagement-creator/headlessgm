(() => {
  "use strict";

  function recruitmentGroup(nav) {
    return [...nav.querySelectorAll(":scope > details.nav-group")].find(group =>
      group.querySelector(":scope > summary")?.textContent?.trim() === "RECRUITMENT"
    ) || null;
  }

  function auctionGroup(nav) {
    return [...nav.querySelectorAll(":scope > details.nav-group")].find(group =>
      group.querySelector(":scope > summary")?.textContent?.trim() === "AUCTION"
    ) || null;
  }

  function syncApplicantsNav() {
    const nav = document.querySelector("#nav");
    if (!nav) return;

    let button = nav.querySelector('[data-view="applicants"]');
    let group = recruitmentGroup(nav);

    if (accessMode !== "commander") {
      button?.remove();
      if (group && !group.querySelector('button[data-view]')) group.remove();
      return;
    }

    if (!button) {
      button = document.createElement("button");
      button.dataset.view = "applicants";
      button.innerHTML = "<span>Applicants</span>";
    }

    if (nav.dataset.compacted === "true") {
      if (!group) {
        group = document.createElement("details");
        group.className = "nav-group";
        const summary = document.createElement("summary");
        summary.textContent = "RECRUITMENT";
        group.appendChild(summary);
        const before = auctionGroup(nav);
        nav.insertBefore(group, before || null);
      }
      if (button.parentElement !== group) group.appendChild(button);
      if (currentView === "applicants") group.open = true;
    } else if (button.parentElement !== nav) {
      const before = nav.querySelector('[data-view="auctionbuilder"]');
      nav.insertBefore(button, before || null);
    }

    button.classList.toggle("active", currentView === "applicants");
  }

  const previousRender = render;
  render = function applicationsNavSafeRender(...args) {
    syncApplicantsNav();
    const result = previousRender.apply(this, args);
    syncApplicantsNav();
    return result;
  };

  document.addEventListener("click", event => {
    if (event.target.closest("#officer-login-trigger, #officer-logout, #nav")) {
      queueMicrotask(syncApplicantsNav);
    }
  });

  syncApplicantsNav();
  window.__havocSyncApplicantsNav = syncApplicantsNav;
})();
