
(() => {
  const PAGE_SIZE = 4;
  let data = { listings: [], offers: [] };
  let filter = "all";
  let page = 1;
  let hideCompleted = true;
  let searchQuery = "";
  const manageState = new Map();

  const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const money = v => v === null || v === "" || v === undefined ? "Negotiable" : `₱${Number(v).toLocaleString("en-PH",{maximumFractionDigits:2})}`;
  const offersFor = id => (data.offers || []).filter(x => x.listing_id === id && ["active","accepted"].includes(x.status));
  const statusText = listing => listing.status === "sold" ? (listing.intent === "buy" ? "FOUND" : listing.intent === "trade" ? "TRADED" : "SOLD") : listing.status.toUpperCase();

  async function api(payload = null, method = "GET") {
    const options = method === "POST" ? {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)} : {};
    return havocPublicApi("/api/config?proxy=marketplace", options);
  }

  async function load() {
    const errorBox = document.querySelector("#market-error");
    try {
      data = await api();
      render();
      errorBox.classList.add("hidden");
    } catch (error) {
      errorBox.textContent = error.message;
      errorBox.classList.remove("hidden");
    }
  }

  function media(listing) {
    const first = listing.images?.[0]?.url;
    return first ? `<div class="listing-media"><img src="${first}" alt="${esc(listing.title)}"/></div>` : "";
  }

  function offerList(listing) {
    const rows = offersFor(listing.id);
    if (!rows.length) return '<div style="color:#777;font-size:13px;margin:12px 0">No offers yet.</div>';
    return `<div class="offer-list">${rows.map(row => `<div class="offer-row"><div><strong>${esc(row.buyer_ign)}</strong>${row.note ? `<small>${esc(row.note)}</small>` : ""}</div><span>${money(row.amount)}</span></div>`).join("")}</div>`;
  }

  function offerForm(listing) {
    if (listing.status !== "listed") return "";
    return `<form class="offer-form public-offer-form" data-listing="${listing.id}" novalidate>
      <input class="input" name="buyerIgn" maxlength="40" required placeholder="Your IGN"/>
      <input class="input" name="amount" type="number" min="1" step="1" required placeholder="Offer ₱"/>
      <input class="input full" name="note" maxlength="500" placeholder="Note (optional)"/>
      <button type="submit" class="button small full public-offer-submit" data-offer-submit="${listing.id}">Send offer</button>
    </form>`;
  }

  function manageBox(listing) {
    const saved = manageState.get(listing.id) || {};
    const isOpen = Boolean(saved.open);
    const title = saved.title ?? listing.title;
    const price = saved.price ?? (listing.price ?? "");
    const description = saved.description ?? (listing.description || "");
    const password = listing.hasListingPassword ? (saved.password || "") : "";
    return `<div class="manage-box" data-manage-box="${listing.id}">
      <button type="button" class="manage-toggle" data-manage-toggle="${listing.id}" aria-expanded="${isOpen ? "true" : "false"}">${isOpen ? "Close management" : "Manage this listing"}</button>
      <div class="manage-actions ${isOpen ? "" : "hidden"}" data-manage-panel="${listing.id}">
        ${listing.hasListingPassword
          ? `<input class="input manage-password" type="password" value="${esc(password)}" placeholder="Listing password"/>`
          : `<div class="no-password-warning"><strong>No Listing Password.</strong> Anyone can manage this listing.</div>`}
        <input class="input manage-title" maxlength="120" value="${esc(title)}"/>
        <input class="input manage-price" type="number" min="0" step="1" value="${esc(price)}" placeholder="Price / offer"/>
        <textarea class="input manage-description" rows="2" maxlength="1000" placeholder="Details">${esc(description)}</textarea>
        <div class="row">
          <button type="button" class="button small manage-update" data-manage-action="update" data-id="${listing.id}">Update</button>
          ${listing.status === "listed" ? `<button type="button" class="button small secondary manage-status" data-manage-action="status" data-id="${listing.id}" data-status="sold">Mark completed</button>` : `<button type="button" class="button small secondary manage-status" data-manage-action="status" data-id="${listing.id}" data-status="listed">Reopen</button>`}
          <button type="button" class="button small ghost manage-remove" data-manage-action="remove" data-id="${listing.id}">Remove</button>
        </div>
        <small style="color:#777">${listing.hasListingPassword ? "Use the Listing Password set when this listing was posted." : "Because no Listing Password was set, these controls are public."}</small>
      </div>
    </div>`;
  }

  function card(listing) {
    const badge = listing.source === "internal" ? '<span class="member-badge">HAVOC MEMBER</span>' : "";
    const passwordBadge = listing.hasListingPassword
      ? '<span class="password-badge password-set">🔒 PASSWORD PROTECTED</span>'
      : '<span class="password-badge password-none">NO LISTING PASSWORD</span>';
    return `<article class="listing-card">
      ${media(listing)}
      <div class="listing-body">
        <div class="listing-top">
          <div>
            <div class="listing-type">${esc(listing.intent.toUpperCase())} · ${esc(listing.category)} ${badge}</div>
            <div class="listing-security">${passwordBadge}</div>
            <h3>${esc(listing.title)}</h3>
            <div class="poster">Posted by <strong>${esc(listing.seller_ign)}</strong> · <span class="status ${listing.status}">${esc(statusText(listing))}</span></div>
          </div>
          <div class="price">${money(listing.price)}</div>
        </div>
        ${listing.description ? `<p class="desc">${esc(listing.description)}</p>` : ""}
        <div style="margin-top:14px" data-offers-section="${listing.id}"><strong style="font-size:12px">OFFERS</strong>${offerList(listing)}</div>
        ${offerForm(listing)}
        ${listing.source === "public" ? manageBox(listing) : ""}
      </div>
    </article>`;
  }

  function listingMatchesSearch(listing) {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    const listingOffers = offersFor(listing.id);
    const searchable = [
      listing.title,
      listing.category,
      listing.seller_ign,
      listing.price,
      listing.price_text,
      listing.description,
      ...listingOffers.flatMap(row => [row.buyer_ign, row.amount, row.note])
    ].filter(value => value !== null && value !== undefined).join(" ").toLowerCase();
    return searchable.includes(query);
  }

  function render() {
    const rows = (data.listings || []).filter(x =>
      (filter === "all" || x.intent === filter) &&
      (!hideCompleted || x.status === "listed") &&
      listingMatchesSearch(x)
    );
    const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
    page = Math.min(page, pages);
    const visible = rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
    document.querySelector("#listing-grid").innerHTML = visible.map(card).join("") || '<div class="panel" style="grid-column:1/-1;color:#888">No listings found.</div>';
    const count = document.querySelector("#market-search-count");
    if (count) count.textContent = searchQuery.trim() ? `${rows.length} listing${rows.length === 1 ? "" : "s"} found` : "";
    document.querySelector("#pagination").innerHTML = pages > 1 ? `<button type="button" data-page="${page-1}" ${page===1?"disabled":""}>Previous</button><span style="padding:9px 4px;color:#888">Page ${page} of ${pages}</span><button type="button" data-page="${page+1}" ${page===pages?"disabled":""}>Next</button>` : "";
  }

  async function sendPublicOffer(form) {
    if (!form || form.dataset.submitting === "true") return;
    const buyerIgn = form.querySelector('[name="buyerIgn"]')?.value.trim() || "";
    const amount = form.querySelector('[name="amount"]')?.value || "";
    const note = form.querySelector('[name="note"]')?.value || "";

    if (!buyerIgn) {
      alert("Enter your IGN.");
      form.querySelector('[name="buyerIgn"]')?.focus({ preventScroll: true });
      return;
    }
    if (!amount || Number(amount) <= 0) {
      alert("Enter a valid offer amount.");
      form.querySelector('[name="amount"]')?.focus({ preventScroll: true });
      return;
    }

    const listingId = form.dataset.listing;
    const button = form.querySelector(".public-offer-submit");
    form.dataset.submitting = "true";
    if (button) {
      button.disabled = true;
      button.textContent = "Sending...";
    }

    try {
      await api({
        action:"make_offer",
        listingId,
        buyerIgn,
        amount,
        note
      },"POST");

      form.reset();

      const fresh = await api();
      data = fresh;
      const listing = (data.listings || []).find(row => row.id === listingId);
      const offersSection = document.querySelector(`[data-offers-section="${listingId}"]`);
      if (offersSection && listing) {
        offersSection.innerHTML = `<strong style="font-size:12px">OFFERS</strong>${offerList(listing)}`;
      }

      const success = document.createElement("div");
      success.className = "success offer-success";
      success.textContent = "Offer sent.";
      form.insertAdjacentElement("afterend", success);
      setTimeout(() => success.remove(), 2500);
    } catch (error) {
      alert(error.message);
    } finally {
      delete form.dataset.submitting;
      if (button?.isConnected) {
        button.disabled = false;
        button.textContent = "Send offer";
      }
    }
  }

  const listingGrid = document.querySelector("#listing-grid");
  const paginationRoot = document.querySelector("#pagination");

  listingGrid?.addEventListener("submit", event => {
    const form = event.target.closest?.(".public-offer-form");
    if (!form) return;
    event.preventDefault();
    event.stopPropagation();
    sendPublicOffer(form);
  });

  async function runManageAction(button) {
    const root = button.closest(".manage-box");
    const id = button.dataset.id;
    if (!root || !id || button.dataset.running === "true") return;

    const listing = (data.listings || []).find(row => row.id === id);
    if (!listing) return;

    const password = listing.hasListingPassword
      ? (root.querySelector(".manage-password")?.value || "")
      : "";

    if (listing.hasListingPassword && !password) {
      alert("Enter the Listing Password first.");
      return;
    }

    const action = button.dataset.manageAction;
    button.dataset.running = "true";
    button.disabled = true;

    try {
      if (action === "update") {
        await api({
          action:"update_listing",
          listingId:id,
          password,
          title:root.querySelector(".manage-title")?.value || "",
          price:root.querySelector(".manage-price")?.value || "",
          description:root.querySelector(".manage-description")?.value || ""
        },"POST");
      } else if (action === "status") {
        await api({
          action:"set_status",
          listingId:id,
          password,
          status:button.dataset.status
        },"POST");
      } else if (action === "remove") {
        if (!confirm("Remove this listing completely?")) return;
        await api({action:"remove_listing",listingId:id,password},"POST");
        data.listings = (data.listings || []).filter(row => row.id !== id);
        data.offers = (data.offers || []).filter(row => row.listing_id !== id);
        root.closest(".listing-card")?.remove();
        manageState.delete(id);
        return;
      } else {
        return;
      }

      const fresh = await api();
      data = fresh;
      const updated = (data.listings || []).find(row => row.id === id);
      const cardEl = root.closest(".listing-card");
      if (updated && cardEl) {
        const wrapper = document.createElement("div");
        wrapper.innerHTML = card(updated).trim();
        const replacement = wrapper.firstElementChild;
        if (replacement) cardEl.replaceWith(replacement);
      }
    } catch (error) {
      alert(error.message);
    } finally {
      delete button.dataset.running;
      if (button.isConnected) button.disabled = false;
    }
  }

  listingGrid?.addEventListener("click", event => {
    const manageAction = event.target.closest?.("[data-manage-action]");
    if (manageAction) {
      event.preventDefault();
      event.stopPropagation();
      runManageAction(manageAction);
      return;
    }

    const manageToggle = event.target.closest?.("[data-manage-toggle]");
    if (manageToggle) {
      event.preventDefault();
      event.stopPropagation();
      const id = manageToggle.dataset.manageToggle;
      const panel = listingGrid.querySelector(`[data-manage-panel="${id}"]`);
      const willOpen = panel?.classList.contains("hidden");
      const state = manageState.get(id) || {};
      state.open = willOpen;
      manageState.set(id, state);
      panel?.classList.toggle("hidden", !willOpen);
      manageToggle.setAttribute("aria-expanded", willOpen ? "true" : "false");
      manageToggle.textContent = willOpen ? "Close management" : "Manage this listing";
    }
  });

  document.querySelectorAll("[data-filter]").forEach(button => {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      filter = button.dataset.filter;
      page = 1;
      document.querySelectorAll("[data-filter]").forEach(x => x.classList.toggle("active", x === button));
      render();
    });
  });

  paginationRoot?.addEventListener("click", event => {
    const pageButton = event.target.closest?.("[data-page]");
    if (!pageButton || pageButton.disabled) return;
    event.preventDefault();
    event.stopPropagation();
    page = Number(pageButton.dataset.page) || 1;
    render();
    const grid = document.querySelector("#listing-grid");
    if (grid) window.scrollTo({top:grid.offsetTop-90,behavior:"smooth"});
  });

  listingGrid?.addEventListener("input", event => {
    const root = event.target.closest?.("[data-manage-box]");
    if (!root) return;
    const id = root.dataset.manageBox;
    const state = manageState.get(id) || { open: true };
    if (event.target.classList.contains("manage-password")) state.password = event.target.value;
    if (event.target.classList.contains("manage-title")) state.title = event.target.value;
    if (event.target.classList.contains("manage-price")) state.price = event.target.value;
    if (event.target.classList.contains("manage-description")) state.description = event.target.value;
    state.open = true;
    manageState.set(id, state);
  });

  const hideCompletedToggle = document.querySelector("[data-public-hide-completed]");
  hideCompletedToggle?.addEventListener("change", event => {
    event.stopPropagation();
    hideCompleted = Boolean(event.currentTarget.checked);
    page = 1;
    render();
  });

  const marketplaceSearchControl = document.querySelector("[data-marketplace-search-control]");

  document.querySelector("[data-market-search-submit]")?.addEventListener("click", event => {
    event.preventDefault();
    event.stopImmediatePropagation();
    const input = marketplaceSearchControl?.querySelector("[data-market-search-input]");
    searchQuery = input?.value || "";
    page = 1;
    document.querySelector("#market-search-clear")?.classList.toggle("hidden", !searchQuery);
    render();
  });

  document.querySelector("#market-search-clear")?.addEventListener("click", event => {
    event.preventDefault();
    event.stopImmediatePropagation();
    const input = marketplaceSearchControl?.querySelector("[data-market-search-input]");
    if (input) input.value = "";
    searchQuery = "";
    page = 1;
    document.querySelector("#market-search-clear")?.classList.add("hidden");
    render();
  });

  // Search input itself never triggers filtering. It only holds text until SEARCH is clicked.
  document.querySelector("[data-market-search-input]")?.addEventListener("keydown", event => {
    if (event.key === "Enter") event.preventDefault();
  });

  load();
})();
