
const HAVOC_API_ORIGIN = location.origin;

async function havocPublicApi(path, options = {}) {
  const response = await fetch(`${HAVOC_API_ORIGIN}${path}`, options);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || "Request failed");
  return body;
}

async function loadPublicRoster() {
  const targets = {
    count: document.querySelector("#home-roster-count"),
    status: document.querySelector("#home-roster-status"),
    applyCount: document.querySelector("#apply-roster-count"),
    applyStatus: document.querySelector("#apply-roster-status")
  };
  if (!Object.values(targets).some(Boolean)) return;
  try {
    const data = await havocPublicApi("/api/config?proxy=roster");
    const countText = `${data.active} / ${data.capacity}`;
    const statusText = data.available > 0
      ? `${data.available} slot${data.available === 1 ? "" : "s"} available`
      : "Guild currently full";
    if (targets.count) targets.count.textContent = countText;
    if (targets.status) targets.status.textContent = statusText;
    if (targets.applyCount) targets.applyCount.textContent = countText;
    if (targets.applyStatus) targets.applyStatus.textContent = data.available > 0
      ? `Applications are open. ${statusText}.`
      : "Applications are still open and will remain on file for officer review.";
  } catch (error) {
    if (targets.count) targets.count.textContent = "Roster unavailable";
    if (targets.status) targets.status.textContent = "Try again later";
    if (targets.applyCount) targets.applyCount.textContent = "Roster unavailable";
    if (targets.applyStatus) targets.applyStatus.textContent = "Roster status could not be loaded.";
  }
}
loadPublicRoster();


document.addEventListener("click", event => {
  const link = event.target.closest(".site-header a[href]");
  if (!link) return;
  const href = link.getAttribute("href");
  if (!href || !href.startsWith("/")) return;
  event.preventDefault();
  event.stopPropagation();
  window.location.assign(href);
}, true);
