(() => {
  let eventPage = 1;
  let cyclePage = 1;
  const PAGE_SIZE = 5;
  const unique = values => [...new Set((values || []).filter(Boolean))];

  function derivedRows() {
    const recorded = new Map((state.auctionHistory || []).map(row => [row.eventId, row]));
    const rows = (state.events || []).filter(event => event.date >= '2026-08-30' && event.date < localISO(new Date())).map(event => {
      if (recorded.has(event.id)) return recorded.get(event.id);
      const assignments = event.auction?.assignments || [];
      const name = id => player(id)?.name || id;
      return {
        eventId:event.id,date:event.date,eventName:event.name,eventType:event.type,group:event.activeGroup,
        featherBidders:unique(assignments.filter(a=>a.tab==='Feather').map(a=>name(a.playerId))),
        puppetBidders:unique(assignments.filter(a=>a.category==='Puppet Fragment').map(a=>name(a.playerId))),
        marketplaceDeals:unique(assignments.filter(a=>a.marketplaceListingId&&a.marketplaceOriginalPlayerId).map(a=>a.marketplaceListingId)).map(listingId=>{const a=assignments.find(x=>x.marketplaceListingId===listingId);return{listingId,rightType:a.marketplaceRightType||(a.category==='Puppet Fragment'?'puppet':'feather'),originalPlayerId:a.marketplaceOriginalPlayerId,originalPlayerName:name(a.marketplaceOriginalPlayerId),bidderPlayerId:a.playerId,bidderPlayerName:name(a.playerId),source:'Marketplace · SOLD'}}),
        reconstructed:true
      };
    });
    return rows.sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  }

  function pills(values) {
    return values?.length ? values.map(value=>`<span class="pill purple">${esc(value)}</span>`).join(' ') : '<span class="muted">Names unavailable in retained assignment data</span>';
  }

  function puppetCycleHistory() {
    const histories=[...(state.puppetCycleHistory || [])].sort((a,b)=>Number(b.cycle)-Number(a.cycle));
    if (!histories.length) return '<div class="empty-state">No completed Puppet cycles recorded.</div>';
    const pages=Math.max(1,Math.ceil(histories.length/PAGE_SIZE));
    cyclePage=Math.min(cyclePage,pages);
    const shown=histories.slice((cyclePage-1)*PAGE_SIZE,cyclePage*PAGE_SIZE);
    const cards=shown.map(history => {
      const members=[...(history.members || [])].sort((a,b)=>Number(a.order||0)-Number(b.order||0));
      return `<details class="card"><summary><strong>Cycle ${history.cycle}</strong> · Completed ${history.completedAt ? formatDate(localISO(new Date(history.completedAt))) : '—'} · ${members.length} recorded turns</summary><div class="table-wrap"><table><thead><tr><th>#</th><th>Player</th><th>Cycle result / bidding date</th></tr></thead><tbody>${members.map(m=>`<tr><td>${m.order ?? '—'}</td><td><strong>${esc(m.name || player(m.playerId)?.name || 'Unknown')}</strong></td><td>${m.completedAt ? `<span class="pill green">COMPLETED</span> ${formatDate(m.completedAt)}` : m.deferred96h ? '<span class="pill red">96H PENALTY</span>' : m.deferredTurn ? '<span class="pill purple">DEFERRED</span>' : '<span class="pill amber">NOT COMPLETED</span>'}</td></tr>`).join('')}</tbody></table></div></details>`;
    }).join('');
    return `${cards}<div class="card"><div class="section-head"><button class="button ghost" data-cycle-page="${cyclePage-1}" ${cyclePage<=1?'disabled':''}>Previous</button><strong>Page ${cyclePage} of ${pages}</strong><button class="button ghost" data-cycle-page="${cyclePage+1}" ${cyclePage>=pages?'disabled':''}>Next</button></div></div>`;
  }

  window.renderAuctionHistoryPage = function() {
    const rows=derivedRows();
    const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE));
    eventPage=Math.min(eventPage,pages);
    const shown=rows.slice((eventPage-1)*PAGE_SIZE,eventPage*PAGE_SIZE);
    return `<div class="card"><div class="section-head"><div><h2>Auction History</h2><p>Read-only guild record. Histories stay folded until opened.</p></div><span class="pill green">MEMBERS + OFFICERS</span></div></div>
      <div class="card"><div class="section-head"><div><h2>Feather & Puppet Bidding</h2><p>Five events per page.</p></div><span class="pill">${rows.length} EVENTS</span></div></div>
      ${shown.map(row=>`<details class="card"><summary><strong>${formatDate(row.date)} · ${esc(row.eventName || row.eventType || 'Event')}</strong> · Feather Group ${row.group || '—'}</summary><div class="auction-history-section"><label>FEATHER BIDDERS</label><div class="auction-history-names">${pills(row.featherBidders)}</div>${row.excessOfficerBidders?.length?`<p><strong>Excess → Officers:</strong> ${row.excessOfficerBidders.map(esc).join(', ')}</p>`:''}</div><div class="auction-history-section"><label>PUPPET BIDDERS</label><div class="auction-history-names">${pills(row.puppetBidders)}</div></div>${row.marketplaceDeals?.length?`<div class="auction-history-section"><label>MARKETPLACE BIDDING RIGHTS</label>${row.marketplaceDeals.map(deal=>`<div class="event-row"><span class="pill amber">${String(deal.rightType||"").toUpperCase()}</span><div><strong>${esc(deal.originalPlayerName||player(deal.originalPlayerId)?.name||"Unknown")} → ${esc(deal.bidderPlayerName||player(deal.bidderPlayerId)?.name||"Unknown")}</strong><p>SOLD · Original owner → actual bidder</p></div></div>`).join("")}</div>`:""}</details>`).join('') || '<div class="empty-state">No auction history.</div>'}
      <div class="card"><div class="section-head"><button class="button ghost" data-history-page="${eventPage-1}" ${eventPage<=1?'disabled':''}>Previous</button><strong>Page ${eventPage} of ${pages}</strong><button class="button ghost" data-history-page="${eventPage+1}" ${eventPage>=pages?'disabled':''}>Next</button></div></div>
      <div class="card"><div class="section-head"><div><h2>Puppet Cycle History</h2><p>Recorded completion history for transparency and appeal verification.</p></div></div></div>
      ${puppetCycleHistory()}`;
  };

  document.addEventListener('click', event => {
    const historyButton=event.target.closest?.('[data-history-page]');
    if(historyButton){eventPage=Number(historyButton.dataset.historyPage)||1;render();return;}
    const cycleButton=event.target.closest?.('[data-cycle-page]');
    if(cycleButton){cyclePage=Number(cycleButton.dataset.cyclePage)||1;render();}
  });
})();