(() => {
  if (typeof viewMeta !== "undefined") {
    viewMeta.jobchanges = ["OFFICER RECORDS", "Account Logs"];
  }

  if (typeof navLabel === "function") {
    const originalNavLabel = navLabel;
    navLabel = function patchedNavLabel(view) {
      if (view !== "jobchanges") return originalNavLabel(view);
      const count = typeof officerBadge === "function" ? officerBadge(view) : 0;
      return `<span>Account Logs</span>${count ? `<span class="nav-badge">${count}</span>` : ""}`;
    };
  }

  if (typeof renderJobChanges === "function") {
    renderJobChanges = function patchedRenderJobChanges() {
      const accountRows = Array.isArray(state.accountChangeLog) ? state.accountChangeLog : [];
      const jobRows = Array.isArray(state.jobChangeLog) ? state.jobChangeLog : [];
      const byId = new Map();

      for (const row of [...jobRows, ...accountRows]) {
        const key = row?.id || `${row?.playerId || ""}|${row?.changedAt || ""}|${row?.type || ""}`;
        byId.set(key, row);
      }

      const log = [...byId.values()].sort((a, b) => String(b.changedAt || "").localeCompare(String(a.changedAt || "")));

      return `<div class="section-head"><div><p>Combined record of IGN changes and job / lineup-role changes.</p></div><span class="pill amber">OFFICER ONLY</span></div><div class="card table-wrap"><table><thead><tr><th>Date</th><th>Type</th><th>Player</th><th>Previous</th><th>New</th><th>Reason</th></tr></thead><tbody>${log.map(x => {
        const ignChange = x?.type === "ign_change" || Boolean((x?.previousIgn || x?.oldIgn) && x?.newIgn);
        const previous = ignChange
          ? (x.previousIgn || x.oldIgn || "Unknown")
          : `${x.previousJob || "Unknown"}${x.previousRole ? ` · ${x.previousRole}` : ""}`;
        const next = ignChange
          ? (x.newIgn || "Unknown")
          : `${x.newJob || "Unknown"}${x.newRole ? ` · ${x.newRole}` : ""}`;
        const displayName = ignChange
          ? (x.newIgn || x.playerName || player(x.playerId)?.name)
          : (player(x.playerId)?.name || x.playerName);
        const changedAt = x.changedAt ? new Date(x.changedAt).toLocaleString("en-PH", { timeZone: PH_TIMEZONE, month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "—";
        return `<tr><td>${changedAt}</td><td><span class="pill ${ignChange ? "purple" : "green"}">${ignChange ? "IGN CHANGE" : "JOB CHANGE"}</span></td><td><strong>${esc(displayName || "Unknown")}</strong></td><td>${esc(previous)}</td><td><strong>${esc(next)}</strong></td><td>${esc(x.reason || "—")}</td></tr>`;
      }).join("") || '<tr><td colspan="6" class="empty-state">No account changes recorded yet.</td></tr>'}</tbody></table></div>`;
    };
  }
})();
