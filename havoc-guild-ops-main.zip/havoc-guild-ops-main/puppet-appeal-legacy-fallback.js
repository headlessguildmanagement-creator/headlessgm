(() => {
  function legacyTurnFor(playerId) {
    const member = (state.players || []).find(row => row.id === playerId && row.active !== false);
    if (!member || member.puppetComplete !== true || !member.puppetCompletedAt) return null;
    const event = (state.events || []).find(row => row.date === member.puppetCompletedAt);
    if (!event) return null;
    const endedAt = new Date(`${event.date}T${event.callTime || '20:30'}:00+08:00`);
    if (new Date() < endedAt) return null;
    return { member, event };
  }

  document.addEventListener('change', event => {
    if (event.target?.id !== 'puppet-appeal-player') return;
    const playerId = event.target.value;
    if (!playerId) return;
    const recorded = window.__havocEndedPuppetAssignmentsFor?.(playerId) || [];
    if (recorded.length) return;
    const legacy = legacyTurnFor(playerId);
    if (!legacy) return;

    event.stopImmediatePropagation();
    const select = document.querySelector('#puppet-appeal-event');
    if (!select) return;
    select.disabled = false;
    select.innerHTML = `<option value="">Select the turn you did not receive</option><option value="${legacy.event.id}">${formatDate(legacy.event.date)} · ${esc(legacy.event.name)} · Recorded completion (Page / Item unavailable)</option>`;
  }, true);

  window.__havocLegacyAppealableTurnFor = legacyTurnFor;
})();
