(() => {
  const nav = document.querySelector('#nav');
  if (!nav || nav.dataset.compacted === 'true') return;
  nav.dataset.compacted = 'true';
  const buttons = new Map([...nav.querySelectorAll('button[data-view]')].map(button => [button.dataset.view, button]));
  const groups = [
    ['MAIN', ['overview']],
    ['EVENTS', ['lineup','lineupview','loa']],
    ['MARKETPLACE', ['marketplace']],
    ['AUCTION', ['auctionbuilder','auction','auctionhistory','puppet','puppetappeals']],
    ['MEMBERS', ['profile','jobchanges','members']],
    ['ADMIN', ['access']]
  ];
  nav.innerHTML = '';
  for (const [label, views] of groups) {
    const available = views.map(view => buttons.get(view)).filter(Boolean);
    if (!available.length) continue;
    if (available.length === 1 && label === 'MAIN') {
      nav.appendChild(available[0]);
      continue;
    }
    const details = document.createElement('details');
    details.className = 'nav-group';
    details.open = available.some(button => button.classList.contains('active')) || label === 'EVENTS';
    const summary = document.createElement('summary');
    summary.textContent = label;
    details.appendChild(summary);
    available.forEach(button => details.appendChild(button));
    nav.appendChild(details);
  }
  nav.addEventListener('click', event => {
    const button = event.target.closest('button[data-view]');
    if (!button) return;
    button.closest('details')?.setAttribute('open','');
  });
})();
