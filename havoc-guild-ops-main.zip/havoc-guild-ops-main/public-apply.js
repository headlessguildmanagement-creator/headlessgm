
(() => {
  let supabaseClient = null;
  const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const fmt = value => value ? new Date(value).toLocaleString("en-PH",{timeZone:"Asia/Manila",month:"short",day:"numeric",year:"numeric",hour:"numeric",minute:"2-digit"}) : "Not yet submitted";

  async function applicationApi(payload) {
    return havocPublicApi("/api/config?proxy=applications", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
  }

  async function initStorage() {
    if (supabaseClient) return supabaseClient;
    const cfg = await havocPublicApi("/api/config");
    supabaseClient = window.supabase.createClient(cfg.url,cfg.publishableKey);
    return supabaseClient;
  }

  async function compressImage(file) {
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error(`${file.name}: unsupported image type`);
    if (file.size > 12 * 1024 * 1024) throw new Error(`${file.name}: source image is too large`);
    const bitmap = await createImageBitmap(file);
    const max = 1600, scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext("2d").drawImage(bitmap,0,0,canvas.width,canvas.height);
    bitmap.close?.();
    let quality=.84, blob;
    do { blob = await new Promise(resolve => canvas.toBlob(resolve,"image/jpeg",quality)); quality -= .08; }
    while (blob && blob.size > 900*1024 && quality >= .5);
    if (!blob || blob.size > 2*1024*1024) throw new Error(`${file.name}: could not compress under 2 MB`);
    const stem=file.name.replace(/\.[^.]+$/,"").replace(/[^A-Za-z0-9_-]/g,"-").slice(0,50)||"screenshot";
    return new File([blob],`${stem}.jpg`,{type:"image/jpeg"});
  }

  async function uploadFiles(token, files) {
    if (files.length < 1 || files.length > 4) throw new Error("Attach between 1 and 4 account screenshots.");
    const client = await initStorage();
    for (const source of files) {
      const file = await compressImage(source);
      const signed = await applicationApi({action:"upload_url",token,fileName:file.name,contentType:file.type,size:file.size});
      const result = await client.storage.from("guild-applications").uploadToSignedUrl(signed.path,signed.uploadToken,file,{contentType:file.type});
      if (result.error) throw result.error;
      await applicationApi({action:"register_file",token,path:signed.path,fileName:file.name,contentType:file.type,size:file.size,revision:signed.revision});
    }
  }

  document.querySelector("#application-screenshots")?.addEventListener("change", event => {
    document.querySelector("#application-files").innerHTML = [...event.target.files].map(file=>`<span class="file-chip">${esc(file.name)}</span>`).join("");
  });

  document.querySelector("#public-application-form")?.addEventListener("submit", async event => {
    event.preventDefault();
    const form=event.currentTarget, fd=new FormData(form), files=[...document.querySelector("#application-screenshots").files];
    const button=document.querySelector("#submit-application"), result=document.querySelector("#application-result");
    result.innerHTML=""; button.disabled=true; button.textContent="Submitting...";
    try{
      const created=await applicationApi({
        action:"create",
        ign:fd.get("ign"),
        email:fd.get("email"),
        jobClass:fd.get("jobClass"),
        previousGuild:fd.get("previousGuild"),
        willingAdjust:fd.get("willingAdjust")==="on",
        organizedBidding:fd.get("organizedBidding")==="on"
      });
      await uploadFiles(created.token,files);
      const finalized=await applicationApi({action:"finalize",token:created.token});
      const applicationNumber = `HV-${String(created.applicationId || "").slice(0,8).toUpperCase()}`;
      result.innerHTML=`<div class="success"><strong>Application submitted.</strong><br/>Application Number: <strong>${esc(applicationNumber)}</strong><br/>Save this number. You can also use your IGN to check your status later.</div>`;
      form.reset(); document.querySelector("#application-files").innerHTML="";
    }catch(error){
      result.innerHTML=`<div class="error">${esc(error.message)}</div>`;
    }finally{
      button.disabled=false; button.textContent="Submit application";
    }
  });

  function renderLookup(app) {
    const notes=(app.messages||[]).map(m=>`<div class="message-note"><strong>${esc(m.senderName || "HAVOC")}</strong><p style="margin:4px 0">${esc(m.message)}</p><small>${fmt(m.createdAt)}</small></div>`).join("");
    return `<div class="lookup-result">
      <p class="eyebrow">APPLICATION ${esc(app.applicationNumber)}</p>
      <h3>${esc(app.ign)}</h3>
      <div style="display:grid;gap:5px;color:#aaa;font-size:13px">
        <span>Status: <strong style="color:#f3ebdd">${esc(app.statusLabel)}</strong></span>
        <span>Class: <strong style="color:#f3ebdd">${esc(app.jobClass || "Not provided")}</strong></span>
        <span>Submitted: <strong style="color:#f3ebdd">${esc(fmt(app.submittedAt))}</strong></span>
      </div>
      ${app.officerFeedback ? `<div class="feedback"><strong>Officer feedback</strong><p style="margin:5px 0 0">${esc(app.officerFeedback)}</p></div>` : ""}
      ${notes ? `<div class="message-list">${notes}</div>` : ""}
    </div>`;
  }

  document.querySelector("#application-lookup-form")?.addEventListener("submit", async event => {
    event.preventDefault();
    const fd=new FormData(event.currentTarget), box=document.querySelector("#lookup-result");
    box.innerHTML='<div style="color:#888;margin-top:12px">Checking...</div>';
    try{
      const result=await applicationApi({action:"lookup",query:fd.get("query")});
      box.innerHTML=renderLookup(result.application);
    }catch(error){
      box.innerHTML=`<div class="error">${esc(error.message)}</div>`;
    }
  });
})();
