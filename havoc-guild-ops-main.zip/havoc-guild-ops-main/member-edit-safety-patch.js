(() => {
  const originalLoadAccounts = loadAccounts;
  const originalLoadRemoteState = loadRemoteState;
  const originalOpenMemberForm = openMemberForm;

  async function hydrateMembersFromMirror(targetPlayer = null) {
    if (!supabaseClient) return;
    const { data: members, error } = await supabaseClient
      .from("members")
      .select("id,ign,job_class,combat_role,auction_group,guild_title,is_officer,can_manage,officer_rotation_order,puppet_rotation_order,puppet_complete,puppet_completed_at")
      .eq("active", true);
    if (error) {
      console.warn("Havoc member hydration failed", error);
      return;
    }

    const byId = new Map((members || []).map(m => [m.id, m]));
    const byIgn = new Map((members || []).map(m => [String(m.ign || "").toLowerCase(), m]));
    const players = targetPlayer ? [targetPlayer] : state.players;

    for (const p of players) {
      const row = (p.dbId && byId.get(p.dbId)) || byIgn.get(String(p.name || "").toLowerCase());
      if (!row) continue;
      p.dbId = row.id;

      // The app-state object remains the primary source of truth. The normalized
      // members table only fills fields that are missing, preventing an unrelated
      // state save from mirroring blanks back over valid roster data.
      if (!p.job && row.job_class) p.job = row.job_class;
      if (!p.role && row.combat_role) p.role = row.combat_role;
      if ((p.auctionGroup === null || p.auctionGroup === undefined || p.auctionGroup === "") && row.auction_group != null) p.auctionGroup = Number(row.auction_group);
      if (!p.guildTitle && row.guild_title) p.guildTitle = row.guild_title;
      if (p.isOfficer == null && row.is_officer != null) p.isOfficer = Boolean(row.is_officer);
      if (p.canManage == null && row.can_manage != null) p.canManage = Boolean(row.can_manage);
      if (p.officerOrder == null && row.officer_rotation_order != null) p.officerOrder = Number(row.officer_rotation_order);
      if (p.puppetOrder == null && row.puppet_rotation_order != null) p.puppetOrder = Number(row.puppet_rotation_order);
      if (p.puppetComplete == null && row.puppet_complete != null) p.puppetComplete = Boolean(row.puppet_complete);
      if (!p.puppetCompletedAt && row.puppet_completed_at) p.puppetCompletedAt = row.puppet_completed_at;
    }
  }

  loadAccounts = async function patchedLoadAccounts() {
    await originalLoadAccounts();
    await hydrateMembersFromMirror();
  };

  loadRemoteState = async function patchedLoadRemoteState() {
    await originalLoadRemoteState();
    await hydrateMembersFromMirror();
  };

  openMemberForm = async function patchedOpenMemberForm(p = null) {
    if (p) await hydrateMembersFromMirror(p);
    return originalOpenMemberForm(p);
  };
})();
