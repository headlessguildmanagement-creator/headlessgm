(() => {
  window.__havocStateVersion = Number(window.__havocStateVersion || 0);
  window.__havocLastChange = window.__havocLastChange || null;

  function mergeRemoteState(remote) {
    if (!remote) return;
    rotationMigrationPending = remote.rotationScheduleVersion !== 4 || remote.puppetRosterCleanupVersion !== 2 || remote.allocationVersion !== 4;
    state = { ...state, ...remote };
    state.players = removeInactiveFromPuppetRotation(remote.players || state.players);
    state.events = alignConfirmedRotations(ensureUpcomingEvents(remote.events || state.events));
    state.loas = remote.loas || [];
    state.history = remote.history || [];
    state.featherHistory = remote.featherHistory || [];
    state.puppetCycle = remote.puppetCycle || 1;
    state.puppetCycleHistory = remote.puppetCycleHistory || [];
    state.jobChangeLog = remote.jobChangeLog || [];
    state.accountChangeLog = remote.accountChangeLog || state.jobChangeLog.map(x => ({ ...x, type: "job_change", migratedFromJobChangeLog: true }));
    state.publicActionLog = remote.publicActionLog || [];
    state.officerReadState = remote.officerReadState || {};
    state.officerRotationIndex = remote.officerRotationIndex ?? 0;
    state.rotationScheduleVersion = 4;
    state.puppetRosterCleanupVersion = 2;
    state.allocationVersion = 4;
    ensureInitialLineup(state);
  }

  loadRemoteState = async function hardenedLoadRemoteState() {
    const { data: { session } } = await supabaseClient.auth.getSession();
    const headers = session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {};
    const response = await fetch("/api/officer-state", { headers, cache: "no-store" });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || "Guild state could not be loaded");
    window.__havocStateVersion = Number(body.version || 1);
    window.__havocLastChange = body.lastChange || null;
    mergeRemoteState(body.state);
  };

  function conflictMessage(body) {
    const by = body?.lastChangedBy || "another user or system task";
    const kind = body?.lastChangeKind || "guild data update";
    const when = body?.lastChangedAt ? new Date(body.lastChangedAt).toLocaleString("en-PH", { timeZone: PH_TIMEZONE }) : "recently";
    return `SAVE BLOCKED — newer guild data exists. ${by} made a change (${kind}) ${when}. Refresh the app to load the latest data, then make your change again. Your save was rejected so the newer data was not overwritten.`;
  }

  persistState = async function hardenedPersistState() {
    if (!officerSession?.access_token) throw new Error("Officer session expired");
    const snapshot = publicStateSnapshot();
    const response = await fetch("/api/officer-state", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${officerSession.access_token}` },
      body: JSON.stringify({ state: snapshot, expectedVersion: window.__havocStateVersion })
    });
    const body = await response.json().catch(() => ({}));
    if (response.status === 409 && body.conflict) {
      const error = new Error(conflictMessage(body));
      error.code = "HAVOC_STATE_CONFLICT";
      error.conflict = body;
      throw error;
    }
    if (!response.ok) throw new Error(body.error || "Guild state save failed");
    window.__havocStateVersion = Number(body.version || window.__havocStateVersion + 1);
    window.__havocLastChange = body.lastChange || window.__havocLastChange;
    if (body.memberSyncWarning) console.warn("Havoc member mirror sync warning", body.memberSyncWarning);
    return body;
  };

  save = function hardenedSave(message) {
    if (supabaseClient && officerSession) {
      syncQueue = syncQueue.then(persistState).catch(error => {
        console.error("Havoc sync failed", error);
        toast(error.message || "Guild state save failed");
        window.__havocLastSaveError = error;
        return null;
      });
    }
    if (message) toast(message.replace("minimum allocation", "equal distribution"));
  };

  const loginForm = document.querySelector("#officer-login-form");
  if (loginForm) {
    loginForm.addEventListener("submit", async event => {
      event.preventDefault();
      event.stopImmediatePropagation();
      const errorBox = document.querySelector("#login-error");
      const submit = loginForm.querySelector("button[type='submit']");
      const form = new FormData(loginForm);
      const username = String(form.get("username") || "").trim();
      const password = String(form.get("password") || "");
      errorBox?.classList.add("hidden");
      if (submit) submit.disabled = true;
      try {
        const response = await fetch("/api/resolve-login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password })
        });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || "Invalid username or password");
        const { error } = await supabaseClient.auth.setSession({ access_token: body.accessToken, refresh_token: body.refreshToken });
        if (error) throw error;
        location.reload();
      } catch (error) {
        if (errorBox) {
          errorBox.textContent = error.message || "Officer login failed";
          errorBox.classList.remove("hidden");
        }
      } finally {
        if (submit) submit.disabled = false;
      }
    }, true);
  }
})();
