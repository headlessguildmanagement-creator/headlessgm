const HAVOC_PUPPET_DONE = {
  "3up10":"2026-08-23","annesykeep":"2026-08-23","ascendum":"2026-08-23","baaashhh":"2026-08-23",
  "bossrems":"2026-08-23","cern":"2026-08-23","cincinnati":"2026-08-23",
  "daryl":"2026-08-23","disenchanted":"2026-08-23","demonfrey":"2026-08-23","eno":"2026-08-23",
  "eren":"2026-08-25","gizmo":"2026-08-25","highfive":"2026-08-25","igee":"2026-08-25",
  "inoooh":"2026-08-27","invalidnhei":"2026-08-27","jabberwock":"2026-08-27","j a p":"2026-08-27",
  "jaxsparrow":"2026-08-27","jay":"2026-08-27"
};
const HAVOC_PUPPET_ORDER = [
  "3up10","AnneSyKeep","Ascendum","BAAASHHH","BossRems","Cern","Cincinnati","DARYL","DEMONFREY","Disenchanted","Eno","Eren","Gizmo","HighFive","iGee","Inoooh","InvalidNhei","Jabberwock","J a p","JaxSparrow","JAY","JeilynMary","JexAlmighty","jmie","JonSnow","Julio","Kemp","KonoHanaHime","Levantine","LexuS","Lumululu","Margarita","MichiKo","MiracleX","MissFlawlesS","Moune","Napster","Otenticc","OZAWA","Pazaway109","Pentagram","PRIME","PRIMO","PrimoG","ravenclaw26","RonTzy","Sakamoto","savvy","Sheeroe","Shiro","SHRUGS","Skalex","Snow","Tryme","Umaw","Untouchmyballs","winpls","xDreadZ","xJelloAce","xMangkanoR","xRyuu","xTia","Yufy","Zephyro","Zonzi","Aini","Arabella","Begi","BULALO","Byakuran","CREIOS","GVRZX","Holyfuck","Pits","Suba","Tibbers","HairyPotter","Bagi","HuaXia","WHITE"
];
const HAVOC_PUPPET_ORDER_MAP = Object.fromEntries(HAVOC_PUPPET_ORDER.map((name,index)=>[name.toLowerCase(),index+1]));
const HAVOC_PENDING_GROUPS = {"aini":2,"arabella":2,"begi":2,"hairypotter":2,"bulalo":3,"byakuran":4,"creios":4,"gvrzx":4,"holyfuck":3,"pits":3,"suba":3,"tibbers":3,"bagi":1,"huaxia":1,"white":1};

window.HAVOC_SEED_PLAYERS = [
  ["xTia","Lord Knight","DPS",4],["xRyuu","Lord Knight","DPS",4],["jmie","Lord Knight","DPS",2],
  ["AnneSyKeep","High Priest","Support",1],["PRIME","High Priest","Support",3],["Pazaway109","High Priest","Support",3],
  ["Otenticc","High Priest","Support",3],["MissFlawlesS","High Priest","Support",3],["MichiKo","High Priest","Support",2],
  ["KonoHanaHime","High Priest","Support",2],["3up10","High Priest","Support",1],["Kemp","Champion","DPS",2],
  ["Savvy","High Wizard","DPS",3],["LexuS","High Wizard","DPS",2],["Julio","High Wizard","DPS",2],
  ["J a p","High Wizard","DPS",2],["HighFive","High Wizard","DPS",1],["Untouchmyballs","Stalker","DPS",4],
  ["MiracleX","Whitesmith","DPS",3],["JaxSparrow","Biochemist","Utility",2],["Snow","Sniper","DPS",4],
  ["Tryme","Sniper","DPS",4],["JAY","Summoner","DPS",2],["iGee","Biochemist","Utility",1],
  ["Gizmo","Sniper","DPS",1],["Eren","Summoner","DPS",1],["PRIMO","Minstrel","Support",3],
  ["SHRUGS","Minstrel","Support",4],["ravenclaw26","Minstrel","Support",3],["PrimoG","Minstrel","Support",3],
  ["Inoooh","Minstrel","Support",1],["xDreadZ","Gypsy","Support",4],
  ["Pentagram","Gypsy","Support",3],["RonTzy","Summoner","DPS",3],["Umaw","Summoner","DPS",4],
  ["InvalidNhei","Summoner","DPS",1],["Cern","Summoner","DPS",1],["winpls","Summoner","DPS",4],["BossRems","Lord Knight","DPS",1],
  ["Ascendum","Lord Knight","Utility",1],["Skalex","Paladin","Utility",4],["Yufy","High Priest","Support",4],
  ["Margarita","High Priest","Support",2],["JexAlmighty","High Priest","Support",2],["Cincinnati","High Priest","Support",1],
  ["BAAASHHH","High Priest","Support",1],["Zephyro","High Wizard","DPS",4],["Zonzi","Professor","DPS",4],
  ["Jabberwock","High Wizard","DPS",2],["DEMONFREY","Assassin Cross","DPS",1],["Disenchanted","Whitesmith","DPS",1],
  ["xJelloAce","Biochemist","Utility",4],["Sakamoto","Biochemist","Utility",3],["Shiro","Summoner","DPS",4],
  ["Sheeroe","Rebellion","DPS",4],["Napster","Sniper","DPS",3],["DARYL","Sniper","DPS",1],
  ["Eno","Minstrel","Support",1],["OZAWA","Gypsy","Support",3],["Moune","Gypsy","Support",3],
  ["Lumululu","Gypsy","Support",2],["xMangkanoR","Summoner","DPS",4],["Levantine","Summoner","DPS",2],
  ["JonSnow","Rebellion","DPS",2],["JeilynMary","Summoner","DPS",2],
  ["Aini","","",null],["Arabella","","",null],["Begi","","",null],["BULALO","","",null],
  ["Byakuran","","",null],["CREIOS","","",null],["GVRZX","","",null],["Holyfuck","","",null],
  ["Pits","","",null],["Suba","","",null],["Tibbers","","",null],
  ["HairyPotter","","",null],["Bagi","","",null],["HuaXia","","",null],["WHITE","","",null]
].map((p, i) => ({
  id: `player-${i + 1}`,
  name: p[0], job: p[1], role: p[2], auctionGroup: p[3] || HAVOC_PENDING_GROUPS[p[0].toLowerCase()] || null,
  guildTitle: ({"zonzi":"Guild Master","bossrems":"Vice Guild Master","ozawa":"Officer","lexus":"Commander","shrugs":"Vice Guild Master","jabberwock":"Officer","levantine":"Officer","rontzy":"Officer"})[p[0].toLowerCase()] || "Member",
  isOfficer: ["zonzi","bossrems","ozawa","lexus","shrugs","jabberwock","levantine","rontzy"].includes(p[0].toLowerCase()),
  canManage: ["ozawa","zonzi"].includes(p[0].toLowerCase()), officerOrder: null,
  puppetComplete: Boolean(HAVOC_PUPPET_DONE[p[0].toLowerCase()]),
  puppetCompletedAt: HAVOC_PUPPET_DONE[p[0].toLowerCase()] || null,
  puppetOrder: HAVOC_PUPPET_ORDER_MAP[p[0].toLowerCase()] || null,
  active: true
}));

window.HAVOC_JOB_ICONS = {
  "Sniper":"assets/job-icons/sniper.webp",
  "High Priest":"assets/job-icons/high-priest.webp",
  "Lord Knight":"assets/job-icons/lord-knight.webp",
  "High Wizard":"assets/job-icons/high-wizard.webp",
  "Assassin Cross":"assets/job-icons/assassin-cross.webp",
  "Champion":"assets/job-icons/champion.webp",
  "Whitesmith":"assets/job-icons/whitesmith.webp",
  "Gypsy":"assets/job-icons/gypsy.webp",
  "Professor":"assets/job-icons/professor.webp",
  "Paladin":"assets/job-icons/paladin.webp",
  "Biochemist":"assets/job-icons/biochemist.webp",
  "Minstrel":"assets/job-icons/minstrel.webp",
  "Stalker":"assets/job-icons/stalker.webp",
  "Summoner":"assets/job-icons/summoner.webp",
  "Rebellion":"assets/job-icons/rebellion.webp"
};
