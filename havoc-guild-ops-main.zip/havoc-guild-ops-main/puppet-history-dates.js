(() => {
  function shortHistoryDate(value) {
    if (!value) return '—';
    const raw = String(value);
    const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(raw) ? `${raw}T12:00:00+08:00` : raw;
    const date = new Date(dateOnly);
    if (Number.isNaN(date.getTime())) return raw;
    return new Intl.DateTimeFormat('en-PH', {
      timeZone: 'Asia/Manila',
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  }

  function memberHistoryStatus(member) {
    if (member?.completedAt) {
      return `<span class="pill green">COMPLETED</span> <strong>${shortHistoryDate(member.completedAt)}</strong>`;
    }
    if (member?.deferred96h) {
      return '<span class="pill red">96H PENALTY</span> <span class="muted">No Cycle turn carried forward</span>';
    }
    if (member?.deferredTurn) {
      const reason = member.deferredReason ? ` · ${esc(member.deferredReason)}` : '';
      return `<span class="pill purple">DEFERRED</span> <span class="muted">Make-up owed${reason}</span>`;
    }
    return '<span class="pill amber">NOT COMPLETED</span>';
  }

  function cycleHistoryCard() {
    const history = [...(state.puppetCycleHistory || [])]
      .sort((a, b) => Number(b.cycle || 0) - Number(a.cycle || 0));

    if (!history.length) {
      return `<div class="card"><div class="section-head"><div><h2>Puppet Cycle History</h2><p>Completed cycles will appear here with each member's actual bidding/completion date for appeal verification.</p></div><span class="pill purple">GUILD HISTORY</span></div><div class="empty-state">No completed Puppet cycles recorded yet.</div></div>`;
    }

    const cycles = history.map((cycle, index) => {
      const members = [...(cycle.members || [])].sort((a, b) => Number(a.order || 0) - Number(b.order || 0) || String(a.name || '').localeCompare(String(b.name || '')));
      const rows = members.map(member => `<tr><td>${member.order ?? '—'}</td><td><strong>${esc(member.name || player(member.playerId)?.name || 'Unknown')}</strong></td><td>${memberHistoryStatus(member)}</td></tr>`).join('');
      const cycleClosed = shortHistoryDate(cycle.completedAt);
      const appealUntil = shortHistoryDate(cycle.appealOpenUntil);
      return `<details class="card"><summary><strong>Cycle ${Number(cycle.cycle || 0)}</strong> · Completed ${cycleClosed} · Appeal until ${appealUntil}</summary><div class="table-wrap"><table><thead><tr><th>Position</th><th>Player</th><th>Cycle result / bidding date</th></tr></thead><tbody>${rows}</tbody></table></div></details>`;
    }).join('');

    return `<div class="card"><div class="section-head"><div><h2>Puppet Cycle History</h2><p>Use the recorded member completion date to verify when a player actually completed their Puppet bidding turn before approving an appeal.</p></div><span class="pill purple">GUILD HISTORY</span></div></div>${cycles}`;
  }

  // Feather 96H is already enforced by member-eligibility.js. Keep a final
  // defensive wrapper so every caller of eligibleFeatherPlayers receives only
  // members eligible for this event, including future/manual auction paths.
  if (typeof eligibleFeatherPlayers === 'function') {
    const previousEligibleFeatherPlayers = eligibleFeatherPlayers;
    eligibleFeatherPlayers = function hardened96hFeatherEligibility(event) {
      const rows = previousEligibleFeatherPlayers(event) || [];
      if (typeof window.havocIsMemberEligibleForEvent !== 'function') return rows;
      return rows.filter(member => window.havocIsMemberEligibleForEvent(member, event));
    };
  }

  window.__havocPuppetCycleHistoryCard = cycleHistoryCard;
})();
