(() => {
  const originalIsPuppetUnavailable = isPuppetUnavailable;
  const PUPPET_TENTATIVE_LIMIT = 20;

  isPuppetUnavailable = function (event, playerId) {
    return originalIsPuppetUnavailable(event, playerId) || (event?.puppetCannotBidIds || []).includes(playerId);
  };

  pendingPuppetPlayers = function (event) {
    return state.players
      .filter(player => player.active && Number.isInteger(player.puppetOrder) && !player.puppetComplete && !isPuppetUnavailable(event, player.id))
      .sort((a, b) => a.puppetOrder - b.puppetOrder);
  };

  function projectedNextCycleIds(event, list) {
    if (!event) return new Set();
    const available = list.filter(member => !isPuppetUnavailable(event, member.id));
    const incompleteAll = list.filter(member => !member.puppetComplete);
    const incompleteAvailable = available.filter(member => !member.puppetComplete);
    const selected = [];
    const selectedIds = new Set();
    const take = member => {
      if (!member || selectedIds.has(member.id) || selected.length >= PUPPET_TENTATIVE_LIMIT) return;
      selectedIds.add(member.id);
      selected.push(member);
    };

    incompleteAvailable.forEach(take);
    const cycleCanFinish = incompleteAll.every(member => selectedIds.has(member.id));
    if (cycleCanFinish && selected.length < PUPPET_TENTATIVE_LIMIT) {
      available.filter(member => member.puppetComplete).forEach(take);
    }
    return new Set(selected.filter(member => member.puppetComplete).map(member => member.id));
  }

  function assignedNextCycleIds(event) {
    return new Set((event?.auction?.assignments || [])
      .filter(item => item.category === "Puppet Fragment" && Number(item.puppetCycleOffset || 0) > 0)
      .map(item => item.playerId));
  }

  renderPuppetQueue = function () {
    const event = eventById(selectedEventId) || state.events[0];
    const skipped = new Set(event?.puppetCannotBidIds || []);
    const list = state.players
      .filter(player => player.active && Number.isInteger(player.puppetOrder))
      .sort((a, b) => a.puppetOrder - b.puppetOrder);
    const projected = projectedNextCycleIds(event, list);
    const assignedNextCycle = assignedNextCycleIds(event);
    const controlsEnabled = currentView === "puppet" && accessMode === "commander";

    return `<div class="card"><div class="section-head"><div><h2>Puppet A–Z rotation</h2><p>Use Cannot Bid when a member cannot bid for the selected event. NEXT IN LINE is a tentative projection only. NEXT CYCLE BIDDER means Auction Builder actually selected that member after a cycle rollover.</p></div><span class="pill amber">${list.length} ACTIVE MEMBERS</span></div><div class="table-wrap"><table><thead><tr><th>Current position</th><th>Player</th><th>Status</th><th>Completion / selection</th><th>Actions</th></tr></thead><tbody>${list.map((playerRow, index) => {
      const cannotBid = !playerRow.puppetComplete && skipped.has(playerRow.id);
      const nextCycleBidder = assignedNextCycle.has(playerRow.id);
      const nextInLine = !nextCycleBidder && projected.has(playerRow.id);
      const status = nextCycleBidder
        ? '<span class="pill green">NEXT CYCLE BIDDER</span>'
        : nextInLine
          ? '<span class="pill amber">NEXT IN LINE</span>'
          : playerRow.puppetComplete
            ? '<span class="pill green">DONE</span>'
            : cannotBid
              ? '<span class="pill red">CANNOT BID</span>'
              : '<span class="pill amber">PENDING</span>';
      const dateText = nextCycleBidder
        ? `Selected · ${formatDate(event.date)}`
        : nextInLine
          ? `Projected · ${formatDate(event.date)}`
          : playerRow.puppetCompletedAt
            ? formatDate(playerRow.puppetCompletedAt)
            : "—";
      let actions = "—";
      if (controlsEnabled) {
        if (playerRow.puppetComplete) {
          actions = `<button class="button ghost small puppet-set-pending" data-player="${playerRow.id}">Set Pending</button>`;
        } else if (cannotBid) {
          actions = `<button class="button ghost small puppet-restore-bid" data-player="${playerRow.id}">Can Bid Again</button>`;
        } else {
          actions = `<div class="card-actions"><button class="button small puppet-complete" data-player="${playerRow.id}">Complete Puppet</button><button class="button ghost small puppet-cannot-bid" data-player="${playerRow.id}">Cannot Bid</button></div>`;
        }
      }
      return `<tr><td>${index + 1}</td><td><strong>${esc(playerRow.name)}</strong></td><td>${status}</td><td>${dateText}</td><td>${actions}</td></tr>`;
    }).join("")}</tbody></table></div></div>`;
  };

  bindPuppetRotation = function () {
    const event = eventById(selectedEventId) || state.events[0];
    if (!event) return;
    event.puppetCannotBidIds ??= [];

    document.querySelectorAll(".puppet-complete").forEach(button => button.addEventListener("click", () => {
      const member = player(button.dataset.player);
      if (!member || !confirm(`Mark ${member.name} as DONE for the Puppet rotation?`)) return;
      member.puppetComplete = true;
      member.puppetCompletedAt = localISO(new Date());
      event.puppetCannotBidIds = event.puppetCannotBidIds.filter(id => id !== member.id);
      event.auction = null;
      save(`${member.name} Puppet turn completed`);
      render();
    }));

    document.querySelectorAll(".puppet-cannot-bid").forEach(button => button.addEventListener("click", () => {
      const member = player(button.dataset.player);
      if (!member || !confirm(`Mark ${member.name} as CANNOT BID for ${event.name}? They will be skipped for this event only and return to Pending after midnight auto-complete.`)) return;
      event.puppetCannotBidIds = [...new Set([...event.puppetCannotBidIds, member.id])];
      event.auction = null;
      delete event.auctionDraft;
      save(`${member.name} marked Cannot Bid for ${event.name}`);
      render();
    }));

    document.querySelectorAll(".puppet-restore-bid").forEach(button => button.addEventListener("click", () => {
      const member = player(button.dataset.player);
      if (!member) return;
      event.puppetCannotBidIds = event.puppetCannotBidIds.filter(id => id !== member.id);
      event.auction = null;
      delete event.auctionDraft;
      save(`${member.name} returned to Pending for ${event.name}`);
      render();
    }));

    document.querySelectorAll(".puppet-set-pending").forEach(button => button.addEventListener("click", () => {
      const member = player(button.dataset.player);
      if (!member || !confirm(`Mark ${member.name} as PENDING again?`)) return;
      member.puppetComplete = false;
      member.puppetCompletedAt = null;
      event.auction = null;
      save(`${member.name} returned to Pending`);
      render();
    }));
  };
})();
