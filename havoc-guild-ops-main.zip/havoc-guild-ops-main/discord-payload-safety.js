(() => {
  const originalFetch = window.fetch.bind(window);
  const MAX_SAFE_JSON_BYTES = 3_200_000;
  const MIN_SCALE = 0.45;

  function isDiscordPublish(input, init) {
    const url = typeof input === "string" ? input : input?.url || "";
    return url.includes("/api/discord-publish") && String(init?.method || "GET").toUpperCase() === "POST";
  }

  function bodySize(payload) {
    return new TextEncoder().encode(JSON.stringify(payload)).length;
  }

  function loadImage(dataUrl) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("Generated Discord preview could not be compressed"));
      image.src = dataUrl;
    });
  }

  async function resizePng(dataUrl, scale) {
    const image = await loadImage(dataUrl);
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const ctx = canvas.getContext("2d");
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/png");
  }

  async function compressDiscordPayload(payload) {
    if (!Array.isArray(payload.images) || !payload.images.length) return payload;
    if (bodySize(payload) <= MAX_SAFE_JSON_BYTES) return payload;

    const originalImages = payload.images;
    let scale = 0.82;
    let compressed = payload;

    while (scale >= MIN_SCALE) {
      const images = await Promise.all(originalImages.map(async image => ({
        ...image,
        data: await resizePng(image.data, scale)
      })));
      compressed = { ...payload, images };
      if (bodySize(compressed) <= MAX_SAFE_JSON_BYTES) return compressed;
      scale -= 0.1;
    }

    return compressed;
  }

  window.fetch = async function (input, init = {}) {
    if (!isDiscordPublish(input, init) || typeof init.body !== "string") {
      return originalFetch(input, init);
    }

    let payload;
    try {
      payload = JSON.parse(init.body);
    } catch (_) {
      return originalFetch(input, init);
    }

    if (!Array.isArray(payload.images) || payload.images.length <= 1 || bodySize(payload) <= MAX_SAFE_JSON_BYTES) {
      return originalFetch(input, init);
    }

    try {
      const compressed = await compressDiscordPayload(payload);
      if (bodySize(compressed) > MAX_SAFE_JSON_BYTES) {
        return new Response(JSON.stringify({ error: "Generated Discord images are still too large after compression. Please try publishing again." }), {
          status: 413,
          headers: { "Content-Type": "application/json" }
        });
      }
      return originalFetch(input, {
        ...init,
        body: JSON.stringify(compressed)
      });
    } catch (error) {
      return new Response(JSON.stringify({ error: error?.message || "Discord image compression failed" }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
  };
})();
