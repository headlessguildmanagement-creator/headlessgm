(() => {
  function assignmentCycle(playerId, event, assignment) {
    const completedThrough = [...(state.puppetCycleHistory || [])]
      .reverse()
      .find(row => row.completedThroughEvent === event.id);
    if (completedThrough) return Number(completedThrough.cycle) + (Number(assignment.puppetCycleOffset || 0) > 0 ? 1 : 0);
    const historyMatch = [...(state.puppetCycleHistory || [])]
      .reverse()
      .find(row => (row.members || []).some(member => member.playerId === playerId && member.completedAt === event.date));
    if (historyMatch) return Number(historyMatch.cycle);
    return Number(state.puppetCycle || 1);
  }

  function endedPuppetAssignmentsFor(playerId) {
    const now = new Date();
    const currentCycle = Number(state.puppetCycle || 1);
    return (state.events || [])
      .filter(event => new Date(`${event.date}T${event.callTime || '20:30'}:00+08:00`) < now)
      .map(event => {
        const assignment = (event.auction?.assignments || []).find(item => item.category === 'Puppet Fragment' && item.playerId === playerId);
        if (!assignment) return null;
        return assignmentCycle(playerId, event, assignment) === currentCycle ? { event, assignment } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b.event.date.localeCompare(a.event.date));
  }

  function appealForm() {
    const members = (state.players || []).filter(p => p.active && Number.isInteger(p.puppetOrder)).sort((a,b)=>a.name.localeCompare(b.name));
    return `<div class="card puppet-appeal-card">
      <div class="section-head"><div><h2>Puppet Appeal</h2><p>If you were the assigned bidder but did not receive your Puppet Fragment, you may submit proof for officer review.</p></div><span class="pill purple">1 APPEAL PER CYCLE</span></div>
      <div class="notice warning"><strong>Important:</strong> Appeals only exist inside the current Puppet cycle. Once the cycle ends, old appeals are no longer accepted. If approved, your one make-up turn is placed after the remaining normal A-Z turns and before the next cycle begins.</div>
      <form id="puppet-appeal-form" class="form-grid">
        <div class="field full"><label>YOUR IGN</label><select name="playerId" id="puppet-appeal-player" required><option value="">Select your IGN</option>${members.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
        <div class="field full"><label>MISSED / STOLEN PUPPET TURN</label><select name="eventId" id="puppet-appeal-event" required disabled><option value="">Select your IGN first</option></select><small>The Page and Item # are taken from the recorded auction assignment. The app cannot determine who actually bought the item.</small></div>
        <div class="field full"><label>WHAT HAPPENED?</label><textarea name="reason" rows="4" minlength="5" maxlength="800" required placeholder="Explain why you did not receive the Puppet Fragment assigned to your Page and Item #."></textarea></div>
        <div class="field full"><label>SCREENSHOT PROOF</label><input class="input" name="screenshot" type="file" accept="image/jpeg,image/png,image/webp" required/><small>JPG, PNG, or WebP. Screenshot proof is reviewed by officers, it is not automatic proof of who won the item.</small></div>
        <label class="puppet-declaration full"><input type="checkbox" name="declaration" required/> <span>I confirm that I did <strong>not</strong> sell, give, transfer, or allow another member to use this Puppet turn. I understand that a false appeal may be revoked and handled by the officers.</span></label>
        <div class="full"><button class="button">Submit Puppet Appeal</button></div>
      </form>
    </div>`;
  }

  function officerAppealsPanel() {
    return `<div class="card" id="puppet-appeals-panel"><div class="section-head"><div><h2>Puppet Appeals</h2><p>Review evidence manually. The system only knows the official assigned bidder, Page, and Item #.</p></div><span class="pill amber">OFFICER REVIEW</span></div><div class="empty-state">Loading appeals…</div></div>`;
  }

  window.renderPuppetAppealsPage = function renderPuppetAppealsPage() {
    if (accessMode === 'commander') {
      queueMicrotask(() => loadOfficerAppeals());
      return `<div class="card"><div class="section-head"><div><p class="eyebrow">PUPPET APPEALS</p><h2>Appeal Review</h2><p>Review member evidence, approve or reject make-up turns, and keep Puppet Rotation focused on the active queue.</p></div><span class="pill amber">OFFICER REVIEW</span></div></div>${officerAppealsPanel()}`;
    }
    return `<div class="card"><div class="section-head"><div><p class="eyebrow">PUPPET APPEALS</p><h2>Submit an Appeal</h2><p>Submit proof here without mixing appeals into the active Puppet Rotation.</p></div><span class="pill purple">MEMBER</span></div></div>${appealForm()}`;
  };

  window.__havocRenderPuppetAppealForm = appealForm;
  window.__havocLoadOfficerAppeals = loadOfficerAppeals;

  renderPuppetRotation = function memberVisiblePuppetRotation() {
    const event = eventById(selectedEventId) || state.events[0];
    const intro = accessMode === 'commander'
      ? 'Manage the permanent guild-wide Puppet rotation and review member appeals.'
      : 'Read-only Puppet Rotation. Members can view status and completion dates, but only officers can change them.';
    const body = `${auctionPageHeader(event, intro)}${renderPuppetQueue()}`;
    return body;
  };

  function populateAppealEvents(playerId) {
    const select = document.querySelector('#puppet-appeal-event');
    if (!select) return;
    const rows = endedPuppetAssignmentsFor(playerId);
    if (!rows.length) {
      select.innerHTML = '<option value="">No appealable Puppet turn in the current cycle</option>';
      select.disabled = true;
      return;
    }
    select.disabled = false;
    select.innerHTML = `<option value="">Select the turn you did not receive</option>${rows.map(({event,assignment})=>`<option value="${event.id}">${formatDate(event.date)} · ${esc(event.name)} · Page ${assignment.page} Item ${assignment.item}</option>`).join('')}`;
  }

  async function imageToDataUrl(file) {
    if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error('Upload a JPG, PNG, or WebP screenshot');
    if (file.size <= 1_300_000) return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)});
    const bitmap = await createImageBitmap(file);
    const max = 1600;
    const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close?.();
    return canvas.toDataURL('image/jpeg', 0.82);
  }

  async function submitAppeal(form) {
    const button = form.querySelector('button[type="submit"],button:not([type])');
    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Submitting…';
    try {
      const data = new FormData(form);
      const screenshotDataUrl = await imageToDataUrl(data.get('screenshot'));
      const response = await fetch('/api/state-store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'puppet_appeal_submit',
          playerId: data.get('playerId'),
          eventId: data.get('eventId'),
          reason: data.get('reason'),
          declaration: data.get('declaration') === 'on',
          screenshotDataUrl
        })
      });
      const result = await response.json().catch(()=>({}));
      if (!response.ok) throw new Error(result.error || 'Puppet Appeal failed');
      form.reset();
      populateAppealEvents('');
      toast(result.message || 'Puppet Appeal submitted');
    } catch (error) {
      console.error(error);
      toast(error.message || 'Puppet Appeal failed');
    } finally {
      button.disabled = false;
      button.textContent = old;
    }
  }

  function statusPill(row) {
    if (row.cycleClosed) return '<span class="pill red">CYCLE CLOSED</span>';
    if (row.status === 'approved') return '<span class="pill green">APPROVED</span>';
    if (row.status === 'rejected') return '<span class="pill red">REJECTED</span>';
    return '<span class="pill amber">PENDING</span>';
  }

  async function loadOfficerAppeals() {
    const panel = document.querySelector('#puppet-appeals-panel');
    if (!panel || !officerSession?.access_token) return;
    try {
      const response = await fetch('/api/state-store', { headers: { Authorization: `Bearer ${officerSession.access_token}` } });
      const result = await response.json().catch(()=>({}));
      if (!response.ok) throw new Error(result.error || 'Could not load Puppet Appeals');
      const rows = result.appeals || [];
      const pending = rows.filter(row => row.status === 'pending' && !row.cycleClosed);
      panel.innerHTML = `<div class="section-head"><div><h2>Puppet Appeals</h2><p>${pending.length} pending in Cycle ${result.currentCycle || state.puppetCycle || 1}. Officers may clear an appeal to reset that member's one-appeal allowance for case-to-case situations.</p></div><span class="pill amber">OFFICER REVIEW</span></div>${rows.length ? rows.map(row => `<div class="puppet-appeal-row">
        <div class="puppet-appeal-main"><div>${statusPill(row)} <strong>${esc(row.player_name)}</strong> <span class="muted">Cycle ${row.cycle}</span></div><p>${formatDate(row.event_date)} · Page ${row.assignment_page || '—'} Item ${row.assignment_item || '—'}</p><p>${esc(row.reason)}</p><small>Submitted ${new Date(row.submitted_at).toLocaleString('en-PH',{timeZone:'Asia/Manila',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})} PHT${row.reviewed_by ? ` · Reviewed by ${esc(row.reviewed_by)}` : ''}</small></div>
        <div class="puppet-appeal-actions">${row.screenshotUrl ? `<a class="button ghost small" href="${esc(row.screenshotUrl)}" target="_blank" rel="noopener">View screenshot</a>` : ''}${row.status === 'pending' && !row.cycleClosed ? `<button class="button small puppet-appeal-review" data-id="${row.id}" data-decision="approved">Approve Make-up</button><button class="button ghost small puppet-appeal-review" data-id="${row.id}" data-decision="rejected">Reject</button>` : ''}<button class="button ghost small puppet-appeal-clear" data-id="${row.id}" data-name="${esc(row.player_name)}" data-cycle="${row.cycle}">Clear Appeal</button></div>
      </div>`).join('') : '<div class="empty-state">No Puppet Appeals yet.</div>'}`;
    } catch (error) {
      panel.innerHTML = `<div class="empty-state">${esc(error.message || 'Could not load Puppet Appeals')}</div>`;
    }
  }

  async function reviewAppeal(button) {
    const decision = button.dataset.decision;
    const verb = decision === 'approved' ? 'approve this make-up turn' : 'reject';
    const note = prompt(`Officer note for this appeal (optional):`) ?? '';
    if (!confirm(`Confirm ${verb}?`)) return;
    button.disabled = true;
    try {
      const response = await fetch('/api/state-store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${officerSession.access_token}` },
        body: JSON.stringify({ action: 'puppet_appeal_review', appealId: button.dataset.id, decision, reviewNote: note })
      });
      const result = await response.json().catch(()=>({}));
      if (!response.ok) throw new Error(result.error || 'Appeal review failed');
      toast(result.message || 'Appeal updated');
      if (decision === 'approved') await loadRemoteState();
      render();
    } catch (error) {
      toast(error.message || 'Appeal review failed');
      button.disabled = false;
    }
  }

  async function clearAppeal(button) {
    const name = button.dataset.name || 'this member';
    const cycle = button.dataset.cycle || '?';
    if (!confirm(`Clear ${name}'s Cycle ${cycle} appeal? This resets their appeal allowance for that cycle and removes any related make-up.`)) return;
    button.disabled = true;
    try {
      const response = await fetch('/api/state-store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${officerSession.access_token}` },
        body: JSON.stringify({ action: 'puppet_appeal_clear', appealId: button.dataset.id })
      });
      const result = await response.json().catch(()=>({}));
      if (!response.ok) throw new Error(result.error || 'Could not clear appeal');
      toast(result.message || 'Appeal cleared');
      await loadRemoteState();
      render();
    } catch (error) {
      toast(error.message || 'Could not clear appeal');
      button.disabled = false;
    }
  }

  document.addEventListener('change', event => {
    if (event.target?.id === 'puppet-appeal-player') populateAppealEvents(event.target.value);
  });

  document.addEventListener('submit', event => {
    if (event.target?.id !== 'puppet-appeal-form') return;
    event.preventDefault();
    submitAppeal(event.target);
  });

  document.addEventListener('click', event => {
    const reviewButton = event.target.closest?.('.puppet-appeal-review');
    if (reviewButton) {
      event.preventDefault();
      reviewAppeal(reviewButton);
      return;
    }
    const clearButton = event.target.closest?.('.puppet-appeal-clear');
    if (clearButton) {
      event.preventDefault();
      clearAppeal(clearButton);
    }
  });

  window.__havocEndedPuppetAssignmentsFor = endedPuppetAssignmentsFor;
})();
