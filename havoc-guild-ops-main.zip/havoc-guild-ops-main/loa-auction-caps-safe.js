(function () {
  "use strict";

  const originalCutoff = cutoff;
  const originalRenderLoa = renderLoa;
  const originalFeatherTotals = featherTotals;
  const originalComputeFeatherDistribution = computeFeatherDistribution;
  const originalRenderCommanderAuctionV2 = renderCommanderAuctionV2;
  const originalConfirmAuctionInputs = confirmAuctionInputs;

  cutoff = function havocLoaCutoff(event) {
    return new Date(`${event.date}T19:30:00+08:00`);
  };

  renderLoa = function havocRenderLoa() {
    return originalRenderLoa().replace(
      "Everyone attends by default. LOA closes six hours before call time.",
      "Everyone attends by default. LOA filing closes at 7:30 PM PHT on the event day."
    );
  };

  featherTotals = function havocFeatherTotals(settings) {
    const totals = originalFeatherTotals(settings);
    let maxLdPerBidder = Number(settings?.maxLdPerBidder) || 0;
    let maxTsPerBidder = Number(settings?.maxTsPerBidder) || 0;

    // Step 2's legacy eligibility renderer calls featherTotals() with only
    // the page/item fields. Read the two cap inputs from the current Auction
    // Builder form so the eligibility table uses the same caps as Step 1.
    if ((!maxLdPerBidder || !maxTsPerBidder) && typeof document !== "undefined") {
      const form = document.querySelector?.("#auction-form-v2");
      if (form) {
        const ldInput = form.querySelector?.('[name="maxLdPerBidder"]');
        const tsInput = form.querySelector?.('[name="maxTsPerBidder"]');
        if (!maxLdPerBidder) maxLdPerBidder = Number(ldInput?.value) || 0;
        if (!maxTsPerBidder) maxTsPerBidder = Number(tsInput?.value) || 0;
      }
    }

    return {
      ...totals,
      maxLdPerBidder,
      maxTsPerBidder
    };
  };

  computeFeatherDistribution = function havocCappedFeatherDistribution(event, totals, startIndex = 0) {
    const dist = originalComputeFeatherDistribution(event, totals, startIndex);
    const maxLd = Number(totals?.maxLdPerBidder) || 0;
    const maxTs = Number(totals?.maxTsPerBidder) || 0;
    if (maxLd <= 0 || maxTs <= 0 || !dist.valid) return dist;

    let overflowLd = 0;
    let overflowTs = 0;

    // Caps are absolute for every recipient, including officers who already
    // received excess from the legacy distribution.
    for (const quota of Object.values(dist.quotas)) {
      if (!quota) continue;

      if (quota.ld > maxLd) {
        overflowLd += quota.ld - maxLd;
        quota.ld = maxLd;
      }
      if (quota.ts > maxTs) {
        overflowTs += quota.ts - maxTs;
        quota.ts = maxTs;
      }

      quota.extras ??= [];
      let allowedLdExtras = Math.min(
        quota.extras.filter(category => category === "Light/Dark").length,
        quota.ld
      );
      let allowedTsExtras = Math.min(
        quota.extras.filter(category => category === "Time/Space").length,
        quota.ts
      );
      quota.extras = quota.extras.filter(category => {
        if (category === "Light/Dark") {
          if (allowedLdExtras <= 0) return false;
          allowedLdExtras--;
          return true;
        }
        if (category === "Time/Space") {
          if (allowedTsExtras <= 0) return false;
          allowedTsExtras--;
          return true;
        }
        return true;
      });
    }

    let pointer = dist.startIndex ?? startIndex;
    let assignedOfficerLd = 0;
    let assignedOfficerTs = 0;

    function addOfficerOverflow(key) {
      const cap = key === "ld" ? maxLd : maxTs;
      let scanIndex = pointer;
      const seen = new Set();

      for (let attempts = 0; attempts < OFFICER_ROTATION.length; attempts++) {
        const next = officerAtRotation(scanIndex, event);
        if (!next?.player) return false;

        if (seen.has(next.player.id)) return false;
        seen.add(next.player.id);

        const quota = dist.quotas[next.player.id] ??= {
          ld: 0,
          ts: 0,
          regular: false,
          extras: []
        };

        if ((quota[key] || 0) < cap) {
          const category = key === "ld" ? "Light/Dark" : "Time/Space";
          quota[key] = (quota[key] || 0) + 1;
          quota.extras ??= [];
          quota.extras.push(category);
          pointer = (next.index + 1) % OFFICER_ROTATION.length;
          return true;
        }

        scanIndex = (next.index + 1) % OFFICER_ROTATION.length;
      }

      return false;
    }

    while (overflowLd > 0) {
      if (!addOfficerOverflow("ld")) break;
      overflowLd--;
      assignedOfficerLd++;
    }

    while (overflowTs > 0) {
      if (!addOfficerOverflow("ts")) break;
      overflowTs--;
      assignedOfficerTs++;
    }

    const regularIds = new Set(dist.regular.map(member => member.id));
    const officerOnly = Object.keys(dist.quotas)
      .map(player)
      .filter(Boolean)
      .filter(member => !regularIds.has(member.id));

    const allocations = [];
    let featherIndex = 0;
    for (const key of ["ld", "ts"]) {
      const category = key === "ld" ? "Light/Dark" : "Time/Space";
      for (const member of dist.regular) {
        for (let i = 0; i < (dist.quotas[member.id]?.[key] || 0); i++) {
          allocations.push({ playerId: member.id, category, index: featherIndex++ });
        }
      }
      for (const member of officerOnly) {
        for (let i = 0; i < (dist.quotas[member.id]?.[key] || 0); i++) {
          allocations.push({ playerId: member.id, category, index: featherIndex++ });
        }
      }
    }

    const regularTotals = dist.regular.map(member => {
      const quota = dist.quotas[member.id] || { ld: 0, ts: 0, extras: [] };
      const extraCount = (quota.extras || []).length;
      return Math.max(0, quota.ld + quota.ts - extraCount);
    });
    const minRegular = regularTotals.length ? Math.min(...regularTotals) : 0;
    const maxRegular = regularTotals.length ? Math.max(...regularTotals) : 0;

    dist.allocations = allocations;
    dist.nextIndex = pointer;
    dist.nextOfficer = officerAtRotation(pointer, event)?.player?.name || "None";
    dist.excess.ld = assignedOfficerLd;
    dist.excess.ts = assignedOfficerTs;
    dist.excessTotal = assignedOfficerLd + assignedOfficerTs;
    dist.unassignedExcess = { ld: overflowLd, ts: overflowTs };
    dist.unassignedExcessTotal = overflowLd + overflowTs;
    dist.valid = dist.valid && dist.unassignedExcessTotal === 0;
    dist.equalTotal = minRegular === maxRegular ? minRegular : `${minRegular}–${maxRegular}`;
    dist.maxLdPerBidder = maxLd;
    dist.maxTsPerBidder = maxTs;
    return dist;
  };
  renderCommanderAuctionV2 = function havocRenderCommanderAuctionV2(event, auction) {
    let html = originalRenderCommanderAuctionV2(event, auction);
    const settings = event.auctionDraft || auction?.settings || {};
    const limits = `
      <div class="auction-material-grid havoc-feather-caps">
        <div class="field">
          <label>MAX L/D PER REGULAR BIDDER</label>
          <input class="input" type="number" name="maxLdPerBidder" min="1" step="1" value="${settings.maxLdPerBidder || ""}" placeholder="e.g. 8" required/>
          <small>Any L/D above this limit is assigned through officer excess rotation.</small>
        </div>
        <div class="field">
          <label>MAX T/S PER REGULAR BIDDER</label>
          <input class="input" type="number" name="maxTsPerBidder" min="1" step="1" value="${settings.maxTsPerBidder || ""}" placeholder="e.g. 8" required/>
          <small>Any T/S above this limit is assigned through officer excess rotation.</small>
        </div>
      </div>`;

    const toolbarMarker = '<div class="toolbar" style="margin:14px 0"><button class="button ghost" type="button" id="recalculate-auction">';
    if (html.includes(toolbarMarker)) html = html.replace(toolbarMarker, limits + toolbarMarker);

    html = html.replace(
      "<li>Click <strong>Recalculate totals and distribution</strong>, then confirm the values.</li>",
      "<li>Set the maximum L/D and T/S each regular bidder may receive.</li><li>Click <strong>Recalculate totals and distribution</strong>, then confirm the values.</li>"
    );

    html = html.replace(
      "<strong>Fairness rule:</strong> L/D and T/S are divided by active bidders first. Their remainders are pooled only to complete a full +1 round for every active bidder. Only what still cannot complete a full round goes to the officer rotation.",
      "<strong>Fairness rule:</strong> L/D and T/S are divided by active bidders first. Regular bidders cannot exceed the Auction Master's category caps. Anything above those caps, plus any true remainder, goes through the existing officer rotation."
    );

    const currentSettings = event.auctionDraft || auction?.settings || {};
    const currentTotals = featherTotals(currentSettings);
    if (currentSettings.maxLdPerBidder && currentSettings.maxTsPerBidder && currentTotals.valid) {
      const currentDist = computeFeatherDistribution(
        event,
        currentTotals,
        currentSettings.officerRotationStart ?? state.officerRotationIndex
      );
      if (currentDist.unassignedExcessTotal > 0) {
        html = html.replace(
          '</form></div>',
          `<div class="notice warning"><strong>Unassigned excess:</strong> ${currentDist.unassignedExcess.ld} L/D · ${currentDist.unassignedExcess.ts} T/S. Every eligible officer is already at the configured cap. Increase the cap or adjust eligibility before generating assignments.</div></form></div>`
        );
      }
    }

    return html;
  };

  confirmAuctionInputs = function havocConfirmAuctionInputs(settings, onConfirm) {
    const form = document.querySelector("#auction-form-v2");
    if (form) {
      const data = new FormData(form);
      settings.maxLdPerBidder = +data.get("maxLdPerBidder");
      settings.maxTsPerBidder = +data.get("maxTsPerBidder");
    }
    return originalConfirmAuctionInputs(settings, onConfirm);
  };

  document.addEventListener("click", event => {
    const recalc = event.target.closest("#recalculate-auction");
    if (recalc) {
      const form = recalc.closest("form");
      if (!form) return;
      const data = new FormData(form);
      const maxLd = +data.get("maxLdPerBidder");
      const maxTs = +data.get("maxTsPerBidder");
      if (!Number.isInteger(maxLd) || maxLd <= 0) {
        event.preventDefault();
        event.stopImmediatePropagation();
        toast("Enter the maximum L/D boxes allowed per regular bidder");
        return;
      }
      if (!Number.isInteger(maxTs) || maxTs <= 0) {
        event.preventDefault();
        event.stopImmediatePropagation();
        toast("Enter the maximum T/S boxes allowed per regular bidder");
      }
      return;
    }

    const toggle = event.target.closest(".feather-eligibility-toggle");
    if (!toggle) return;
    const form = toggle.closest("#auction-form-v2");
    if (!form) return;

    event.preventDefault();
    event.stopImmediatePropagation();

    const currentEvent = eventById(selectedEventId);
    const panel = toggle.closest(".feather-eligibility");
    const data = new FormData(form);
    const current = new Set(currentEvent.ineligibleFeatherIds || []);
    const reasonMap = currentEvent.featherIneligibleReasons ??= {};

    if (current.has(toggle.dataset.player)) {
      current.delete(toggle.dataset.player);
      delete reasonMap[toggle.dataset.player];
    } else {
      current.add(toggle.dataset.player);
      reasonMap[toggle.dataset.player] = panel?.querySelector(`.eligibility-reason[data-player="${toggle.dataset.player}"]`)?.value || "No Gold";
    }

    currentEvent.ineligibleFeatherIds = [...current];
    currentEvent.auctionDraft = {
      puppetCount: +data.get("puppetCount"),
      ldEndPage: +data.get("ldEndPage"),
      ldEndItem: +data.get("ldEndItem"),
      tsEndPage: +data.get("tsEndPage"),
      tsEndItem: +data.get("tsEndItem"),
      maxLdPerBidder: +data.get("maxLdPerBidder"),
      maxTsPerBidder: +data.get("maxTsPerBidder"),
      officerRotationStart: currentEvent.auctionDraft?.officerRotationStart ?? state.officerRotationIndex
    };
    currentEvent.auction = null;
    save("Bidder eligibility updated and Feathers redistributed");
    render();
  }, true);

  window.__havocSafeLoaAuctionCapsPatch = true;
})();