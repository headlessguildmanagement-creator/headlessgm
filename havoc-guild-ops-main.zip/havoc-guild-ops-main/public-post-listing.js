(() => {
  const IMAGE_LIMIT = 5;
  const IMAGE_MAX_BYTES = 3 * 1024 * 1024;
  let supabaseClient = null;

  const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));

  async function api(payload = null, method = "GET") {
    const options = method === "POST"
      ? { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload) }
      : {};
    return havocPublicApi("/api/config?proxy=marketplace", options);
  }

  async function initStorage() {
    if (supabaseClient) return supabaseClient;
    const cfg = await havocPublicApi("/api/config");
    supabaseClient = window.supabase.createClient(cfg.url, cfg.publishableKey);
    return supabaseClient;
  }

  async function uploadImages(listingId, uploadKey, files) {
    const selected = [...files];
    if (!selected.length) return;
    if (selected.length > IMAGE_LIMIT) throw new Error("Maximum 5 photos per listing.");
    const client = await initStorage();

    for (let i = 0; i < selected.length; i++) {
      const file = selected[i];
      if (!["image/jpeg","image/png","image/webp"].includes(file.type)) throw new Error("Photos must be JPG, PNG, or WebP.");
      if (file.size > IMAGE_MAX_BYTES) throw new Error(`${file.name} is larger than 3 MB.`);

      const signed = await api({
        action:"upload_image_url",
        listingId,
        password:uploadKey,
        fileName:file.name,
        contentType:file.type,
        size:file.size,
        position:i
      },"POST");

      const upload = await client.storage.from(signed.bucket).uploadToSignedUrl(
        signed.path,
        signed.uploadToken,
        file,
        {contentType:file.type}
      );
      if (upload.error) throw upload.error;

      await api({
        action:"register_image",
        listingId,
        password:uploadKey,
        path:signed.path,
        fileName:file.name,
        contentType:file.type,
        size:file.size,
        position:i
      },"POST");
    }
  }

  document.querySelector("#public-category")?.addEventListener("change", event => {
    document.querySelector("#public-title-label").textContent = event.target.value === "Account" ? "ACCOUNT TITLE" : "ITEM NAME";
  });

  document.querySelector("#public-photos")?.addEventListener("change", event => {
    const box = document.querySelector("#photo-preview");
    box.innerHTML = "";
    [...event.target.files].slice(0, IMAGE_LIMIT).forEach(file => {
      const img = document.createElement("img");
      img.src = URL.createObjectURL(file);
      box.appendChild(img);
    });
  });

  document.querySelector("#public-listing-form")?.addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;

    const fd = new FormData(form);
    const button = document.querySelector("#post-listing-button");
    const resultBox = document.querySelector("#post-result");
    button.disabled = true;
    button.textContent = "Posting...";
    resultBox.innerHTML = "";

    try {
      const created = await api({
        action:"create_listing",
        intent:fd.get("intent"),
        category:fd.get("category"),
        ign:fd.get("ign"),
        title:fd.get("title"),
        price:fd.get("price"),
        description:fd.get("description"),
        password:fd.get("password")
      },"POST");

      await uploadImages(created.listingId, created.uploadKey, document.querySelector("#public-photos").files);

      resultBox.innerHTML = `<div class="success"><strong>Listing posted.</strong><br/>${created.passwordEnabled ? "Keep your Listing Password. You will need it to manage the listing." : "No Listing Password was set. Anyone can manage this listing."}<br/><br/><a href="/marketplace">View your listing in the Marketplace</a></div>`;
      form.reset();
      document.querySelector("#photo-preview").innerHTML = "";
    } catch (error) {
      resultBox.innerHTML = `<div class="error">${esc(error.message)}</div>`;
    } finally {
      button.disabled = false;
      button.textContent = "Post listing";
    }
  });
})();