(() => {
  const MEMBER_PUPPET_PATH = '/puppet-rotation';

  function exposeMemberPuppetNav() {
    if (accessMode !== 'member') return;
    const button = document.querySelector('#nav button[data-view="puppet"]');
    if (button) button.classList.remove('hidden');
  }

  const originalRender = render;
  render = function memberPuppetAwareRender() {
    const result = originalRender();
    exposeMemberPuppetNav();
    return result;
  };

  // features.js previously treated Puppet Rotation as officer-only. Override only
  // that route for members so the existing read-only Puppet Appeal view can render.
  if (accessMode === 'member' && location.pathname === MEMBER_PUPPET_PATH) {
    currentView = 'puppet';
  }

  exposeMemberPuppetNav();
})();
