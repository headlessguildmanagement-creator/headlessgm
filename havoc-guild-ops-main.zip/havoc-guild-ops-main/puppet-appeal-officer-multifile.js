(() => {
  async function enhanceOfficerAppealScreenshots() {
    if (accessMode !== 'commander' || !officerSession?.access_token) return;
    const panel = document.querySelector('#puppet-appeals-panel');
    if (!panel) return;
    try {
      const response = await fetch('/api/state-store', { headers: { Authorization: `Bearer ${officerSession.access_token}` } });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) return;
      const byId = new Map((result.appeals || []).map(row => [String(row.id), row]));
      panel.querySelectorAll('.puppet-appeal-row').forEach(rowEl => {
        const clearButton = rowEl.querySelector('.puppet-appeal-clear[data-id]');
        const actions = rowEl.querySelector('.puppet-appeal-actions');
        if (!clearButton || !actions) return;
        const appeal = byId.get(String(clearButton.dataset.id));
        const urls = appeal?.screenshotUrls?.length ? appeal.screenshotUrls : (appeal?.screenshotUrl ? [appeal.screenshotUrl] : []);
        actions.querySelectorAll('a[data-puppet-proof], a[href][class*="button"]').forEach(link => link.remove());
        urls.forEach((url, index) => {
          const link = document.createElement('a');
          link.className = 'button ghost small';
          link.href = url;
          link.target = '_blank';
          link.rel = 'noopener';
          link.dataset.puppetProof = 'true';
          link.textContent = urls.length === 1 ? 'View screenshot' : `Screenshot ${index + 1}`;
          actions.insertBefore(link, actions.firstChild);
        });
      });
    } catch (error) {
      console.error('Could not enhance Puppet appeal screenshots', error);
    }
  }

  const originalRender = render;
  render = function puppetAppealOfficerMultiFileRender() {
    const result = originalRender.apply(this, arguments);
    if (accessMode === 'commander') setTimeout(enhanceOfficerAppealScreenshots, 80);
    return result;
  };
})();
