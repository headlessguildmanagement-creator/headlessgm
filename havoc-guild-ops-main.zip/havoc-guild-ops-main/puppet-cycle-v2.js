(() => {
  const currentCycle = () => Number(state.puppetCycle || 1);

  function rotation() {
    return (state.players || [])
      .filter(member => member.active && Number.isInteger(member.puppetOrder))
      .sort((a, b) => a.puppetOrder - b.puppetOrder);
  }

  function activeLoa(event, playerId) {
    return (state.loas || []).some(row => row.eventId === event?.id && row.playerId === playerId && !row.cancelledAt);
  }

  function unavailableReason(member, event) {
    if (!member || !event) return null;
    if (activeLoa(event, member.id)) return 'LOA';
    if ((event.noShows || []).includes(member.id)) return 'NO SHOW';
    if ((event.puppetCannotBidIds || []).includes(member.id)) return 'CANNOT BID';
    if ((event.ineligibleFeatherIds || []).includes(member.id) && event.featherIneligibleReasons?.[member.id] === 'Absent') return 'ABSENT';
    return null;
  }

  function isUnavailable(member, event) {
    return Boolean(unavailableReason(member, event));
  }

  function is96h(member, event) {
    return typeof window.havocIsMemberEligibleForEvent === 'function'
      ? !window.havocIsMemberEligibleForEvent(member, event)
      : false;
  }

  function appealWindowOpen(cycle) {
    return typeof window.__havocAppealWindowOpen === 'function'
      ? window.__havocAppealWindowOpen(cycle)
      : Number(cycle) === currentCycle();
  }

  function activeDeferred(event) {
    const byId = new Map((state.players || []).map(member => [member.id, member]));
    return (state.puppetDeferredTurns || [])
      .filter(row => !row.consumedAt)
      .sort((a, b) => Number(a.sourceCycle || 0) - Number(b.sourceCycle || 0) || String(a.createdAt || '').localeCompare(String(b.createdAt || '')))
      .map(row => ({ row, member: byId.get(row.playerId) }))
      .filter(({ member }) => member?.active && Number.isInteger(member.puppetOrder) && !isUnavailable(member, event) && !is96h(member, event));
  }

  function activeAppeals(event) {
    const byId = new Map((state.players || []).map(member => [member.id, member]));
    return (state.puppetAppealQueue || [])
      .filter(row => !row.consumedAt && appealWindowOpen(row.sourceCycle))
      .sort((a, b) => Number(a.sourceCycle || 0) - Number(b.sourceCycle || 0) || String(a.approvedAt || '').localeCompare(String(b.approvedAt || '')))
      .map(row => ({ row, member: byId.get(row.playerId) }))
      .filter(({ member }) => member?.active && Number.isInteger(member.puppetOrder) && !isUnavailable(member, event) && !is96h(member, event));
  }

  function activeCreditIds() {
    return new Set((state.puppetNextCycleCredits || [])
      .filter(row => !row.appliedAt && Number(row.sourceCycle) === currentCycle())
      .map(row => row.playerId));
  }

  function selectPuppets(event, requestedCount) {
    const count = Math.max(0, Math.floor(Number(requestedCount) || 0));
    if (!count) return [];
    const cycle = currentCycle();
    const list = rotation();
    const available = list.filter(member => !isUnavailable(member, event) && !is96h(member, event));
    const incomplete = list.filter(member => !member.puppetComplete);
    const assignments = [];
    const assigned = new Set();

    const take = (member, kind, sourceCycle, extra = {}) => {
      if (!member || assigned.has(member.id) || assignments.length >= count) return;
      assigned.add(member.id);
      assignments.push({
        playerId: member.id,
        puppetTurnKind: kind,
        puppetSourceCycle: Number(sourceCycle),
        puppetCycleOffset: kind === 'rollover' ? 1 : 0,
        ...extra
      });
    };

    // Priority 1: old deferred obligations from LOA / Cannot Bid / no-show.
    activeDeferred(event).forEach(({ row, member }) => take(member, 'deferred', row.sourceCycle, { puppetDeferredId: row.id }));

    // Priority 2: approved appeal make-ups.
    activeAppeals(event).forEach(({ row, member }) => take(member, 'appeal', row.sourceCycle, { puppetAppealId: row.appealId }));

    // Priority 3: normal current-cycle pending queue.
    available.filter(member => !member.puppetComplete).forEach(member => take(member, 'normal', cycle));

    const selectedCurrent = new Set(assignments
      .filter(row => row.puppetTurnKind === 'normal' && row.puppetSourceCycle === cycle)
      .map(row => row.playerId));

    const cycleCanClose = incomplete.every(member =>
      selectedCurrent.has(member.id) || is96h(member, event) || isUnavailable(member, event)
    );

    if (cycleCanClose && assignments.length < count) {
      const credited = activeCreditIds();
      available
        .filter(member => member.puppetComplete && !credited.has(member.id))
        .forEach(member => take(member, 'rollover', cycle + 1));
    }

    return assignments;
  }

  function marketplaceDeal(ownerId, event) {
    const deal = window.havocMarketplacePuppetDeal?.(ownerId) || null;
    if (!deal?.buyer_player_id) return null;
    const buyer = player(deal.buyer_player_id);
    return {
      deal,
      buyer,
      available: Boolean(buyer?.active && !isUnavailable(buyer, event) && !is96h(buyer, event))
    };
  }

  function puppetSlots(event, count) {
    const requested = Math.max(0, Math.floor(Number(count) || 0));
    if (!requested) return [];
    const candidateLimit = Math.min(rotation().length + 20, Math.max(requested + 40, 40));
    const candidates = selectPuppets(event, candidateLimit);
    const priority = candidates.filter(row => ['deferred','appeal'].includes(row.puppetTurnKind)).slice(0, requested);
    const priorityActualIds = new Set(priority.map(row => row.playerId));
    const natural = candidates.filter(row => !['deferred','appeal'].includes(row.puppetTurnKind));
    const needed = Math.max(0, requested - priority.length);
    let selected = natural.slice(0, needed);
    let cursor = needed;

    // A purchased Puppet right takes priority over the buyer's own natural turn.
    // The buyer can bid only once in the event, so their natural turn stays pending
    // and the next eligible rotation member is pulled forward as the replacement.
    for (let guard = 0; guard < 100 && selected.length; guard++) {
      const dealByOwner = new Map();
      const purchasedBuyerIds = new Set();
      const blockedOwners = new Set();

      for (const owner of selected) {
        const info = marketplaceDeal(owner.playerId, event);
        if (!info) continue;
        if (!info.available || priorityActualIds.has(info.buyer?.id)) {
          blockedOwners.add(owner.playerId);
          continue;
        }
        dealByOwner.set(owner.playerId, info);
        purchasedBuyerIds.add(info.buyer.id);
      }

      const filtered = selected.filter(owner => {
        if (blockedOwners.has(owner.playerId)) return false;
        if (purchasedBuyerIds.has(owner.playerId) && !dealByOwner.has(owner.playerId)) return false;
        return true;
      });

      let changed = filtered.length !== selected.length;
      selected = filtered;
      const selectedOwners = new Set(selected.map(row => row.playerId));
      while (selected.length < needed && cursor < natural.length) {
        const candidate = natural[cursor++];
        if (!candidate || selectedOwners.has(candidate.playerId)) continue;
        selected.push(candidate);
        selectedOwners.add(candidate.playerId);
        changed = true;
      }
      if (!changed) break;
    }

    const finalAssignments = [...priority];
    const usedActualIds = new Set(priority.map(row => row.playerId));
    for (const owner of selected) {
      const info = marketplaceDeal(owner.playerId, event);
      if (info && info.available && !usedActualIds.has(info.buyer.id)) {
        usedActualIds.add(info.buyer.id);
        finalAssignments.push({
          ...owner,
          playerId: info.buyer.id,
          puppetRotationOwnerId: owner.playerId,
          marketplaceListingId: info.deal.id,
          marketplaceRightType: 'puppet',
          marketplaceOriginalPlayerId: owner.playerId,
          marketplaceBuyerPlayerId: info.buyer.id,
          marketplaceSource: 'sold'
        });
      } else if (!info) {
        if (usedActualIds.has(owner.playerId)) continue;
        usedActualIds.add(owner.playerId);
        finalAssignments.push(owner);
      }
      if (finalAssignments.length >= requested) break;
    }

    return finalAssignments.slice(0, requested).map((assignment, index) => ({
      ...slotAt(index, 'Puppet Fragment', 'Cards'),
      group: null,
      ...assignment
    }));
  }

  const previousBuildAuction = buildAuction;
  buildAuction = function puppetV2Build(event, settings) {
    const nonPuppet = previousBuildAuction(event, { ...settings, puppetCount: 0 });
    return [...puppetSlots(event, settings?.puppetCount), ...nonPuppet];
  };

  const previousBuildDistribution = buildAuctionFromDistribution;
  buildAuctionFromDistribution = function puppetV2Distribution(event, settings, distribution) {
    const nonPuppet = previousBuildDistribution(event, { ...settings, puppetCount: 0 }, distribution);
    return [...puppetSlots(event, settings?.puppetCount), ...nonPuppet];
  };

  function ensureDeferred(member, event, sourceCycle, completionTime) {
    state.puppetDeferredTurns ??= [];
    const existing = state.puppetDeferredTurns.find(row => row.playerId === member.id && !row.consumedAt);
    if (existing) return existing;
    const reason = unavailableReason(member, event);
    if (!reason) return null;
    const row = {
      id: `deferred-${sourceCycle}-${member.id}`,
      playerId: member.id,
      playerName: member.name,
      sourceCycle,
      sourceEventId: event.id,
      sourceEventDate: event.date,
      reason,
      createdAt: completionTime,
      consumedAt: null,
      consumedEventId: null
    };
    state.puppetDeferredTurns.push(row);
    return row;
  }

  function recordCredit(event, item, completionTime, sourceCycle) {
    state.puppetNextCycleCredits ??= [];
    const ownerId = item.puppetRotationOwnerId || item.playerId;
    if (state.puppetNextCycleCredits.some(row => !row.appliedAt && Number(row.sourceCycle) === sourceCycle && row.playerId === ownerId)) return;
    state.puppetNextCycleCredits.push({
      playerId: ownerId,
      sourceCycle,
      eventId: event.id,
      eventDate: event.date,
      earnedAt: completionTime,
      appliedAt: null
    });
  }

  function closeCycleIfReady(event, completionTime) {
    const list = rotation();
    const cycle = currentCycle();
    const unfinished = list.filter(member => !member.puppetComplete);
    const blockers = unfinished.filter(member => !is96h(member, event) && !isUnavailable(member, event));
    if (!list.length || blockers.length) return false;

    for (const member of unfinished) {
      if (is96h(member, event)) continue;
      ensureDeferred(member, event, cycle, completionTime);
    }

    state.puppetCycleHistory ??= [];
    state.puppetCycleHistory.push({
      cycle,
      completedAt: completionTime,
      appealOpenUntil: new Date(new Date(completionTime).getTime() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      completedThroughEvent: event.id,
      members: list.map(member => {
        const penalty = !member.puppetComplete && is96h(member, event);
        const deferred = !member.puppetComplete && !penalty && isUnavailable(member, event);
        return {
          playerId: member.id,
          name: member.name,
          order: member.puppetOrder,
          completedAt: member.puppetComplete ? (member.puppetCompletedAt || event.date) : null,
          deferred96h: penalty,
          deferredTurn: deferred,
          deferredReason: deferred ? unavailableReason(member, event) : null
        };
      })
    });

    for (const member of list) {
      member.puppetComplete = false;
      member.puppetCompletedAt = null;
    }
    state.puppetCycle = cycle + 1;
    return true;
  }

  function applyCredits(sourceCycle, completionTime) {
    let applied = 0;
    for (const row of (state.puppetNextCycleCredits || []).filter(row => !row.appliedAt && Number(row.sourceCycle) === Number(sourceCycle))) {
      const member = player(row.playerId);
      if (!member || member.puppetComplete) {
        row.appliedAt = completionTime;
        continue;
      }
      member.puppetComplete = true;
      member.puppetCompletedAt = row.eventDate || null;
      row.appliedAt = completionTime;
      applied++;
    }
    return applied;
  }

  function confirmPuppets(event) {
    const assignments = (event.auction?.assignments || []).filter(item => item.category === 'Puppet Fragment');
    if (!assignments.length) return { assigned: 0, cycleAdvanced: false, appealsConsumed: 0, deferredConsumed: 0, rolloverApplied: 0 };

    const cycle = currentCycle();
    const completionTime = new Date().toISOString();
    state.puppetAppealQueue ??= [];
    state.puppetDeferredTurns ??= [];
    let appealsConsumed = 0;
    let deferredConsumed = 0;

    for (const item of assignments) {
      const kind = item.puppetTurnKind || (item.puppetAppealId ? 'appeal' : Number(item.puppetCycleOffset || 0) > 0 ? 'rollover' : 'normal');
      if (kind === 'appeal') {
        const row = state.puppetAppealQueue.find(x => x.appealId === item.puppetAppealId && !x.consumedAt);
        if (row) {
          row.consumedAt = completionTime;
          row.consumedEventId = event.id;
          appealsConsumed++;
        }
        continue;
      }
      if (kind === 'deferred') {
        const row = state.puppetDeferredTurns.find(x => (x.id === item.puppetDeferredId || (x.playerId === item.playerId && Number(x.sourceCycle) === Number(item.puppetSourceCycle))) && !x.consumedAt);
        if (row) {
          row.consumedAt = completionTime;
          row.consumedEventId = event.id;
          deferredConsumed++;
        }
        continue;
      }
      if (kind === 'rollover') {
        recordCredit(event, item, completionTime, cycle);
        continue;
      }
      if (kind === 'normal' && Number(item.puppetSourceCycle || cycle) === cycle) {
        const member = player(item.puppetRotationOwnerId || item.playerId);
        if (member && !member.puppetComplete) {
          member.puppetComplete = true;
          member.puppetCompletedAt = event.date;
        }
      }
    }

    const cycleAdvanced = closeCycleIfReady(event, completionTime);
    const rolloverApplied = cycleAdvanced ? applyCredits(cycle, completionTime) : 0;
    return { assigned: new Set(assignments.map(item => item.playerId)).size, cycleAdvanced, appealsConsumed, deferredConsumed, rolloverApplied };
  }

  function makeUpFor(memberId) {
    const deferred = (state.puppetDeferredTurns || []).find(row => row.playerId === memberId && !row.consumedAt);
    if (deferred) return { type: 'deferred', cycle: Number(deferred.sourceCycle), row: deferred };
    const appeal = (state.puppetAppealQueue || []).find(row => row.playerId === memberId && !row.consumedAt && appealWindowOpen(row.sourceCycle));
    if (appeal) return { type: 'appeal', cycle: Number(appeal.sourceCycle), row: appeal };
    return null;
  }

  function assignmentMap(event) {
    return new Map((event?.auction?.assignments || []).filter(item => item.category === 'Puppet Fragment').map(item => [item.puppetRotationOwnerId || item.playerId, item]));
  }

  renderPuppetQueue = function puppetV2RenderQueue() {
    const event = eventById(selectedEventId) || state.events[0];
    const list = rotation();
    const cycle = currentCycle();
    const assignments = assignmentMap(event);
    const controls = currentView === 'puppet' && accessMode === 'commander';
    const outstandingDeferred = (state.puppetDeferredTurns || []).filter(row => !row.consumedAt);
    const outstandingAppeals = (state.puppetAppealQueue || []).filter(row => !row.consumedAt && appealWindowOpen(row.sourceCycle));
    const makeUpCount = outstandingDeferred.length + outstandingAppeals.length;

    const summary = `<div class="card"><div class="section-head"><div><h2>Puppet Rotation</h2><p>Old make-up obligations are cleared first. Completing an old-cycle make-up never consumes the member's normal turn in the current cycle.</p></div><div class="card-actions"><span class="pill purple">CURRENT CYCLE ${cycle}</span>${makeUpCount ? `<span class="pill amber">${makeUpCount} MAKE-UP${makeUpCount === 1 ? '' : 'S'}</span>` : ''}</div></div></div>`;

    const priorityRows = [...outstandingDeferred.map(row => ({...row, type:'Deferred'})), ...outstandingAppeals.map(row => ({...row, type:'Appeal', id:row.appealId}))]
      .sort((a,b) => Number(a.sourceCycle||0)-Number(b.sourceCycle||0))
      .map(row => {
        const member = player(row.playerId);
        if (!member) return '';
        return `<div class="event-row"><span class="pill purple">MAKE-UP · CYCLE ${Number(row.sourceCycle)}</span><div><strong>${esc(member.name)}</strong><p>${row.type}${row.reason ? ` · ${esc(row.reason)}` : ''}</p></div></div>`;
      }).join('');

    const priority = priorityRows ? `<div class="card"><div class="section-head"><div><h2>Priority make-ups</h2><p>These are old obligations and are selected before normal Cycle ${cycle} bidders when the member is available.</p></div></div>${priorityRows}</div>` : '';

    const rows = list.map((member, index) => {
      const assignment = assignments.get(member.id);
      const makeUp = makeUpFor(member.id);
      const unavailable = unavailableReason(member, event);
      const penalty = is96h(member, event);
      const kind = assignment?.puppetTurnKind || (assignment?.puppetAppealId ? 'appeal' : Number(assignment?.puppetCycleOffset || 0) > 0 ? 'rollover' : assignment ? 'normal' : null);
      const sourceCycle = Number(assignment?.puppetSourceCycle || (kind === 'rollover' ? cycle + 1 : cycle));

      let status;
      if (unavailable) status = `<span class="pill red">${esc(unavailable)}</span>`;
      else if (penalty) status = `<span class="pill red">96H · CYCLE ${cycle}</span>`;
      else if (kind === 'deferred' || kind === 'appeal') status = `<span class="pill purple">MAKE-UP BIDDER · CYCLE ${sourceCycle}</span>`;
      else if (kind === 'rollover') status = `<span class="pill purple">NEXT CYCLE BIDDER · CYCLE ${sourceCycle}</span>`;
      else if (kind === 'normal') status = `<span class="pill amber">CURRENT BIDDER · CYCLE ${cycle}</span>`;
      else if (makeUp) status = `<span class="pill purple">MAKE-UP PENDING · CYCLE ${makeUp.cycle}</span>`;
      else if (member.puppetComplete) status = `<span class="pill green">DONE · CYCLE ${cycle}</span>`;
      else status = `<span class="pill amber">PENDING · CYCLE ${cycle}</span>`;

      let completion = member.puppetCompletedAt ? formatDate(member.puppetCompletedAt) : '—';
      if (kind) completion = `Selected · ${formatDate(event.date)}`;
      if (makeUp && !kind) completion = `Old Cycle ${makeUp.cycle} obligation`;

      let actions = '—';
      if (controls) {
        if (unavailable === 'CANNOT BID') actions = `<button class="button ghost small puppet-restore-bid" data-player="${member.id}">Can Bid Again</button>`;
        else if (kind === 'deferred' || kind === 'appeal' || kind === 'rollover') actions = `<button class="button ghost small puppet-cannot-bid" data-player="${member.id}">Cannot Bid</button>`;
        else if (makeUp?.type === 'deferred') actions = `<button class="button small puppet-deferred-complete" data-player="${member.id}" data-id="${esc(makeUp.row.id)}">Complete Make-up</button>`;
        else if (makeUp?.type === 'appeal') actions = `<button class="button small puppet-complete" data-player="${member.id}">Complete Make-up</button>`;
        else if (member.puppetComplete) actions = `<button class="button ghost small puppet-set-pending" data-player="${member.id}">Set Pending</button>`;
        else actions = `<div class="card-actions"><button class="button small puppet-complete" data-player="${member.id}">Complete Puppet</button><button class="button ghost small puppet-cannot-bid" data-player="${member.id}">Cannot Bid</button></div>`;
      }

      return `<tr><td>${index + 1}</td><td><strong>${esc(member.name)}</strong></td><td>${status}</td><td>${completion}</td><td>${actions}</td></tr>`;
    }).join('');

    return `${summary}${priority}<div class="card"><div class="section-head"><div><h2>Cycle ${cycle} A-Z queue</h2><p>LOA, Cannot Bid and no-show skip the member without freezing the guild. 96H members do not carry an old-cycle turn.</p></div><span class="pill amber">${list.length} ACTIVE MEMBERS</span></div><div class="table-wrap"><table><thead><tr><th>Position</th><th>Player</th><th>Status</th><th>Completion / selection</th><th>Actions</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
  };

  document.addEventListener('click', event => {
    const button = event.target.closest?.('#confirm-puppet');
    if (!button) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const selected = eventById(selectedEventId);
    if (!selected?.auction) return;
    if (selected.puppetCompletionRecordedAt) return toast('Puppet completions were already recorded for this event');
    window.havocSnapshotAuctionHistory?.(selected);
    const result = confirmPuppets(selected);
    if (!result.assigned) return toast('No Puppet assignments to confirm');
    selected.puppetCompletionRecordedAt = new Date().toISOString();
    const notes = [];
    if (result.deferredConsumed) notes.push(`${result.deferredConsumed} deferred make-up`);
    if (result.appealsConsumed) notes.push(`${result.appealsConsumed} appeal make-up`);
    if (result.rolloverApplied) notes.push(`${result.rolloverApplied} next-cycle turn`);
    save(`${result.assigned} Puppet completions recorded${notes.length ? ` · ${notes.join(' · ')}` : ''}`);
    render();
  }, true);

  document.addEventListener('click', event => {
    const button = event.target.closest?.('.puppet-deferred-complete');
    if (!button) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const row = (state.puppetDeferredTurns || []).find(item => item.id === button.dataset.id && !item.consumedAt);
    const member = row ? player(row.playerId) : null;
    if (!row || !member) return;
    if (!confirm(`Mark ${member.name}'s Cycle ${row.sourceCycle} make-up as DONE? Their Cycle ${currentCycle()} normal turn will not be consumed.`)) return;
    row.consumedAt = new Date().toISOString();
    row.consumedEventId = (eventById(selectedEventId) || state.events[0])?.id || 'manual';
    const selected = eventById(selectedEventId) || state.events[0];
    if (selected) selected.auction = null;
    save(`${member.name} Cycle ${row.sourceCycle} deferred Puppet make-up completed`);
    render();
  }, true);

  window.__havocPuppetV2Selector = selectPuppets;
  window.__havocPuppetV2Confirm = confirmPuppets;
})();
