Replace your existing havoc-guild-ops/package.json with this package.json.
The Vercel API files use ES module import/export syntax, so the project must declare type=module.
Then commit and push the package.json change. Do not change Supabase credentials.
