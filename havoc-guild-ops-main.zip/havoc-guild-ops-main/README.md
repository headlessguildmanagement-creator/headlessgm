# Havoc Guild Operations

A Vercel-ready guild operations system for Ragnarok Origin Classic. This repository contains the working interface and the production Supabase schema.

## Included

- Active roster members in four permanent Feather groups
- Exact Gypsy and Minstrel categories
- Permanent Group 1–4 auction membership
- Guild League rotation: 4 → 3 → 2 → 1
- Emperium Overrun rotation from August 30: 2 → 3 → 4 → 1
- Main and Sub raid lineups, each with eight five-player parties
- Click-to-place lineup building with confirmed Supabase saves
- Players disappear from Available Players immediately after assignment
- Commander no-show tagging after the lineup is built
- No-shows and LOAs are excluded from Feather assignments and from that event's Puppet bidders. Their Puppet queue position is preserved for the next event; No Gold and 96-Hour Penalty remain Feather-only reasons.
- Everyone attending by default
- LOA filing until 2:30 PM PHT for an 8:30 PM call time
- LOA cancellation and automatic return to the available pool
- Automatic exclusion of active LOAs from auction assignments
- Rolling calendar that always keeps 24 upcoming Tuesday, Thursday, and Sunday events available
- Officer Overview alerts for members absent from two or more consecutive completed events
- Officer Overview alerts for active members missing a job, lineup role, or permanent Feather Group
- Lineup Builder warning for every started Main/Sub party that does not yet contain a Support-role player
- Editable member masterlist with add, edit, and permanent removal controls. Removal wipes that member's LOAs, job history, lineup history, event assignments, Puppet position, auction records, and linked access.
- Password-gated officer view and read-only member view
- Havoc-branded officer login with inline validation, password visibility control, and logout state
- Officer navigation badges for active LOAs, unread job changes, and consecutive-absence alerts
- Member-facing Line Up search showing Main/Sub, party number, and party leader
- Previous-lineup import that automatically excludes inactive, LOA, and absent players
- OZAWA/Zonzi-only officer account management for adding, changing, and revoking officer logins
- Member-accessible job, lineup-role, and IGN updates
- IGN changes preserve the same member identity, Feather Group, Puppet position/status, Lineups, LOAs, Auction history, and linked officer access
- Job-change requests show the member's recorded previous job before submission; the officer log separates Previous Job, New Job, New Role, and Reason
- Havoc crest and Void Black/Blood Crimson/Ember Orange/Bone Ivory/Gunmetal interface theme
- Independent guild-wide A–Z Puppet rotation
- Puppet Rotation displays only active members with compact current positions. Removing a member clears that inactive record's Puppet order while preserving the relative order of every remaining member; new members still join at the back.
- Puppet completion tracking with preserved completion dates
- 23 current Puppet completions, including the August 27 results
- Feather Group 3 completion recorded for August 27
- Commander-set page-and-item Feather totals with exact Light/Dark-to-Time/Space boundary handling
- Light/Dark and Time/Space are combined, divided into an equal total for every active Feather bidder, and allocated Light/Dark first followed by Time/Space
- Only the indivisible combined-total excess enters the persistent officer round-robin
- Per-event Feather eligibility defaults everyone to Eligible; absence/LOA is automatic, while officers can apply Absent, No Gold, or 96-Hour Penalty
- Eligibility, exclusion reason, calculated Light/Dark, calculated Time/Space, and remainder source appear in one compact officer table
- Successful officer logins persist for 30 days on the same browser unless the officer logs out manually
- Members-table access labels come from login accounts: Administrator for Zonzi/OZAWA, Officer for the other six officer accounts, and Member for everyone else
- Event selectors show three past events plus the current/next three, with all earlier events retained under history
- Confirmation and event-start safeguards for Puppet and Feather completion actions
- Separate officer Lineup Builder and read-only Line Up View navigation
- Officer-only member job-change log with required reasons
- Automatic four-item Cards and Feather page generation
- Simplified member output: player, auction tab, reward, and page/item range
- Illusion cards removed because they are free-for-all
- Supabase production schema and audit-log foundation
- Classic in-game job icons, an overall job breakdown, and a permanent unassigned-job countdown in the Lineup Builder
- Lineup change history capped at 300 records and a warning while the latest Lineup change is still syncing
- Administrator CSV exports and a complete JSON backup
- Shareable routes for the main navigation and event-specific Lineup/Auction links
- Officer-only Discord publication for completed Lineups and Auction assignments

## Important seed-data note

The current masterlist contains 80 members. HairyPotter, Bagi, HuaXia, and WHITE are appended at Puppet positions 77–80. All members have permanent feather groups; newly added members retain blank job and lineup-role fields until updated. All officers can add, edit, and remove ordinary roster members. Only OZAWA and Zonzi can manage officer access or remove a member who still has an active officer account.

Officer lineup, roster, attendance, rotation, and auction saves are verified by `/api/officer-state` and written server-side. Browser officers never require direct write permission on `guild_app_state`, so no additional Supabase SQL grant is required.

Production authentication uses Supabase Auth. Only officers and administrators receive logins; regular members remain roster records without accounts. OZAWA and Zonzi are administrators and control officer access. Temporary passwords are never stored in the app or database; first login requires the user to set a new password.

Feather remainder order is Zonzi → BossRems → SHRUGS → LexuS → OZAWA → Jabberwock → Levantine → RonTzy. Each receives one item before the order repeats, so a remainder of nine gives the ninth item to Zonzi.

## Run locally

```bash
npm run dev
```

Then open `http://localhost:3000`.

The production build uses Supabase Auth and a shared Supabase state store. Browser `localStorage` is not used for authentication or application data.

## Deploy to Vercel

1. Create a new GitHub repository.
2. Push this folder to the repository.
3. Import the repository into Vercel.
4. Keep the project as a static site; `vercel.json` handles route fallback.
5. Configure the existing Supabase environment variables, including the server-only `SUPABASE_SERVICE_ROLE_KEY`.
6. To enable Discord notifications, add `DISCORD_LINEUP_WEBHOOK_URL`, `DISCORD_AUCTION_WEBHOOK_URL`, `DISCORD_LOA_WEBHOOK_URL`, and `PUBLIC_SITE_URL` to the Vercel project and redeploy. Never commit webhook URLs.
7. Add a long random `CRON_SECRET`. Vercel uses it to authorize the daily auction auto-completion job scheduled for 12:00 AM Philippine time (`0 16 * * *` UTC).

Generate the secret locally with `openssl rand -hex 32`, copy only the resulting value into Vercel → Project Settings → Environment Variables as `CRON_SECRET`, select Production/Preview/Development, save, and redeploy. Do not add the real value to this repository.

## Discord publication

Create one incoming webhook for each destination channel. Store them only in Vercel as `DISCORD_LINEUP_WEBHOOK_URL`, `DISCORD_AUCTION_WEBHOOK_URL`, and `DISCORD_LOA_WEBHOOK_URL`. Set `PUBLIC_SITE_URL` to the production Havoc website origin, without a trailing slash. The LOA channel should be restricted to officers because notifications include the filed reason.

Ordinary Lineup and Auction saves do not post to Discord. Signed-in officers must deliberately select **Publish Lineup** or **Publish bidding to Discord**. A Lineup publication sends separate, large-text Main Raid and Sub Raid PNGs. An Auction publication sends separate large-text Feather and Puppet Fragment PNGs, splitting a long Feather list into numbered parts when needed. The raw event URL appears as a clickable link in the Discord message only; it is not printed on the images. Images are generated only for the Discord post and are not stored in Supabase. Recording or cancelling an LOA sends its existing text notification after the server save finishes. Existing members can file/cancel LOA and submit job changes without logging in; these public actions are validated and persisted by the server.

Auction tools are separated by access and purpose:

- `/auction-builder` — officer-only three-step builder and publishing controls.
- `/auction` — read-only, fully expanded assignments for all users.
- `/puppet-rotation` — officer-only permanent Puppet A–Z queue.

Every event automatically completes at 12:00 AM Philippine time on the following day unless an officer has already completed its auction actions manually. The job confirms generated Puppet recipients, records the active Feather group completion, advances the saved officer excess rotation, and closes the event even when the Discord post was not published. When all active members finish the Puppet queue, the same preserved order starts a new recorded cycle automatically.

Officers and administrators can manually publish tomorrow's tentative bidder reminder from Overview. GL reminders show 8 Puppet bidders; EO reminders show 20. The Discord message asks listed members to save Gold for tomorrow's auction and states that the list may change with attendance. Known LOAs and members marked Absent are excluded without completing or moving their Puppet turn; the next available members fill the Puppet list. No Gold and 96-Hour Penalty affect Feathers only.

Feather rotations are independent and calculated from fixed calendar anchors, not from the number of event records stored. Confirmed anchors are **GL Aug 27, 2026 = Group 3** with the continuing `4 → 3 → 2 → 1` cycle, and **EO Aug 30, 2026 = Group 2** with the continuing `1 → 2 → 3 → 4` cycle. Overview opens today's event until 11:59 PM PHT, then opens the next event. All event history remains stored; the operational selector shows three past plus the current/next three, with earlier records available for checking.

## Production database

Create a Supabase project and execute `supabase/schema.sql` in the SQL editor. The schema deliberately enables row-level security without permissive policies. Authentication and role policies should be added when multi-user accounts are implemented.

## Next implementation phase

1. Connect the interface to Supabase.
2. Add commander/admin and member accounts.
3. Add the missing guild members as they join.
4. Connect real officer/member permissions.
5. Confirm officer membership and excess-resource rotation order.
