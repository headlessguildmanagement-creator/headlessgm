(() => {
  function marketplaceReady() {
    return Boolean(window.__havocMarketplaceData);
  }

  function applyFeatherSales(event, assignments) {
    return (assignments || []).map(item => {
      if (item.category === "Puppet Fragment") return item;
      const deal = window.havocMarketplaceFeatherDeal?.(event.id, item.playerId);
      if (!deal?.buyer_player_id) return item;
      return {
        ...item,
        playerId: deal.buyer_player_id,
        marketplaceListingId: deal.id,
        marketplaceRightType: "feather",
        marketplaceOriginalPlayerId: item.playerId,
        marketplaceBuyerPlayerId: deal.buyer_player_id,
        marketplaceSource: "sold"
      };
    });
  }

  const baseBuildAuction = buildAuction;
  buildAuction = function marketplaceBuildAuction(event, settings) {
    return applyFeatherSales(event, baseBuildAuction(event, settings));
  };

  const baseBuildDistribution = buildAuctionFromDistribution;
  buildAuctionFromDistribution = function marketplaceBuildDistribution(event, settings, distribution) {
    return applyFeatherSales(event, baseBuildDistribution(event, settings, distribution));
  };

  const baseBindAuctionV3 = bindAuctionV3;
  bindAuctionV3 = function marketplaceAwareBindAuctionV3() {
    baseBindAuctionV3();
    const form = document.querySelector("#auction-form-v2");
    if (!form) return;
    const generate = form.querySelector('button:not([type="button"])');
    if (!generate) return;
    if (!marketplaceReady()) {
      generate.disabled = true;
      generate.title = "Waiting for Marketplace bidding-right data";
      Promise.resolve(window.havocMarketplaceReady?.()).then(() => {
        if (generate.isConnected) {
          generate.disabled = false;
          generate.title = "";
        }
      }).catch(() => {
        if (generate.isConnected) {
          generate.disabled = true;
          generate.title = "Marketplace data could not be loaded. Refresh before generating.";
        }
      });
    }
  };

  function decorateRotationHtml(html) {
    if (!marketplaceReady() || typeof document === "undefined") return html;
    const sales = (window.__havocMarketplaceData.listings || []).filter(row => row.right_type === "puppet" && row.status === "sold");
    if (!sales.length) return html;
    const template = document.createElement("template");
    template.innerHTML = html;
    for (const sale of sales) {
      const strong = [...template.content.querySelectorAll("strong")].find(node => node.textContent.trim().toLowerCase() === String(sale.seller_ign || "").toLowerCase());
      if (!strong || strong.parentElement?.querySelector(".marketplace-rotation-sale")) continue;
      const marker = document.createElement("small");
      marker.className = "marketplace-rotation-sale";
      marker.innerHTML = `<span class="pill amber">SOLD → ${esc(sale.buyer_ign || "BUYER")}</span>`;
      strong.parentElement.append(marker);
    }
    return template.innerHTML;
  }

  const basePendingPuppetOverview = renderPendingPuppetOverview;
  renderPendingPuppetOverview = function marketplacePendingPuppetOverview() {
    return decorateRotationHtml(basePendingPuppetOverview());
  };

  const basePuppetQueue = renderPuppetQueue;
  renderPuppetQueue = function marketplacePuppetQueue() {
    return decorateRotationHtml(basePuppetQueue());
  };

  const baseCommanderResults = auctionCommanderResults;
  auctionCommanderResults = function marketplaceCommanderResults(event, auction) {
    const base = baseCommanderResults(event, auction);
    const substitutions = (auction?.assignments || []).filter(row => row.marketplaceOriginalPlayerId);
    if (!substitutions.length) return base;
    const unique = new Map();
    for (const row of substitutions) {
      const key = `${row.marketplaceListingId || ""}|${row.marketplaceOriginalPlayerId}|${row.playerId}|${row.category}`;
      if (!unique.has(key)) unique.set(key, row);
    }
    const panel = `<div class="card marketplace-auction-review"><div class="section-head"><div><h2>Marketplace substitutions</h2><p>Actual bidder is shown first. The original owner remains attached for completion and history.</p></div><span class="pill amber">${unique.size} DEAL${unique.size === 1 ? "" : "S"}</span></div>${[...unique.values()].map(row => `<div class="event-row"><span class="pill ${row.category === "Puppet Fragment" ? "amber" : "purple"}">${row.category === "Puppet Fragment" ? "PUPPET" : "FEATHER"}</span><div><strong>${esc(player(row.playerId)?.name || row.playerId)}</strong><p>Buyer for ${esc(player(row.marketplaceOriginalPlayerId)?.name || row.marketplaceOriginalPlayerId)} · Marketplace SOLD</p></div></div>`).join("")}</div>`;
    return `${base}${panel}`;
  };

  document.addEventListener("click", event => {
    const button = event.target.closest?.("#confirm-feathers");
    if (!button) return;
    const selected = eventById(selectedEventId);
    if (!selected?.auction) return;
    window.havocSnapshotAuctionHistory?.(selected);
  }, true);

  document.addEventListener("submit", event => {
    if (event.target?.id !== "auction-form-v2") return;
    if (marketplaceReady()) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    toast("Marketplace bidding-right data is still loading. Wait a moment, then generate again.");
    window.havocMarketplaceReady?.().then(() => render()).catch(() => {});
  }, true);
})();