(() => {
  const APPEAL_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

  function rotation() {
    return state.players
      .filter(member => member.active && Number.isInteger(member.puppetOrder))
      .sort((a, b) => a.puppetOrder - b.puppetOrder);
  }

  function eventTime(event) {
    return new Date(`${event?.date || localISO(new Date())}T${event?.callTime || '20:30'}:00+08:00`);
  }

  function appealWindowOpen(sourceCycle, event) {
    const currentCycle = Number(state.puppetCycle || 1);
    if (Number(sourceCycle) === currentCycle) return true;
    const history = (state.puppetCycleHistory || []).find(row => Number(row.cycle) === Number(sourceCycle));
    if (!history?.completedAt) return false;
    return eventTime(event).getTime() <= new Date(history.completedAt).getTime() + APPEAL_WINDOW_MS;
  }

  function is96hPenalty(member, event) {
    return typeof window.havocIsMemberEligibleForEvent === 'function'
      ? !window.havocIsMemberEligibleForEvent(member, event)
      : false;
  }

  function activeAppeals(event) {
    const byId = new Map(state.players.map(member => [member.id, member]));
    return (state.puppetAppealQueue || [])
      .filter(row => !row.consumedAt && appealWindowOpen(row.sourceCycle, event))
      .sort((a, b) => String(a.approvedAt || '').localeCompare(String(b.approvedAt || '')))
      .map(row => ({ row, member: byId.get(row.playerId) }))
      .filter(({ member }) => member?.active && Number.isInteger(member.puppetOrder) && !isPuppetUnavailable(event, member.id));
  }

  function activeNextCycleCredits() {
    const currentCycle = Number(state.puppetCycle || 1);
    return (state.puppetNextCycleCredits || []).filter(row => !row.appliedAt && Number(row.sourceCycle) === currentCycle);
  }

  function selectBidders(event, requestedCount) {
    const count = Math.max(0, Math.floor(Number(requestedCount) || 0));
    if (!count) return [];
    const list = rotation();
    const available = list.filter(member => !isPuppetUnavailable(event, member.id));
    const incompleteAll = list.filter(member => !member.puppetComplete);
    const incompleteAvailable = available.filter(member => !member.puppetComplete);
    const appeals = activeAppeals(event);
    const creditedIds = new Set(activeNextCycleCredits().map(row => row.playerId));
    const assignments = [];
    const assignedIds = new Set();
    const take = (member, puppetCycleOffset, puppetAppealId = null) => {
      if (!member || assignedIds.has(member.id) || assignments.length >= count) return;
      assignedIds.add(member.id);
      assignments.push({ playerId: member.id, puppetCycleOffset, ...(puppetAppealId ? { puppetAppealId } : {}) });
    };

    // Approved make-ups are priority #1 while their 7-day appeal window is still open.
    appeals.forEach(({ row, member }) => take(member, 0, row.appealId));
    incompleteAvailable.forEach(member => take(member, 0));

    // A 96H-penalty member does not hold the whole guild back. Other unavailable
    // members (LOA/Cannot Bid/no-show) still block rollover as before.
    const currentNormalIds = new Set(assignments
      .filter(row => !row.puppetAppealId && Number(row.puppetCycleOffset || 0) === 0)
      .map(row => row.playerId));
    const normalCycleCanClose = incompleteAll.every(member =>
      currentNormalIds.has(member.id) || is96hPenalty(member, event)
    );

    // Only when the current normal queue can close do excess fragments go back to #1.
    if (normalCycleCanClose && assignments.length < count) {
      available
        .filter(member => member.puppetComplete && !creditedIds.has(member.id))
        .forEach(member => take(member, 1));
    }
    return assignments;
  }

  function puppetSlots(event, count) {
    return selectBidders(event, count).map((assignment, index) => ({
      ...slotAt(index, 'Puppet Fragment', 'Cards'),
      playerId: assignment.playerId,
      group: null,
      puppetCycleOffset: assignment.puppetCycleOffset,
      ...(assignment.puppetAppealId ? { puppetAppealId: assignment.puppetAppealId } : {})
    }));
  }

  const originalBuildAuction = buildAuction;
  buildAuction = function cycleAwareBuildAuction(event, settings) {
    const result = originalBuildAuction(event, { ...settings, puppetCount: 0 });
    return [...puppetSlots(event, settings.puppetCount), ...result];
  };

  const originalBuildAuctionFromDistribution = buildAuctionFromDistribution;
  buildAuctionFromDistribution = function cycleAwareBuildAuctionFromDistribution(event, settings, distribution) {
    const result = originalBuildAuctionFromDistribution(event, { ...settings, puppetCount: 0 }, distribution);
    return [...puppetSlots(event, settings.puppetCount), ...result];
  };

  renderPuppetQueue = function cycleAwareRenderPuppetQueue() {
    const event = eventById(selectedEventId) || state.events[0];
    const skipped = new Set(event?.puppetCannotBidIds || []);
    const puppetAssignments = new Map((event?.auction?.assignments || [])
      .filter(item => item.category === 'Puppet Fragment')
      .map(item => [item.playerId, item]));
    const appealByPlayer = new Map(activeAppeals(event).map(({ row }) => [row.playerId, row]));
    const nextCycleCreditIds = new Set(activeNextCycleCredits().map(row => row.playerId));
    const list = rotation();
    const controlsEnabled = currentView === 'puppet' && accessMode === 'commander';

    const appealQueueHtml = [...appealByPlayer.values()].map((row, index) => {
      const member = player(row.playerId);
      return member ? `<div class="event-row"><span class="pill purple">PRIORITY MAKE-UP ${index + 1}</span><div><strong>${esc(member.name)}</strong><p>Approved Cycle ${row.sourceCycle} appeal. This bidder is prioritized while the 7-day appeal window remains open.</p></div></div>` : '';
    }).join('');

    return `${appealQueueHtml ? `<div class="card"><div class="section-head"><div><h2>Approved Puppet make-up turns</h2><p>Valid approved make-ups are selected before the normal queue.</p></div><span class="pill purple">${appealByPlayer.size} PRIORITY</span></div>${appealQueueHtml}</div>` : ''}<div class="card"><div class="section-head"><div><h2>Puppet A–Z rotation</h2><p>${controlsEnabled ? '96H-penalty members are skipped without blocking rollover. Other event-specific unavailability rules still apply.' : 'Read-only Puppet rotation. Officers control all status changes.'}</p></div><span class="pill amber">${list.length} ACTIVE MEMBERS</span></div><div class="table-wrap"><table><thead><tr><th>Current position</th><th>Player</th><th>Status</th><th>Completion date</th><th>Actions</th></tr></thead><tbody>${list.map((member, index) => {
      const assignment = puppetAssignments.get(member.id);
      const appealBidder = Boolean(assignment?.puppetAppealId);
      const rolloverBidder = !appealBidder && Number(assignment?.puppetCycleOffset || 0) > 0;
      const currentBidder = Boolean(assignment) && !rolloverBidder && !appealBidder;
      const cannotBid = skipped.has(member.id);
      const awaitingAppeal = appealByPlayer.has(member.id);
      const creditedNextCycle = nextCycleCreditIds.has(member.id);
      let status;
      if (cannotBid) status = '<span class="pill red">CANNOT BID</span>';
      else if (appealBidder) status = '<span class="pill purple">MAKE-UP BIDDER</span>';
      else if (rolloverBidder) status = '<span class="pill purple">NEXT CYCLE BIDDER</span>';
      else if (currentBidder && !member.puppetComplete) status = '<span class="pill amber">CURRENT BIDDER</span>';
      else if (awaitingAppeal) status = '<span class="pill purple">MAKE-UP PENDING</span>';
      else if (creditedNextCycle) status = '<span class="pill purple">NEXT CYCLE CREDIT</span>';
      else if (member.puppetComplete) status = '<span class="pill green">DONE</span>';
      else status = '<span class="pill amber">PENDING</span>';

      let completion = member.puppetCompletedAt ? formatDate(member.puppetCompletedAt) : '—';
      if (rolloverBidder || appealBidder) completion = `Selected for ${formatDate(event.date)}`;

      let actions = '—';
      if (controlsEnabled) {
        if (cannotBid) actions = `<button class="button ghost small puppet-restore-bid" data-player="${member.id}">Can Bid Again</button>`;
        else if (appealBidder) actions = `<button class="button ghost small puppet-cannot-bid" data-player="${member.id}">Cannot Bid</button>`;
        else if (awaitingAppeal) actions = `<button class="button small puppet-complete" data-player="${member.id}">Complete Make-up</button>`;
        else if (rolloverBidder) actions = `<button class="button ghost small puppet-cannot-bid" data-player="${member.id}">Cannot Bid</button>`;
        else if (member.puppetComplete) actions = `<button class="button ghost small puppet-set-pending" data-player="${member.id}">Set Pending</button>`;
        else actions = `<div class="card-actions"><button class="button small puppet-complete" data-player="${member.id}">Complete Puppet</button><button class="button ghost small puppet-cannot-bid" data-player="${member.id}">Cannot Bid</button></div>`;
      }
      return `<tr><td>${index + 1}</td><td><strong>${esc(member.name)}</strong></td><td>${status}</td><td>${completion}</td><td>${actions}</td></tr>`;
    }).join('')}</tbody></table></div></div>`;
  };

  function archiveAndReset(event, completionTime) {
    const list = rotation();
    const unfinishedNonPenalty = list.filter(member => !member.puppetComplete && !is96hPenalty(member, event));
    if (!list.length || unfinishedNonPenalty.length) return false;
    state.puppetCycleHistory ??= [];
    state.puppetCycle ??= 1;
    state.puppetCycleHistory.push({
      cycle: state.puppetCycle,
      completedAt: completionTime,
      appealOpenUntil: new Date(new Date(completionTime).getTime() + APPEAL_WINDOW_MS).toISOString(),
      completedThroughEvent: event.id,
      members: list.map(member => ({
        playerId: member.id,
        name: member.name,
        order: member.puppetOrder,
        completedAt: member.puppetComplete ? (member.puppetCompletedAt || event.date) : null,
        deferred96h: !member.puppetComplete && is96hPenalty(member, event)
      }))
    });
    for (const member of list) {
      member.puppetComplete = false;
      member.puppetCompletedAt = null;
    }
    state.puppetCycle += 1;
    return true;
  }

  function recordNextCycleCredits(event, rollover, completionTime) {
    state.puppetNextCycleCredits ??= [];
    const sourceCycle = Number(state.puppetCycle || 1);
    for (const item of rollover) {
      if (state.puppetNextCycleCredits.some(row => !row.appliedAt && Number(row.sourceCycle) === sourceCycle && row.playerId === item.playerId)) continue;
      state.puppetNextCycleCredits.push({ playerId: item.playerId, sourceCycle, eventId: event.id, eventDate: event.date, earnedAt: completionTime, appliedAt: null });
    }
  }

  function applyNextCycleCredits(sourceCycle, completionTime) {
    let applied = 0;
    for (const row of (state.puppetNextCycleCredits || []).filter(row => !row.appliedAt && Number(row.sourceCycle) === Number(sourceCycle))) {
      const member = player(row.playerId);
      if (!member || member.puppetComplete) { row.appliedAt = completionTime; continue; }
      member.puppetComplete = true;
      member.puppetCompletedAt = row.eventDate || null;
      row.appliedAt = completionTime;
      applied++;
    }
    return applied;
  }

  function confirmCycleAwarePuppets(event) {
    const assignments = (event.auction?.assignments || []).filter(item => item.category === 'Puppet Fragment');
    if (!assignments.length) return { assigned: 0, rolloverApplied: 0, cycleAdvanced: false, appealsConsumed: 0 };
    state.puppetAppealQueue ??= [];
    const completionTime = new Date().toISOString();
    let appealsConsumed = 0;
    for (const item of assignments.filter(item => item.puppetAppealId)) {
      const queueRow = state.puppetAppealQueue.find(row => row.appealId === item.puppetAppealId && !row.consumedAt);
      if (!queueRow) continue;
      queueRow.consumedAt = completionTime;
      queueRow.consumedEventId = event.id;
      appealsConsumed++;
    }

    const current = assignments.filter(item => !item.puppetAppealId && Number(item.puppetCycleOffset || 0) === 0);
    const rollover = assignments.filter(item => !item.puppetAppealId && Number(item.puppetCycleOffset || 0) > 0);
    for (const item of current) {
      const member = player(item.playerId);
      if (!member || member.puppetComplete) continue;
      member.puppetComplete = true;
      member.puppetCompletedAt = event.date;
    }

    const sourceCycle = Number(state.puppetCycle || 1);
    recordNextCycleCredits(event, rollover, completionTime);
    const cycleAdvanced = archiveAndReset(event, completionTime);
    const rolloverApplied = cycleAdvanced ? applyNextCycleCredits(sourceCycle, completionTime) : 0;
    return { assigned: new Set(assignments.map(item => item.playerId)).size, rolloverApplied, cycleAdvanced, appealsConsumed };
  }

  document.addEventListener('click', event => {
    const button = event.target.closest?.('#confirm-puppet');
    if (!button) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const currentEvent = eventById(selectedEventId);
    if (!currentEvent?.auction) return;
    if (currentEvent.puppetCompletionRecordedAt) return toast('Puppet completions were already recorded for this event');
    const result = confirmCycleAwarePuppets(currentEvent);
    if (!result.assigned) return toast('No Puppet assignments to confirm');
    currentEvent.puppetCompletionRecordedAt = new Date().toISOString();
    const parts = [];
    if (result.appealsConsumed) parts.push(`${result.appealsConsumed} appeal make-up turn${result.appealsConsumed === 1 ? '' : 's'}`);
    if (result.rolloverApplied) parts.push(`${result.rolloverApplied} next-cycle credit${result.rolloverApplied === 1 ? '' : 's'} applied`);
    save(`${result.assigned} Puppet completions recorded${parts.length ? `, including ${parts.join(' and ')}` : ''}`);
    render();
  }, true);
})();
