(() => {
  function pastIncompleteEvents() {
    const today = localISO(new Date());
    return (state.events || [])
      .filter(event => event.date < today && !event.eventCompletedAt)
      .sort((a, b) => b.date.localeCompare(a.date));
  }

  function mountRecovery() {
    if (accessMode !== "commander" || !officerSession?.access_token) return;
    if (!["overview", "auctionbuilder", "auction"].includes(currentView)) return;
    if (document.querySelector("#auction-recovery-card")) return;
    const pending = pastIncompleteEvents();
    const target = pending[0];
    const app = document.querySelector("#app");
    const anchor = app?.querySelector(".grid.stats") || app?.firstElementChild;
    if (!app || !anchor) return;

    const card = document.createElement("div");
    card.id = "auction-recovery-card";
    card.className = "card officer-data-alerts";
    card.innerHTML = target ? `<div class="section-head"><div><p class="eyebrow">RECOVERY</p><h2>Missed midnight auto-complete</h2><p><strong>${esc(target.name)} · ${esc(formatDate(target.date))}</strong> is still incomplete. Run the same Puppet + Feather completion logic used by the 12:00 AM PHT cron.</p></div><button id="run-auction-recovery" class="button primary" type="button">Run Auto-Complete Now</button></div>` : `<div class="section-head"><div><p class="eyebrow">AUTO-COMPLETE</p><h2>Midnight recovery</h2><p>No overdue events currently need auto-completion.</p></div><button class="button ghost" type="button" disabled>Nothing to recover</button></div>`;
    anchor.after(card);

    card.querySelector("#run-auction-recovery")?.addEventListener("click", async event => {
      const button = event.currentTarget;
      if (!confirm(`Auto-complete overdue event ${target.name} on ${formatDate(target.date)}? This will commit Puppet and Feather completion/rotation state. Already completed events will not be advanced twice.`)) return;
      button.disabled = true;
      const original = button.textContent;
      button.textContent = "Completing…";
      try {
        await Promise.resolve(syncQueue);
        const response = await fetch("/api/auction-auto-complete", {
          method: "POST",
          headers: { Authorization: `Bearer ${officerSession.access_token}` }
        });
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.message || body.error || "Auto-complete recovery failed");
        await loadRemoteState();
        selectedEventId = defaultSelectedEventId();
        render();
        toast(body.completed?.length ? `Recovered ${body.completed.length} overdue event${body.completed.length === 1 ? "" : "s"}` : "No overdue events needed recovery");
      } catch (error) {
        button.disabled = false;
        button.textContent = original;
        toast(error?.message || "Auto-complete recovery failed");
      }
    });
  }

  const previousRender = render;
  render = function auctionRecoveryAwareRender(...args) {
    const result = previousRender.apply(this, args);
    mountRecovery();
    return result;
  };
  queueMicrotask(mountRecovery);
})();