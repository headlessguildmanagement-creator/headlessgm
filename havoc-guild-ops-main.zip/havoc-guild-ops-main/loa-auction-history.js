(() => {
  const DEFAULT_DEADLINE = '19:30';

  function settings() {
    state.guildSettings ??= {};
    state.guildSettings.loaDeadlineTime ??= DEFAULT_DEADLINE;
    return state.guildSettings;
  }

  function deadlineFor(event) {
    const time = settings().loaDeadlineTime || DEFAULT_DEADLINE;
    return new Date(`${event.date}T${time}:00+08:00`);
  }

  // LOA is now controlled by an explicit guild deadline instead of call-time minus 6h.
  cutoff = deadlineFor;

  function countdownMarkup(event) {
    const target = deadlineFor(event);
    const closed = Date.now() >= target.getTime();
    return `<div class="card loa-countdown-card"><div class="section-head"><div><p class="eyebrow">LOA DEADLINE</p><h2 id="loa-countdown">${closed ? 'LOA filing closed' : 'Calculating…'}</h2><p id="loa-countdown-deadline">Closes ${target.toLocaleString('en-PH',{timeZone:PH_TIMEZONE,weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})} PHT</p></div><span class="pill ${closed?'red':'green'}" id="loa-countdown-status">${closed?'CLOSED':'OPEN'}</span></div></div>`;
  }

  function settingsMarkup() {
    if (accessMode !== 'commander') return '';
    return `<div class="card"><div class="section-head"><div><h2>LOA Settings</h2><p>Set the guild-wide filing deadline in Philippine time. This applies to every event.</p></div><span class="pill amber">OFFICER</span></div><form id="loa-settings-form" class="form-grid"><div class="field"><label>DEADLINE TIME (PHT)</label><input class="input" type="time" name="loaDeadlineTime" value="${esc(settings().loaDeadlineTime)}" required /></div><div class="field" style="align-self:end"><button class="button" type="submit">Save Deadline</button></div></form></div>`;
  }

  const baseLoa = renderLoa;
  renderLoa = function renderLoaWithCountdown() {
    const event = eventById(selectedEventId) || state.events[0];
    return `${countdownMarkup(event)}${baseLoa()}${settingsMarkup()}`;
  };

  function tick() {
    if (currentView !== 'loa') return;
    const event = eventById(selectedEventId) || state.events[0];
    if (!event) return;
    const remaining = deadlineFor(event).getTime() - Date.now();
    const label = document.querySelector('#loa-countdown');
    const pill = document.querySelector('#loa-countdown-status');
    if (!label || !pill) return;
    if (remaining <= 0) {
      label.textContent = 'LOA filing closed';
      pill.textContent = 'CLOSED';
      pill.className = 'pill red';
      return;
    }
    const total = Math.floor(remaining / 1000);
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const mins = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    label.textContent = `${days ? days + 'd ' : ''}${String(hours).padStart(2,'0')}h ${String(mins).padStart(2,'0')}m ${String(secs).padStart(2,'0')}s remaining`;
  }

  const baseBindLoa = bindLoa;
  bindLoa = function bindLoaWithSettings() {
    baseBindLoa();
    document.querySelector('#loa-settings-form')?.addEventListener('submit', event => {
      event.preventDefault();
      if (accessMode !== 'commander') return;
      const value = String(new FormData(event.currentTarget).get('loaDeadlineTime') || '');
      if (!/^([01]\\d|2[0-3]):[0-5]\\d$/.test(value)) return toast('Enter a valid LOA deadline');
      settings().loaDeadlineTime = value;
      save('LOA deadline saved');
      render();
    });
    tick();
  };

  setInterval(tick, 1000);
})();