(() => {
  const PAGE_SIZE = 4;
  const IMAGE_LIMIT = 5;
  const IMAGE_MAX_BYTES = 3 * 1024 * 1024;
  const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);

  let cache = { listings: [], offers: [], players: [], nextEvent: null, eligibility: { featherSellerIds: [], puppetSellerIds: [], featherBuyerIds: [], puppetBuyerIds: [], loaIds: [], penaltyIds: [] } };
  let loading = null;
  let section = "items";
  let itemFilter = "all";
  let rightFilter = "all";
  let itemPage = 1;
  let rightPage = 1;
  let hideCompletedItems = true;
  let hideCompletedRights = true;
  let itemSearch = "";
  let rightSearch = "";
  let cutoffCleanupTriggered = false;

  function money(value) {
    if (value == null || value === "") return "Negotiable";
    return `₱${Number(value).toLocaleString("en-PH", { maximumFractionDigits: 2 })}`;
  }

  function playerOptions(ids = null) {
    const allowed = ids ? new Set(ids) : null;
    return [...(cache.players || [])]
      .filter(row => !allowed || allowed.has(row.id))
      .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }))
      .map(row => `<option value="${esc(row.id)}">${esc(row.name)}${row.auctionGroup ? ` · Group ${row.auctionGroup}` : ""}</option>`).join("");
  }

  function offersFor(listingId) {
    return (cache.offers || []).filter(row => row.listing_id === listingId);
  }

  function activeOfferRows(listingId) {
    return offersFor(listingId).filter(row => row.status === "active");
  }

  function eventLabel() {
    const event = cache.nextEvent;
    if (!event) return "No upcoming guild event";
    return `${event.name} · ${formatDate(event.date)}`;
  }

  function statusLabel(listing) {
    if (listing.status === "listed") return '<span class="pill green">AVAILABLE</span>';
    if (listing.status === "sold") {
      const label = listing.right_type ? "SOLD" : listing.intent === "buy" ? "FOUND" : listing.intent === "trade" ? "TRADED" : "SOLD";
      return `<span class="pill amber">${label}</span>`;
    }
    if (listing.status === "completed") return '<span class="pill purple">COMPLETED</span>';
    if (listing.status === "expired") return '<span class="pill">EXPIRED</span>';
    return '<span class="pill">CANCELLED</span>';
  }

  function intentLabel(intent) {
    return String(intent || "sell").toUpperCase();
  }

  function cardTone(listing) {
    if (listing.right_type === "feather") return "market-card--feather";
    if (listing.right_type === "puppet") return "market-card--puppet";
    if (listing.intent === "buy") return "market-card--buy";
    if (listing.intent === "trade") return "market-card--trade";
    return "market-card--sell";
  }

  async function loadMarketplace(force = false) {
    if (loading && !force) return loading;
    loading = fetch("/api/state-store?resource=marketplace", { cache: "no-store" })
      .then(async response => {
        const body = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(body.error || "Marketplace could not be loaded");
        cache = body;
        window.__havocMarketplaceData = cache;
        return cache;
      })
      .finally(() => { loading = null; });
    return loading;
  }

  async function marketplaceAction(action, payload = {}, officer = false, reload = true) {
    const headers = { "Content-Type": "application/json" };
    if (officer && officerSession?.access_token) headers.Authorization = `Bearer ${officerSession.access_token}`;
    const response = await fetch("/api/state-store?resource=marketplace", {
      method: "POST",
      headers,
      body: JSON.stringify({ action, ...payload })
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || "Marketplace action failed");
    if (reload) await loadMarketplace(true);
    return body;
  }

  async function uploadListingImages(listingId, password, files) {
    const selected = [...(files || [])];
    if (!selected.length) return;
    if (selected.length > IMAGE_LIMIT) throw new Error("Maximum 5 photos per listing");
    if (!supabaseClient) throw new Error("Photo upload is still loading. Try again in a moment.");

    selected.forEach(file => {
      if (!IMAGE_TYPES.has(file.type)) throw new Error("Photos must be JPG, PNG, or WebP");
      if (file.size > IMAGE_MAX_BYTES) throw new Error(`${file.name} is larger than 3 MB`);
    });

    for (let position = 0; position < selected.length; position++) {
      const file = selected[position];
      const upload = await marketplaceAction("upload_image_url", {
        listingId,
        password,
        fileName: file.name,
        contentType: file.type,
        size: file.size,
        position
      }, false, false);

      const result = await supabaseClient.storage
        .from(upload.bucket || "marketplace-media")
        .uploadToSignedUrl(upload.path, upload.uploadToken, file, { contentType: file.type, upsert: false });
      if (result.error) throw result.error;

      await marketplaceAction("register_image", {
        listingId,
        password,
        path: upload.path,
        fileName: file.name,
        contentType: file.type,
        size: file.size,
        position
      }, false, false);
    }
  }

  function activeSoldDeal(rightType, ownerId, eventId = null) {
    return (cache.listings || []).find(row =>
      row.right_type === rightType &&
      row.status === "sold" &&
      row.seller_player_id === ownerId &&
      (rightType !== "feather" || !eventId || row.origin_event_id === eventId)
    ) || null;
  }

  window.havocMarketplacePuppetDeal = ownerId => activeSoldDeal("puppet", ownerId);
  window.havocMarketplaceFeatherDeal = (eventId, ownerId) => activeSoldDeal("feather", ownerId, eventId);
  window.havocLoadMarketplace = loadMarketplace;
  window.havocMarketplaceReady = () => loadMarketplace();

  window.havocSnapshotAuctionHistory = event => {
    const assignments = event?.auction?.assignments || [];
    if (!event?.id || !assignments.length) return false;
    state.auctionHistory ??= [];
    if (state.auctionHistory.some(row => row.eventId === event.id)) return false;

    const playerName = id => player(id)?.name || id;
    const unique = values => [...new Set(values.filter(Boolean))];
    const feather = unique(assignments
      .filter(item => item.tab === "Feather" || item.category === "Light/Dark" || item.category === "Time/Space")
      .map(item => playerName(item.playerId)));
    const puppet = unique(assignments
      .filter(item => item.tab === "Cards" || item.category === "Puppet Fragment")
      .map(item => playerName(item.playerId)));
    const regularGroup = new Set((state.players || [])
      .filter(member => member.active !== false && Number(member.auctionGroup) === Number(event.activeGroup))
      .map(member => member.id));
    const excessOfficerBidders = unique(assignments
      .filter(item => {
        if (!(item.tab === "Feather" || item.category === "Light/Dark" || item.category === "Time/Space")) return false;
        const ownerId = item.marketplaceOriginalPlayerId || item.playerId;
        return !regularGroup.has(ownerId) && Boolean(player(ownerId)?.isOfficer);
      })
      .map(item => playerName(item.marketplaceOriginalPlayerId || item.playerId)));

    const marketplaceDeals = [];
    const seenDeals = new Set();
    for (const item of assignments.filter(row => row.marketplaceListingId && row.marketplaceOriginalPlayerId)) {
      if (seenDeals.has(item.marketplaceListingId)) continue;
      seenDeals.add(item.marketplaceListingId);
      marketplaceDeals.push({
        listingId: item.marketplaceListingId,
        rightType: item.marketplaceRightType || (item.category === "Puppet Fragment" ? "puppet" : "feather"),
        category: item.category,
        originalPlayerId: item.marketplaceOriginalPlayerId,
        originalPlayerName: playerName(item.marketplaceOriginalPlayerId),
        bidderPlayerId: item.playerId,
        bidderPlayerName: playerName(item.playerId),
        source: "Marketplace · SOLD"
      });
    }

    state.auctionHistory.push({
      eventId: event.id,
      date: event.date,
      eventName: event.name,
      eventType: event.type,
      group: event.activeGroup,
      featherBidders: feather,
      puppetBidders: puppet,
      excessOfficerBidders,
      marketplaceDeals,
      recordedAt: new Date().toISOString()
    });
    return true;
  };

  function marketplaceHero() {
    return `<div class="card marketplace-hero">
      <div class="section-head">
        <div><p class="eyebrow">HAVOC MARKETPLACE</p><h2>Guild Marketplace</h2><p>Buy, sell, trade, or manage event bidding rights without digging through one giant form.</p></div>
        <span class="pill purple">MEMBERS + OFFICERS</span>
      </div>
      <div class="marketplace-sections" role="tablist" aria-label="Marketplace sections">
        <button type="button" class="${section === "items" ? "active" : ""}" data-market-section="items">ITEMS</button>
        <button type="button" class="${section === "rights" ? "active" : ""}" data-market-section="rights">BIDDING RIGHTS</button>
      </div>
    </div>`;
  }

  function normalForm() {
    const categories = ["MVP Card", "Accessory", "Costume", "Account"];
    return `<details class="card marketplace-post" id="market-item-post">
      <summary><span><strong>+ POST LISTING</strong><small> SELL · BUY · TRADE</small></span><span class="dropdown-arrow">⌄</span></summary>
      <form id="market-normal-form" class="form-grid marketplace-post-form">
        <div class="field"><label>TYPE</label><select name="intent"><option value="sell">SELL</option><option value="buy">BUY</option><option value="trade">TRADE</option></select></div>
        <div class="field"><label>CATEGORY</label><select name="category" id="market-item-category">${categories.map(x => `<option>${x}</option>`).join("")}</select></div>
        <div class="field"><label>IGN</label><select name="sellerPlayerId" required><option value="">Select IGN</option>${playerOptions()}</select></div>
        <div class="field"><label id="market-item-title-label">ITEM NAME</label><input class="input" id="market-item-title" name="title" maxlength="120" placeholder="What are you listing?" required/></div>
        <div class="field"><label>PRICE / OFFER (PHP)</label><input class="input" type="number" name="price" min="0" step="1" placeholder="Optional"/></div>
        <div class="field"><label>LISTING KEY</label><input class="input marketplace-secret-input" type="text" name="listingKey" minlength="4" maxlength="128" autocomplete="off" autocapitalize="none" spellcheck="false" data-lpignore="true" data-1p-ignore="true" required/><small>Keep this private. Buyers never need it.</small></div>
        <div class="field full">
          <label>PHOTOS</label>
          <input class="input marketplace-file-input" id="market-photos" type="file" name="photos" accept="image/jpeg,image/png,image/webp" multiple/>
          <small>Optional but recommended for proof. Up to 5 photos · JPG/PNG/WebP · 3 MB each.</small>
          <div class="marketplace-photo-preview" id="market-photo-preview"></div>
        </div>
        <div class="field full"><label>DETAILS</label><textarea class="input" name="description" rows="3" maxlength="1000" placeholder="Condition, refine, important stats, trade terms, or anything the buyer should know."></textarea></div>
        <div class="full marketplace-form-actions"><button type="submit" class="button">Post listing</button></div>
      </form>
    </details>`;
  }

  function rightSummary() {
    const event = cache.nextEvent;
    const open = Boolean(event?.rightWindowOpen);
    const featherCount = cache.eligibility?.featherSellerIds?.length || 0;
    const puppetCount = cache.eligibility?.puppetSellerIds?.length || 0;
    return `<div class="card marketplace-rights-head">
      <div class="section-head">
        <div><p class="eyebrow">NEXT EVENT</p><h2>${esc(eventLabel())}</h2><p>Feather Group ${event?.activeGroup ?? "—"} · Puppet seller window follows the upcoming rotation.</p></div>
        <span class="pill ${open ? "green" : "red"}">${open ? "TRADING OPEN" : "TRADING LOCKED"}</span>
      </div>
      <div class="marketplace-rule-grid">
        <div><strong>Feather</strong><span>Group ${event?.activeGroup ?? "—"}</span><small>${featherCount} eligible sellers</small></div>
        <div><strong>Puppet</strong><span>Current seller window</span><small>Up to ${puppetCount} eligible natural turns</small></div>
        <div><strong>Cutoff</strong><span id="marketplace-countdown">${open ? "Calculating…" : "Locked until after event day"}</span><small>Rights close at 8:30 PM PHT. Unconfirmed listings expire after cutoff.</small></div>
      </div>
      <div class="notice warning"><strong>Payment is private.</strong> HAVOC does not verify payments or settle buyer/seller disputes. Never give your listing key to a buyer.</div>
    </div>`;
  }

  function rightActorIds(intent, rightType) {
    const key = `${rightType}${intent === "buy" ? "Buyer" : "Seller"}Ids`;
    return cache.eligibility?.[key] || [];
  }

  function rightForm() {
    const event = cache.nextEvent;
    if (!event?.rightWindowOpen) return `<div class="card empty-state">Feather and Puppet bidding-right trading is locked for the current event window.</div>`;
    return `<details class="card marketplace-post" id="market-right-post">
      <summary><span><strong>+ POST BIDDING RIGHT</strong><small> SELL or BUY · Feather or Puppet</small></span><span class="dropdown-arrow">⌄</span></summary>
      <form id="market-right-form" class="form-grid marketplace-post-form">
        <div class="field"><label>TYPE</label><select name="intent" id="market-right-intent"><option value="sell">SELL</option><option value="buy">BUY</option></select></div>
        <div class="field"><label>RIGHT TYPE</label><select name="rightType" id="market-right-type"><option value="feather">Feather</option><option value="puppet">Puppet</option></select></div>
        <div class="field"><label id="market-right-actor-label">SELLER IGN</label><select name="sellerPlayerId" id="market-right-actor" required><option value="">Select eligible seller</option>${playerOptions(rightActorIds("sell", "feather"))}</select></div>
        <div class="field"><label id="market-right-price-label">SELLING PRICE (PHP)</label><input class="input" type="number" name="price" min="1" step="1" required/></div>
        <div class="field"><label>LISTING KEY</label><input class="input marketplace-secret-input" type="text" name="listingKey" minlength="4" maxlength="128" autocomplete="off" autocapitalize="none" spellcheck="false" data-lpignore="true" data-1p-ignore="true" required/><small>Required to accept an offer or cancel. Do not share it.</small></div>
        <div class="field full"><label>NOTE (OPTIONAL)</label><textarea class="input" name="description" rows="2" maxlength="1000" placeholder="Optional deal notes"></textarea></div>
        <div class="full marketplace-form-actions"><button type="submit" class="button" id="market-right-submit">List bidding right</button></div>
      </form>
      <p class="muted marketplace-identity-note">BUY means you are looking for a slot. Only members currently eligible to SELL that Feather or Puppet right can answer your request. Feather buyers and sellers from the same permanent Feather Group cannot transact.</p>
      <template id="market-feather-sell-options"><option value="">Select eligible seller</option>${playerOptions(rightActorIds("sell", "feather"))}</template>
      <template id="market-puppet-sell-options"><option value="">Select eligible seller</option>${playerOptions(rightActorIds("sell", "puppet"))}</template>
      <template id="market-feather-buy-options"><option value="">Select eligible buyer</option>${playerOptions(rightActorIds("buy", "feather"))}</template>
      <template id="market-puppet-buy-options"><option value="">Select eligible buyer</option>${playerOptions(rightActorIds("buy", "puppet"))}</template>
    </details>`;
  }

  function offerForm(listing) {
    if (listing.status !== "listed") return "";
    const right = Boolean(listing.right_type);
    const isBuyRequest = right && listing.intent === "buy";
    const ids = right ? rightActorIds(isBuyRequest ? "sell" : "buy", listing.right_type) : null;
    return `<form class="market-offer-form" data-listing="${listing.id}">
      <select name="buyerPlayerId" required><option value="">${isBuyRequest ? "Seller IGN" : right ? "Buyer IGN" : "Your IGN"}</option>${playerOptions(ids)}</select>
      <input class="input" type="number" name="amount" min="1" step="1" placeholder="${isBuyRequest ? "Counter ₱" : "Offer ₱"}" required/>
      <input class="input" name="note" maxlength="500" placeholder="Note (optional)"/>
      <button type="submit" class="button small">${isBuyRequest ? "Send counter offer" : "Send offer"}</button>
    </form>`;
  }

  function offerList(listing) {
    const rows = offersFor(listing.id).filter(row => ["active", "accepted"].includes(row.status));
    if (!rows.length) return '<div class="muted marketplace-no-offers">No offers yet.</div>';
    const role = listing.right_type && listing.intent === "buy" ? "SELLER" : "BUYER";
    return `<div class="marketplace-offers">${rows.map(row => `<div class="marketplace-offer">
      <div><small>${role}</small><strong>${esc(row.buyer_ign)}</strong><span>${money(row.amount)}</span>${row.note ? `<small>${esc(row.note)}</small>` : ""}</div>
      <span class="pill ${row.status === "accepted" ? "green" : "amber"}">${row.status.toUpperCase()}</span>
      ${listing.status === "listed" && row.status === "active" ? `<button type="button" class="button small market-accept-offer" data-listing="${listing.id}" data-offer="${row.id}">Accept</button>` : ""}
    </div>`).join("")}</div>`;
  }

  function officerTools(listing) {
    if (accessMode !== "commander" || (listing.right_type && listing.status === "sold")) return "";
    return `<div class="marketplace-officer-tools">
      <button type="button" class="button ghost small market-officer-remove" data-listing="${listing.id}">Remove listing</button>
    </div>`;
  }

  function listingMedia(listing) {
    if (listing.right_type) return "";
    const images = (listing.images || []).filter(row => row.url);
    if (!images.length) {
      return `<div class="marketplace-cover marketplace-cover--empty"><span>${esc(listing.category)}</span><small>No photo uploaded</small></div>`;
    }
    return `<button class="marketplace-cover market-gallery-open" type="button" data-listing="${listing.id}" aria-label="View listing photos">
      <img src="${esc(images[0].url)}" alt="${esc(listing.title)}"/>
      ${images.length > 1 ? `<span class="marketplace-photo-count">+${images.length - 1}</span>` : ""}
    </button>`;
  }

  function listingCard(listing) {
    const right = Boolean(listing.right_type);
    const soldLine = right && listing.status === "sold"
      ? `<div class="marketplace-sale-link"><strong>${esc(listing.seller_ign)}</strong><span>→</span><strong>${esc(listing.buyer_ign || "Buyer")}</strong><span class="pill amber">SOLD</span></div>`
      : "";
    const label = right ? `${intentLabel(listing.intent)} · ${listing.right_type === "feather" ? "FEATHER" : "PUPPET"} BIDDING RIGHT` : `${intentLabel(listing.intent)} · ${esc(listing.category)}`;
    const event = right ? `<small>${listing.origin_event_date ? formatDate(listing.origin_event_date) : ""}${listing.origin_group ? ` · Feather Group ${listing.origin_group}` : listing.right_type === "puppet" ? " · Carries until the seller's turn is selected" : ""}</small>` : "";
    const postedBy = listing.created_by_ign || listing.seller_ign;
    return `<article class="card marketplace-listing ${cardTone(listing)}">
      ${listingMedia(listing)}
      <div class="marketplace-card-body">
        <div class="section-head marketplace-card-head">
          <div><p class="eyebrow">${label}</p><h3>${esc(listing.title)}</h3><p>Posted by <strong>${esc(postedBy)}</strong></p>${event}</div>
          <div class="marketplace-listing-status">${statusLabel(listing)}<strong>${money(listing.price)}</strong></div>
        </div>
        ${soldLine}
        ${listing.description ? `<p class="marketplace-description">${esc(listing.description)}</p>` : ""}
        ${offerForm(listing)}
        <details class="marketplace-offers-box" ${activeOfferRows(listing.id).length ? "open" : ""}><summary>Offers · ${activeOfferRows(listing.id).length}</summary>${offerList(listing)}</details>
        <div class="marketplace-manage">
          ${listing.status === "listed" ? `<input class="input market-listing-password marketplace-secret-input" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" data-lpignore="true" data-1p-ignore="true" placeholder="Listing key"/><button type="button" class="button ghost small market-cancel-listing" data-listing="${listing.id}">Cancel listing</button>` : ""}
          ${!right && listing.status === "listed" ? `<button type="button" class="button small market-normal-status" data-listing="${listing.id}" data-status="sold">Mark ${listing.intent === "buy" ? "Found" : listing.intent === "trade" ? "Traded" : "Sold"}</button>` : ""}
          ${!right && listing.status === "sold" ? `<input class="input market-listing-password marketplace-secret-input" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" data-lpignore="true" data-1p-ignore="true" placeholder="Listing key"/><button type="button" class="button small market-normal-status" data-listing="${listing.id}" data-status="listed">Make available again</button>` : ""}
          ${officerTools(listing)}
        </div>
        ${right && listing.status === "sold" ? '<div class="notice marketplace-final-note"><strong>Final deal.</strong> The seller is only consumed when this right is actually used and completed.</div>' : ""}
      </div>
    </article>`;
  }

  function marketplaceSearchText(row) {
    const playerName = id => (cache.players || []).find(player => player.id === id)?.name || "";
    const offers = offersFor(row.id);
    return [
      row.title,
      row.category,
      row.description,
      row.intent,
      row.right_type,
      row.seller_ign,
      row.created_by_ign,
      row.price,
      row.price_text,
      row.status,
      row.origin_event_id,
      row.origin_event_date,
      row.origin_group,
      playerName(row.seller_player_id),
      playerName(row.created_by_player_id),
      playerName(row.buyer_player_id),
      ...offers.flatMap(offer => [
        offer.buyer_ign,
        offer.amount,
        offer.note,
        offer.status,
        playerName(offer.buyer_player_id)
      ])
    ].filter(value => value !== null && value !== undefined).join(" ").toLowerCase();
  }

  function matchesMarketplaceSearch(row, query) {
    const needle = String(query || "").trim().toLowerCase();
    return !needle || marketplaceSearchText(row).includes(needle);
  }

  function itemsRows() {
    return (cache.listings || []).filter(row => {
      if (row.right_type || ["cancelled", "expired"].includes(row.status)) return false;
      if (hideCompletedItems && row.status === "sold") return false;
      if (itemFilter !== "all" && row.intent !== itemFilter) return false;
      return matchesMarketplaceSearch(row, itemSearch);
    });
  }

  function rightsRows() {
    return (cache.listings || []).filter(row => {
      if (!row.right_type || ["cancelled", "expired"].includes(row.status)) return false;
      // SOLD bidding rights are still pending/current until their auction consequence completes.
      if (hideCompletedRights && row.status === "completed") return false;
      if (rightFilter !== "all" && row.right_type !== rightFilter) return false;
      return matchesMarketplaceSearch(row, rightSearch);
    });
  }

  function paginate(rows, page) {
    const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
    const current = Math.min(Math.max(1, page), pages);
    const start = (current - 1) * PAGE_SIZE;
    return { rows: rows.slice(start, start + PAGE_SIZE), pages, current };
  }

  function pagination(pages, current, target) {
    if (pages <= 1) return "";
    const start = Math.max(1, Math.min(current - 2, Math.max(1, pages - 4)));
    const end = Math.min(pages, start + 4);
    const nums = [];
    for (let i = start; i <= end; i++) nums.push(i);
    return `<nav class="marketplace-pagination" aria-label="Marketplace pages">
      <button type="button" class="button ghost small" data-market-page="${Math.max(1, current - 1)}" data-market-page-target="${target}" ${current === 1 ? "disabled" : ""}>← Previous</button>
      <div>${nums.map(i => `<button type="button" class="${i === current ? "active" : ""}" data-market-page="${i}" data-market-page-target="${target}">${i}</button>`).join("")}</div>
      <button type="button" class="button ghost small" data-market-page="${Math.min(pages, current + 1)}" data-market-page-target="${target}" ${current === pages ? "disabled" : ""}>Next →</button>
    </nav>`;
  }

  function searchBox(type, resultCount) {
    const query = type === "items" ? itemSearch : rightSearch;
    const placeholder = type === "items"
      ? "Search item name, price, seller IGN, offers or notes"
      : "Search Feather, Puppet, BUY, SELL, IGN, price, event or offers";
    return `<div class="card marketplace-search">
      <label for="marketplace-search-${type}">SEARCH ${type === "items" ? "LISTINGS" : "BIDDING RIGHTS"}</label>
      <div class="marketplace-search-field">
        <input class="input" id="marketplace-search-${type}" data-market-search="${type}" type="search" autocomplete="off" value="${esc(query)}" placeholder="${placeholder}"/>
        ${query ? `<button type="button" data-market-search-clear="${type}">Clear</button>` : ""}
      </div>
      <small>${query ? `${resultCount} result${resultCount === 1 ? "" : "s"} found` : "Search by listing details, IGN, price, or offers."}</small>
    </div>`;
  }

  function filterTabs(type) {
    const options = type === "items"
      ? [["all", "ALL"], ["sell", "SELL"], ["buy", "BUY"], ["trade", "TRADE"]]
      : [["all", "ALL"], ["feather", "FEATHER"], ["puppet", "PUPPET"]];
    const selected = type === "items" ? itemFilter : rightFilter;
    const hidden = type === "items" ? hideCompletedItems : hideCompletedRights;
    return `<div class="card marketplace-tabs">
      <div class="marketplace-filter-buttons">${options.map(([value, label]) => `<button type="button" class="${selected === value ? "active" : ""}" data-market-filter="${value}" data-market-filter-target="${type}">${label}</button>`).join("")}</div>
      <label class="marketplace-completed-toggle">
        <input type="checkbox" data-market-hide-completed="${type}" ${hidden ? "checked" : ""}/>
        <span>Hide completed</span>
      </label>
    </div>`;
  }

  function itemsView() {
    const rows = itemsRows();
    const page = paginate(rows, itemPage);
    itemPage = page.current;
    return `${normalForm()}
      ${searchBox("items", rows.length)}
      ${filterTabs("items")}
      <div class="marketplace-grid">${page.rows.length ? page.rows.map(listingCard).join("") : '<div class="card empty-state marketplace-empty-wide">No item listings match your search or filters.</div>'}</div>
      ${pagination(page.pages, page.current, "items")}`;
  }

  function rightsView() {
    const rows = rightsRows();
    const page = paginate(rows, rightPage);
    rightPage = page.current;
    return `${rightSummary()}
      ${rightForm()}
      ${searchBox("rights", rows.length)}
      ${filterTabs("rights")}
      <div class="marketplace-grid">${page.rows.length ? page.rows.map(listingCard).join("") : '<div class="card empty-state marketplace-empty-wide">No bidding-right listings match your search or filters.</div>'}</div>
      ${pagination(page.pages, page.current, "rights")}`;
  }

  window.renderMarketplacePage = function renderMarketplacePage() {
    if (!window.__havocMarketplaceData && !loading) {
      loadMarketplace().then(() => { if (currentView === "marketplace") render(); }).catch(error => toast(error.message));
    }
    return `<div class="marketplace-page">${marketplaceHero()}${section === "items" ? itemsView() : rightsView()}</div>`;
  };

  function listingPassword(button) {
    return button.closest(".marketplace-listing")?.querySelector(".market-listing-password")?.value || "";
  }

  function updateItemTitleLabel() {
    const category = document.querySelector("#market-item-category");
    const label = document.querySelector("#market-item-title-label");
    const input = document.querySelector("#market-item-title");
    if (!category || !label || !input) return;
    const isAccount = category.value === "Account";
    label.textContent = isAccount ? "ACCOUNT TITLE" : "ITEM NAME";
    input.placeholder = isAccount ? "e.g. Creator account · 2 MVP cards" : "What item are you listing?";
  }

  function previewSelectedPhotos(input) {
    const preview = document.querySelector("#market-photo-preview");
    if (!preview) return;
    const files = [...(input.files || [])];
    if (files.length > IMAGE_LIMIT) {
      input.value = "";
      preview.innerHTML = "";
      toast("Maximum 5 photos per listing");
      return;
    }
    const invalid = files.find(file => !IMAGE_TYPES.has(file.type) || file.size > IMAGE_MAX_BYTES);
    if (invalid) {
      input.value = "";
      preview.innerHTML = "";
      toast(!IMAGE_TYPES.has(invalid.type) ? "Photos must be JPG, PNG, or WebP" : `${invalid.name} is larger than 3 MB`);
      return;
    }
    preview.innerHTML = files.map(file => `<div><img src="${URL.createObjectURL(file)}" alt="Selected listing photo"/><small>${esc(file.name)}</small></div>`).join("");
  }

  function openGallery(listingId) {
    const listing = (cache.listings || []).find(row => row.id === listingId);
    const images = (listing?.images || []).filter(row => row.url);
    if (!listing || !images.length) return;
    const overlay = document.createElement("div");
    overlay.className = "marketplace-gallery-overlay";
    overlay.innerHTML = `<button type="button" class="marketplace-gallery-backdrop" aria-label="Close photo gallery"></button>
      <section class="marketplace-gallery-panel" role="dialog" aria-modal="true" aria-label="${esc(listing.title)} photos">
        <div class="marketplace-gallery-head"><div><p class="eyebrow">${esc(listing.category)}</p><h2>${esc(listing.title)}</h2></div><button type="button" class="button ghost small marketplace-gallery-close">Close</button></div>
        <div class="marketplace-gallery-grid">${images.map((image, index) => `<img src="${esc(image.url)}" alt="${esc(listing.title)} photo ${index + 1}"/>`).join("")}</div>
      </section>`;
    const close = () => overlay.remove();
    overlay.querySelector(".marketplace-gallery-backdrop")?.addEventListener("click", close);
    overlay.querySelector(".marketplace-gallery-close")?.addEventListener("click", close);
    document.body.appendChild(overlay);
  }

  document.addEventListener("submit", async event => {
    const form = event.target;
    if (!["market-normal-form", "market-right-form"].includes(form.id) && !form.classList.contains("market-offer-form")) return;
    event.preventDefault();
    event.stopPropagation();
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    const button = form.querySelector('button[type="submit"],button:not([type])');
    if (button) button.disabled = true;
    try {
      const data = Object.fromEntries(new FormData(form).entries());
      let result;
      if (form.id === "market-normal-form") {
        const password = data.listingKey;
        data.password = password;
        delete data.listingKey;
        const photos = [...(form.querySelector("#market-photos")?.files || [])];
        delete data.photos;
        result = await marketplaceAction("create_listing", data, false, false);
        try {
          await uploadListingImages(result.listing.id, password, photos);
        } catch (uploadError) {
          await loadMarketplace(true);
          toast(`Listing posted, but photo upload stopped: ${uploadError.message}`);
          render();
          return;
        }
        await loadMarketplace(true);
        toast(photos.length ? `Listing posted with ${photos.length} photo${photos.length === 1 ? "" : "s"}` : "Marketplace listing posted");
        itemPage = 1;
      } else if (form.id === "market-right-form") {
        data.password = data.listingKey;
        delete data.listingKey;
        result = await marketplaceAction("create_listing", data);
        toast(result.message || "Bidding-right listing posted");
        rightPage = 1;
      } else {
        result = await marketplaceAction("make_offer", { listingId: form.dataset.listing, ...data });
        toast(result.message || "Offer sent");
      }
      render();
      requestAnimationFrame(() => window.scrollTo(scrollX, scrollY));
    } catch (error) {
      toast(error.message || "Marketplace action failed");
    } finally {
      if (button?.isConnected) button.disabled = false;
    }
  });

  function updateRightFormOptions() {
    const intent = document.querySelector("#market-right-intent")?.value || "sell";
    const rightType = document.querySelector("#market-right-type")?.value || "feather";
    const source = document.querySelector(`#market-${rightType}-${intent}-options`);
    const target = document.querySelector("#market-right-actor");
    if (source && target) target.innerHTML = source.innerHTML;
    const actorLabel = document.querySelector("#market-right-actor-label");
    const priceLabel = document.querySelector("#market-right-price-label");
    const submit = document.querySelector("#market-right-submit");
    if (actorLabel) actorLabel.textContent = intent === "buy" ? "BUYER IGN" : "SELLER IGN";
    if (priceLabel) priceLabel.textContent = intent === "buy" ? "BUYING OFFER (PHP)" : "SELLING PRICE (PHP)";
    if (submit) submit.textContent = intent === "buy" ? "Post buy request" : "List bidding right";
  }

  document.addEventListener("input", event => {
    const type = event.target?.dataset?.marketSearch;
    if (!["items", "rights"].includes(type)) return;
    const value = event.target.value;
    if (type === "items") {
      itemSearch = value;
      itemPage = 1;
    } else {
      rightSearch = value;
      rightPage = 1;
    }
    const cursor = event.target.selectionStart ?? value.length;
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    render();
    requestAnimationFrame(() => {
      const input = document.querySelector(`[data-market-search="${type}"]`);
      if (!input) return;
      try {
        input.focus({ preventScroll: true });
      } catch {
        input.focus();
      }
      input.setSelectionRange(Math.min(cursor, input.value.length), Math.min(cursor, input.value.length));
      window.scrollTo(scrollX, scrollY);
    });
  });

  document.addEventListener("change", event => {
    const completedToggle = event.target.closest?.("[data-market-hide-completed]");
    if (completedToggle) {
      event.stopPropagation();
      const target = completedToggle.dataset.marketHideCompleted;
      if (target === "items") {
        hideCompletedItems = Boolean(completedToggle.checked);
        itemPage = 1;
      } else if (target === "rights") {
        hideCompletedRights = Boolean(completedToggle.checked);
        rightPage = 1;
      }
      render();
      return;
    }

    if (["market-right-type", "market-right-intent"].includes(event.target?.id)) {
      updateRightFormOptions();
      return;
    }
    if (event.target?.id === "market-item-category") {
      updateItemTitleLabel();
      return;
    }
    if (event.target?.id === "market-photos") {
      previewSelectedPhotos(event.target);
    }
  });

  document.addEventListener("click", async event => {
    const searchClear = event.target.closest?.("[data-market-search-clear]");
    if (searchClear) {
      const type = searchClear.dataset.marketSearchClear;
      if (type === "items") {
        itemSearch = "";
        itemPage = 1;
      } else {
        rightSearch = "";
        rightPage = 1;
      }
      const scrollX = window.scrollX;
      const scrollY = window.scrollY;
      render();
      requestAnimationFrame(() => {
        const input = document.querySelector(`[data-market-search="${type}"]`);
        if (input) {
          try {
            input.focus({ preventScroll: true });
          } catch {
            input.focus();
          }
        }
        window.scrollTo(scrollX, scrollY);
      });
      return;
    }

    const sectionButton = event.target.closest?.("[data-market-section]");
    if (sectionButton) {
      section = sectionButton.dataset.marketSection;
      render();
      return;
    }

    const filter = event.target.closest?.("[data-market-filter]");
    if (filter) {
      if (filter.dataset.marketFilterTarget === "items") {
        itemFilter = filter.dataset.marketFilter;
        itemPage = 1;
      } else {
        rightFilter = filter.dataset.marketFilter;
        rightPage = 1;
      }
      render();
      return;
    }

    const pageButton = event.target.closest?.("[data-market-page]");
    if (pageButton && !pageButton.disabled) {
      const page = Number(pageButton.dataset.marketPage) || 1;
      if (pageButton.dataset.marketPageTarget === "items") itemPage = page;
      else rightPage = page;
      render();
      document.querySelector(".marketplace-grid")?.scrollIntoView({ behavior: "smooth", block: "start" });
      return;
    }

    const gallery = event.target.closest?.(".market-gallery-open");
    if (gallery) {
      openGallery(gallery.dataset.listing);
      return;
    }

    const accept = event.target.closest?.(".market-accept-offer");
    const cancel = event.target.closest?.(".market-cancel-listing");
    const normal = event.target.closest?.(".market-normal-status");
    const remove = event.target.closest?.(".market-officer-remove");
    if (!accept && !cancel && !normal && !remove) return;

    event.preventDefault();
    event.stopPropagation();
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    const button = accept || cancel || normal || remove;
    button.disabled = true;
    try {
      if (accept) {
        const password = listingPassword(accept);
        if (!password) throw new Error("Enter the listing key before accepting an offer");
        if (!confirm("Confirm this offer? For bidding rights, SOLD is final and cannot be reverted.")) return;
        const result = await marketplaceAction("accept_offer", { listingId: accept.dataset.listing, offerId: accept.dataset.offer, password });
        toast(result.message || "Offer accepted");
      } else if (cancel) {
        const password = listingPassword(cancel);
        if (!password) throw new Error("Enter the listing key");
        if (!confirm("Cancel this listing? You can list again while the window is open.")) return;
        const result = await marketplaceAction("cancel_listing", { listingId: cancel.dataset.listing, password });
        toast(result.message || "Listing cancelled");
      } else if (normal) {
        const password = listingPassword(normal);
        if (!password) throw new Error("Enter the listing key");
        const result = await marketplaceAction("set_normal_status", { listingId: normal.dataset.listing, status: normal.dataset.status, password });
        toast(result.message || "Listing updated");
      } else if (remove) {
        if (!confirm("Remove this listing entirely? The listing owner will need to post a new listing.")) return;
        const result = await marketplaceAction("officer_remove", { listingId: remove.dataset.listing }, true);
        toast(result.message || "Listing removed. Ask the listing owner to post it again.");
      }
      render();
      requestAnimationFrame(() => window.scrollTo(scrollX, scrollY));
    } catch (error) {
      toast(error.message || "Marketplace action failed");
    } finally {
      if (button?.isConnected) button.disabled = false;
    }
  });

  function tick() {
    if (currentView !== "marketplace" || section !== "rights") return;
    const target = document.querySelector("#marketplace-countdown");
    const event = cache.nextEvent;
    if (!target || !event) return;
    const ms = new Date(event.lockAt).getTime() - Date.now();
    if (ms <= 0) {
      target.textContent = "Bidding-right trading locked";
      if (!cutoffCleanupTriggered && Date.now() >= new Date(event.lockAt).getTime() + 60_000) {
        cutoffCleanupTriggered = true;
        loadMarketplace(true).then(() => { if (currentView === "marketplace") render(); }).catch(() => {});
      }
      return;
    }
    const seconds = Math.floor(ms / 1000);
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    target.textContent = `${days ? days + "d " : ""}${String(hours).padStart(2, "0")}h ${String(mins).padStart(2, "0")}m ${String(secs).padStart(2, "0")}s`;
  }

  setInterval(tick, 1000);
  loadMarketplace().then(() => {
    if (currentView === "marketplace") render();
  }).catch(error => console.error("Marketplace preload failed", error));
})();