(() => {
  const WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

  function cycleDeadline(cycle) {
    if (Number(cycle) === Number(state.puppetCycle || 1)) return null;
    const history = (state.puppetCycleHistory || []).find(row => Number(row.cycle) === Number(cycle));
    if (!history?.completedAt) return null;
    return history.appealOpenUntil || new Date(new Date(history.completedAt).getTime() + WINDOW_MS).toISOString();
  }

  function windowOpen(cycle) {
    if (Number(cycle) === Number(state.puppetCycle || 1)) return true;
    const deadline = cycleDeadline(cycle);
    return Boolean(deadline && Date.now() <= new Date(deadline).getTime());
  }

  function assignmentCycle(playerId, event, assignment) {
    if (Number.isFinite(Number(assignment?.puppetSourceCycle))) return Number(assignment.puppetSourceCycle);
    const closing = [...(state.puppetCycleHistory || [])].reverse().find(row => row.completedThroughEvent === event.id);
    if (closing) return Number(closing.cycle) + (Number(assignment.puppetCycleOffset || 0) > 0 ? 1 : 0);
    const history = [...(state.puppetCycleHistory || [])].reverse()
      .find(row => (row.members || []).some(member => member.playerId === playerId && member.completedAt === event.date));
    return history ? Number(history.cycle) : Number(state.puppetCycle || 1);
  }

  function appealableTurns(playerId) {
    const now = new Date();
    const rows = [];
    for (const event of state.events || []) {
      if (new Date(`${event.date}T${event.callTime || '20:30'}:00+08:00`) >= now) continue;
      const assignment = (event.auction?.assignments || []).find(item => item.category === 'Puppet Fragment' && item.playerId === playerId);
      if (assignment) {
        const cycle = assignmentCycle(playerId, event, assignment);
        if (windowOpen(cycle)) rows.push({ event, assignment, cycle });
      }
    }

    const current = (state.players || []).find(row => row.id === playerId && row.active !== false);
    if (current?.puppetComplete && current.puppetCompletedAt && !rows.some(row => row.event.date === current.puppetCompletedAt)) {
      const event = (state.events || []).find(row => row.date === current.puppetCompletedAt);
      if (event) rows.push({ event, assignment: null, cycle: Number(state.puppetCycle || 1) });
    }

    for (const history of state.puppetCycleHistory || []) {
      if (!windowOpen(history.cycle)) continue;
      const member = (history.members || []).find(row => row.playerId === playerId && row.completedAt);
      if (!member) continue;
      if (rows.some(row => row.cycle === Number(history.cycle) && row.event.date === member.completedAt)) continue;
      const event = (state.events || []).find(row => row.date === member.completedAt);
      if (event) rows.push({ event, assignment: null, cycle: Number(history.cycle) });
    }
    return rows.sort((a, b) => b.event.date.localeCompare(a.event.date));
  }

  document.addEventListener('change', event => {
    if (event.target?.id !== 'puppet-appeal-player') return;
    const playerId = event.target.value;
    if (!playerId) return;
    const rows = appealableTurns(playerId);
    if (!rows.length) return;
    event.stopImmediatePropagation();
    const select = document.querySelector('#puppet-appeal-event');
    if (!select) return;
    select.disabled = false;
    select.innerHTML = `<option value="">Select the turn you did not receive</option>${rows.map(({event,assignment,cycle}) => `<option value="${event.id}">${formatDate(event.date)} · ${esc(event.name)} · Cycle ${cycle} · ${assignment ? `Page ${assignment.page} Item ${assignment.item}` : 'Recorded completion (Page / Item unavailable)'}</option>`).join('')}`;
  }, true);

  document.addEventListener('click', event => {
    const button = event.target.closest?.('.puppet-complete');
    if (!button) return;
    const member = player(button.dataset.player);
    if (!member) return;
    const appeal = (state.puppetAppealQueue || []).find(row => row.playerId === member.id && !row.consumedAt && windowOpen(row.sourceCycle));
    if (!appeal) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (!confirm(`Mark ${member.name}'s approved Puppet make-up as DONE?`)) return;
    appeal.consumedAt = new Date().toISOString();
    appeal.consumedEventId = (eventById(selectedEventId) || state.events[0])?.id || 'manual';
    if (Number(appeal.sourceCycle) === Number(state.puppetCycle || 1)) {
      member.puppetComplete = true;
      member.puppetCompletedAt = localISO(new Date());
    }
    const selected = eventById(selectedEventId) || state.events[0];
    if (selected) selected.auction = null;
    save(`${member.name} Puppet make-up completed`);
    render();
  }, true);

  const originalRenderPuppetRotation = renderPuppetRotation;
  renderPuppetRotation = function sevenDayAppealRender() {
    return originalRenderPuppetRotation()
      .replace('Appeals only exist inside the current Puppet cycle. Once the cycle ends, old appeals are no longer accepted. If approved, your one make-up turn is placed after the remaining normal A-Z turns and before the next cycle begins.', 'Each cycle has a 7-day appeal window after it ends. Approved make-ups are prioritized in the next available Puppet bidding while that window remains open. Unused make-ups expire when the 7 days end.')
      .replace('No appealable Puppet turn in the current cycle', 'No appealable Puppet turn in an open 7-day window');
  };

  const observer = new MutationObserver(() => {
    const panel = document.querySelector('#puppet-appeals-panel');
    if (!panel) return;
    panel.querySelectorAll('p').forEach(p => {
      if (/Old-cycle appeals cannot be approved/i.test(p.textContent || '')) {
        p.textContent = (p.textContent || '').replace(/Old-cycle appeals cannot be approved\.?/i, 'Appeals remain reviewable for 7 days after their cycle closes.');
      }
    });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  window.__havocAppealWindowOpen = windowOpen;
  window.__havocAppealableTurns = appealableTurns;
})();