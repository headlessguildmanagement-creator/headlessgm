(() => {
  const MAX_FILES = 20;
  const MAX_EDGE = 1000;
  const START_QUALITY = 0.68;
  const MAX_DATA_URL_CHARS = 150000;
  const MAX_TOTAL_DATA_URL_CHARS = 3000000;

  function configureInput(root = document) {
    const input = root.querySelector?.('#puppet-appeal-form input[name="screenshot"]');
    if (!input) return;
    input.multiple = true;
    input.setAttribute('multiple', '');
    input.setAttribute('data-max-files', String(MAX_FILES));
    const help = input.parentElement?.querySelector('small');
    if (help) help.textContent = `Upload 1 to ${MAX_FILES} separate JPG, PNG, or WebP screenshots. Use before-and-after Trade History screenshots when possible. Officers will review every uploaded image.`;
    const label = input.parentElement?.querySelector('label');
    if (label) label.textContent = 'SCREENSHOT PROOF (UP TO 20 FILES)';
  }

  async function imageToDataUrl(file) {
    if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error('Only JPG, PNG, or WebP screenshots are allowed');
    const bitmap = await createImageBitmap(file);
    try {
      let scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
      let quality = START_QUALITY;
      let dataUrl = '';

      for (let attempt = 0; attempt < 8; attempt++) {
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));
        canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        dataUrl = canvas.toDataURL('image/jpeg', quality);
        if (dataUrl.length <= MAX_DATA_URL_CHARS) return dataUrl;
        if (quality > 0.42) quality -= 0.08;
        else scale *= 0.82;
      }

      if (dataUrl.length > MAX_DATA_URL_CHARS) throw new Error(`${file.name || 'A screenshot'} is too large. Please crop it and try again.`);
      return dataUrl;
    } finally {
      bitmap.close?.();
    }
  }

  async function prepareScreenshots(files) {
    if (!files.length) throw new Error('Attach at least one screenshot');
    if (files.length > MAX_FILES) throw new Error(`You can upload up to ${MAX_FILES} screenshots per appeal`);
    const dataUrls = [];
    let total = 0;
    for (const file of files) {
      const dataUrl = await imageToDataUrl(file);
      total += dataUrl.length;
      if (total > MAX_TOTAL_DATA_URL_CHARS) throw new Error('The selected screenshots are too large together. Please crop them or upload fewer files.');
      dataUrls.push(dataUrl);
    }
    return dataUrls;
  }

  async function submitMultiAppeal(form) {
    const button = form.querySelector('button[type="submit"],button:not([type])');
    if (!button || button.disabled) return;
    const input = form.querySelector('input[name="screenshot"]');
    const files = [...(input?.files || [])];
    if (!files.length) return toast('Attach at least one screenshot');
    if (files.length > MAX_FILES) return toast(`You can upload up to ${MAX_FILES} screenshots per appeal`);

    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Preparing screenshots…';
    try {
      const data = new FormData(form);
      const screenshotDataUrls = await prepareScreenshots(files);
      button.textContent = 'Submitting…';
      const response = await fetch('/api/state-store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'puppet_appeal_submit',
          playerId: data.get('playerId'),
          eventId: data.get('eventId'),
          reason: data.get('reason'),
          declaration: data.get('declaration') === 'on',
          screenshotDataUrls
        })
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || 'Puppet Appeal failed');
      form.reset();
      const eventSelect = form.querySelector('#puppet-appeal-event');
      if (eventSelect) {
        eventSelect.disabled = true;
        eventSelect.innerHTML = '<option value="">Select your IGN first</option>';
      }
      toast(result.message || 'Puppet Appeal submitted');
    } catch (error) {
      console.error(error);
      toast(error.message || 'Puppet Appeal failed');
    } finally {
      button.disabled = false;
      button.textContent = old;
    }
  }

  document.addEventListener('change', event => {
    const input = event.target;
    if (!input?.matches?.('#puppet-appeal-form input[name="screenshot"]')) return;
    const count = input.files?.length || 0;
    if (count > MAX_FILES) {
      input.value = '';
      toast(`You can upload up to ${MAX_FILES} screenshots per appeal`);
    }
  }, true);

  document.addEventListener('submit', event => {
    if (event.target?.id !== 'puppet-appeal-form') return;
    event.preventDefault();
    event.stopImmediatePropagation();
    submitMultiAppeal(event.target);
  }, true);

  const originalRender = render;
  render = function puppetAppealMultiFileAwareRender() {
    const result = originalRender.apply(this, arguments);
    configureInput();
    return result;
  };

  configureInput();
  window.__havocPuppetAppealMaxFiles = MAX_FILES;
})();
