(() => {
  function rotation() {
    return (state.players || [])
      .filter(member => member.active && Number.isInteger(member.puppetOrder))
      .sort((a, b) => a.puppetOrder - b.puppetOrder);
  }

  function activeLoa(event, playerId) {
    return (state.loas || []).some(row => row.eventId === event?.id && row.playerId === playerId && !row.cancelledAt);
  }

  function isEventUnavailable(member, event) {
    if (!member || !event) return true;
    const absent = activeLoa(event, member.id) || (event.noShows || []).includes(member.id);
    const cannotBid = (event.puppetCannotBidIds || []).includes(member.id);
    const featherAbsent = (event.ineligibleFeatherIds || []).includes(member.id)
      && event.featherIneligibleReasons?.[member.id] === 'Absent';
    return absent || cannotBid || featherAbsent;
  }

  function is96hPenalty(member, event) {
    return typeof window.havocIsMemberEligibleForEvent === 'function'
      ? !window.havocIsMemberEligibleForEvent(member, event)
      : false;
  }

  function appealWindowOpen(cycle) {
    if (typeof window.__havocAppealWindowOpen === 'function') {
      return window.__havocAppealWindowOpen(cycle);
    }
    return Number(cycle) === Number(state.puppetCycle || 1);
  }

  function activeAppeals(event) {
    const byId = new Map((state.players || []).map(member => [member.id, member]));
    return (state.puppetAppealQueue || [])
      .filter(row => !row.consumedAt && appealWindowOpen(row.sourceCycle))
      .sort((a, b) => String(a.approvedAt || '').localeCompare(String(b.approvedAt || '')))
      .map(row => ({ row, member: byId.get(row.playerId) }))
      .filter(({ member }) => member?.active
        && Number.isInteger(member.puppetOrder)
        && !isEventUnavailable(member, event)
        && !is96hPenalty(member, event));
  }

  function selectPuppets(event, requestedCount) {
    const count = Math.max(0, Math.floor(Number(requestedCount) || 0));
    if (!count) return [];

    const list = rotation();
    const available = list.filter(member => !isEventUnavailable(member, event) && !is96hPenalty(member, event));
    const incompleteAll = list.filter(member => !member.puppetComplete);
    const incompleteAvailable = available.filter(member => !member.puppetComplete);
    const creditedIds = new Set((state.puppetNextCycleCredits || [])
      .filter(row => !row.appliedAt && Number(row.sourceCycle) === Number(state.puppetCycle || 1))
      .map(row => row.playerId));

    const assignments = [];
    const assignedIds = new Set();
    const take = (member, puppetCycleOffset, puppetAppealId = null) => {
      if (!member || assignedIds.has(member.id) || assignments.length >= count) return;
      assignedIds.add(member.id);
      assignments.push({
        playerId: member.id,
        puppetCycleOffset,
        ...(puppetAppealId ? { puppetAppealId } : {})
      });
    };

    // Approved make-ups always get first priority while their appeal window is valid.
    activeAppeals(event).forEach(({ row, member }) => take(member, 0, row.appealId));
    incompleteAvailable.forEach(member => take(member, 0));

    const selectedNormalIds = new Set(assignments
      .filter(row => !row.puppetAppealId && Number(row.puppetCycleOffset || 0) === 0)
      .map(row => row.playerId));

    // Only 96H penalty may be deferred. LOA, no-show and Cannot Bid still hold the cycle open.
    const cycleCanClose = incompleteAll.every(member => selectedNormalIds.has(member.id) || is96hPenalty(member, event));
    if (cycleCanClose && assignments.length < count) {
      available
        .filter(member => member.puppetComplete && !creditedIds.has(member.id))
        .forEach(member => take(member, 1));
    }
    return assignments;
  }

  function puppetSlots(event, count) {
    return selectPuppets(event, count).map((assignment, index) => ({
      ...slotAt(index, 'Puppet Fragment', 'Cards'),
      playerId: assignment.playerId,
      group: null,
      puppetCycleOffset: assignment.puppetCycleOffset,
      ...(assignment.puppetAppealId ? { puppetAppealId: assignment.puppetAppealId } : {})
    }));
  }

  // Replace only the Puppet portion. Passing puppetCount: 0 through the existing builder
  // preserves all Feather logic while avoiding the older frontend Puppet selector.
  const previousBuildAuction = buildAuction;
  buildAuction = function productionSafePuppetBuild(event, settings) {
    const nonPuppet = previousBuildAuction(event, { ...settings, puppetCount: 0 });
    return [...puppetSlots(event, settings?.puppetCount), ...nonPuppet];
  };

  const previousBuildAuctionFromDistribution = buildAuctionFromDistribution;
  buildAuctionFromDistribution = function productionSafePuppetDistribution(event, settings, distribution) {
    const nonPuppet = previousBuildAuctionFromDistribution(event, { ...settings, puppetCount: 0 }, distribution);
    return [...puppetSlots(event, settings?.puppetCount), ...nonPuppet];
  };

  // A consumed make-up assignment may still exist in the selected event's saved Auction.
  // Do not let that stale assignment keep rendering MAKE-UP BIDDER after completion.
  const previousRenderPuppetQueue = renderPuppetQueue;
  renderPuppetQueue = function consumedMakeupSafeQueue() {
    const html = previousRenderPuppetQueue();
    if (typeof document === 'undefined') return html;

    const event = eventById(selectedEventId) || state.events?.[0];
    if (!event) return html;
    const list = rotation();
    const assignments = new Map((event.auction?.assignments || [])
      .filter(item => item.category === 'Puppet Fragment')
      .map(item => [item.playerId, item]));
    const appealRows = new Map((state.puppetAppealQueue || []).map(row => [row.appealId, row]));

    const template = document.createElement('template');
    template.innerHTML = html;
    const rows = [...template.content.querySelectorAll('tbody tr')];
    rows.forEach((row, index) => {
      const member = list[index];
      const assignment = member ? assignments.get(member.id) : null;
      const appealAssignmentRow = assignment?.puppetAppealId ? appealRows.get(assignment.puppetAppealId) : null;
      if (!member || !assignment?.puppetAppealId || !appealAssignmentRow?.consumedAt) return;

      if (row.children[2]) {
        row.children[2].innerHTML = member.puppetComplete
          ? '<span class="pill green">DONE</span>'
          : '<span class="pill amber">PENDING</span>';
      }
      if (row.children[3]) row.children[3].textContent = member.puppetCompletedAt ? formatDate(member.puppetCompletedAt) : '—';
      if (row.children[4]) {
        if (accessMode !== 'commander' || currentView !== 'puppet') row.children[4].textContent = '—';
        else if (member.puppetComplete) row.children[4].innerHTML = `<button class="button ghost small puppet-set-pending" data-player="${member.id}">Set Pending</button>`;
        else row.children[4].innerHTML = `<div class="card-actions"><button class="button small puppet-complete" data-player="${member.id}">Complete Puppet</button><button class="button ghost small puppet-cannot-bid" data-player="${member.id}">Cannot Bid</button></div>`;
      }
    });
    return template.innerHTML;
  };

  window.__havocProductionPuppetSelector = selectPuppets;
})();
